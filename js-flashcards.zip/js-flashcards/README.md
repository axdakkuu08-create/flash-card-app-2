# JS Flashcards

A flashcard app with a small backend and an Android wrapper.

```
backend/   Node server (no npm packages). Saves decks, makes cards from PDFs or text.
web/       The app (React). The server also hosts it, and the APK bundles it.
android/   Android project that shows web/ full screen, with a file picker for PDFs.
.github/   Workflow that builds the APK for you.
Dockerfile Optional, for hosting the server in a container.
```

## 1. Run the backend

Needs Node 18 or newer. No `npm install`.

```
cd backend
ANTHROPIC_API_KEY=sk-ant-... APP_TOKEN=pick-a-long-secret node server.js
```

Open http://localhost:3000. On first start the server downloads React into `web/vendor/`, so it needs internet once.

| Variable | Meaning | Default |
|---|---|---|
| `ANTHROPIC_API_KEY` | Key used to make cards. Without it the server still saves decks. | none |
| `APP_TOKEN` | Secret the app must send. Set this on any server reachable from the internet, or anyone can spend your API credit. | none |
| `ANTHROPIC_MODEL` | Model used for cards | `claude-sonnet-5-5` |
| `PORT`, `HOST` | Where to listen | `3000`, `0.0.0.0` |
| `DATA_DIR` | Where decks are stored (one JSON file each) | `backend/data` |
| `GENERATE_PER_HOUR` | Card requests allowed per IP per hour | `20` |
| `TRUST_PROXY` | Set to `1` behind a proxy so the real client IP is used | off |

### API

| Route | What it does |
|---|---|
| `GET /api/health` | `{ ok, ai, auth }`. No token needed. |
| `GET /api/decks` | List saved decks |
| `GET /api/decks/:id` | One deck with its cards |
| `POST /api/decks` | Save a deck: `{ "name": "...", "cards": [{ "topic", "q", "a", "code" }] }` |
| `DELETE /api/decks/:id` | Delete a deck |
| `POST /api/generate?count=12&name=...` | Body is a PDF (`Content-Type: application/pdf`) or JSON `{ "text": "...", "name": "..." }`. Makes the cards, saves the deck and returns it. |

When `APP_TOKEN` is set, send `Authorization: Bearer <token>` on every route except `/api/health`.

PDFs go straight to the Anthropic API, so they are read as the model sees them (text and layout). Limits are 30 MB per file and about 100 pages.

### Hosting it

Any host that runs Node or Docker works. With Docker:

```
docker build -t js-flashcards .
docker run -p 3000:3000 -v flashcards-data:/data \
  -e ANTHROPIC_API_KEY=sk-ant-... -e APP_TOKEN=pick-a-long-secret js-flashcards
```

Put it behind HTTPS (most hosts do this for you). The app sends the token with every request, so plain `http://` is only for testing on your own network.

## 2. Build the APK

### Option A: GitHub builds it for you

1. Create a GitHub repository and upload this whole folder to the `main` branch (keep the `.github` folder).
2. Open the repository's **Actions** tab. The **Build APK** workflow runs on every push. You can also start it with **Run workflow**.
3. When it finishes, open the repository's **Releases** page, find **Latest APK** and download `js-flashcards.apk`. This is a plain APK you can install directly.

The same file is also attached to the workflow run as an artifact, but GitHub wraps artifacts in a `.zip`. Android cannot install a zip: unzip it first.

### Option B: Android Studio

1. Open the `android/` folder in Android Studio and let it sync.
2. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. The file is `android/app/build/outputs/apk/debug/app-debug.apk`.

Or from a terminal with JDK 17 and the Android SDK installed: `cd android && gradle assembleDebug` (Gradle 8.9 or newer).

The build downloads React into `web/vendor/` automatically, so it needs internet.

### Install it

Copy the APK to your phone and open it. Android asks you to allow installs from that source. This is a debug-signed build for your own use. A Play Store release needs your own signing key. It needs Android 5.0 or newer.

If Android says "There was a problem parsing the package":

- Make sure the file name ends in `.apk`, not `.zip` or `.apk.zip`. Unzip anything you downloaded from the Actions page.
- Download it again from the Releases page. A cut-off download gives this error.
- Do not install the "Source code" zip from a release. That is not the app.
- Check Settings > About phone for the Android version. Versions below 5.0 cannot run this app.

## 3. Connect the app to the server

Open the app, tap **Decks**, open **Server settings**, enter your server address (for example `https://flashcards.example.com`) and the access token, then tap **Save and test**.

Without a server the app still works with the built-in JavaScript deck, and it keeps the last deck you opened on the phone.

## Notes

- Decks are shared by everyone who has the server address and token. There are no separate user accounts.
- Making cards uses your Anthropic API credit.
- Nothing here was compiled on the machine that wrote it: the Android project is untested until you build it.
