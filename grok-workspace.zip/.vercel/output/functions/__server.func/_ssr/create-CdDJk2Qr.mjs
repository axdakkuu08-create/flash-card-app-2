import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as ImagePlus, r as Trash2 } from "../_libs/lucide-react.mjs";
import { i as Route$6 } from "./router-CRcXBGnh.mjs";
import { a as Notice, c as useLibrary, n as Button, r as Field, s as fieldClass, t as AppFrame } from "./shell-BH10JKgo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/create-CdDJk2Qr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function compressImage(file) {
	if (!file.type.startsWith("image/")) throw new Error("Choose an image file.");
	if (file.size > 8e6) throw new Error("That image is too large.");
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, 960 / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const context = canvas.getContext("2d");
	if (!context) throw new Error("Could not read that image.");
	context.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	const url = canvas.toDataURL("image/jpeg", .72);
	if (url.length > 7e5) throw new Error("That image is still too large after compressing. Try a smaller one.");
	return url;
}
function CreatePage() {
	const search = Route$6.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateBody, {
		cardId: search.card,
		deckId: search.deckId
	}) });
}
function CreateBody({ cardId, deckId }) {
	const navigate = useNavigate();
	const library = useLibrary((state) => state.library);
	const ready = useLibrary((state) => state.ready);
	const addCard = useLibrary((state) => state.addCard);
	const updateCard = useLibrary((state) => state.updateCard);
	const existing = library.cards.find((card) => card.id === cardId);
	const [selectedDeck, setSelectedDeck] = (0, import_react.useState)(deckId ?? existing?.deckId ?? library.decks[0]?.id ?? "");
	const [newDeck, setNewDeck] = (0, import_react.useState)("");
	const [front, setFront] = (0, import_react.useState)(existing?.front ?? "");
	const [back, setBack] = (0, import_react.useState)(existing?.back ?? "");
	const [image, setImage] = (0, import_react.useState)(existing?.image ?? null);
	const [reverse, setReverse] = (0, import_react.useState)(existing?.reverse ?? false);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!existing) return;
		setSelectedDeck(existing.deckId);
		setFront(existing.front);
		setBack(existing.back);
		setImage(existing.image);
		setReverse(existing.reverse);
	}, [existing]);
	(0, import_react.useEffect)(() => {
		if (existing || selectedDeck || library.decks.length === 0) return;
		const preferred = deckId && library.decks.some((deck) => deck.id === deckId) ? deckId : library.decks[0]?.id;
		if (preferred) setSelectedDeck(preferred);
	}, [
		deckId,
		existing,
		library.decks,
		selectedDeck
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading your cards…"
	});
	if (cardId && !existing) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
		tone: "error",
		children: "That card is no longer on this device."
	});
	const save = async () => {
		setBusy(true);
		setError("");
		try {
			if (existing) {
				if (!selectedDeck) throw new Error("Choose a deck.");
				await updateCard(existing.id, {
					deckId: selectedDeck,
					front,
					back,
					image,
					reverse
				});
				await navigate({
					to: "/decks/$deckId",
					params: { deckId: selectedDeck }
				});
			} else {
				const savedDeck = await addCard({
					deckId: selectedDeck,
					newDeckTitle: newDeck,
					front,
					back,
					image,
					reverse
				});
				await navigate({
					to: "/decks/$deckId",
					params: { deckId: savedDeck }
				});
			}
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Couldn't save that card.");
		} finally {
			setBusy(false);
		}
	};
	const wrapSelection = (element) => {
		const start = element.selectionStart ?? 0;
		const end = element.selectionEnd ?? 0;
		if (start === end) {
			setFront((current) => `${current}{{answer}}`);
			return;
		}
		const next = `${front.slice(0, start)}{{${front.slice(start, end)}}}${front.slice(end)}`;
		setFront(next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-[0.16em] text-muted",
			children: existing ? "EDIT" : "NEW CARD"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl text-fg",
			children: existing ? "Edit card" : "Create a card"
		})] }),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "error",
			children: error
		}) : null,
		existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Deck",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: fieldClass,
				value: selectedDeck,
				onChange: (event) => setSelectedDeck(event.target.value),
				children: library.decks.map((deck) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: deck.id,
					children: deck.title
				}, deck.id))
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Deck",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: fieldClass,
				value: selectedDeck,
				onChange: (event) => setSelectedDeck(event.target.value),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "Choose a deck"
				}), library.decks.map((deck) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: deck.id,
					children: deck.title
				}, deck.id))]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Or a new deck name",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: fieldClass,
				value: newDeck,
				onChange: (event) => setNewDeck(event.target.value),
				placeholder: "Biology · Cell structure",
				maxLength: 120
			})
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Front",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "card-front",
				className: `${fieldClass} min-h-28`,
				value: front,
				onChange: (event) => setFront(event.target.value),
				placeholder: "Question, or wrap a hidden word in {{braces}}"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "self-start text-sm font-semibold text-primary",
			onClick: () => {
				const element = document.getElementById("card-front");
				if (element instanceof HTMLTextAreaElement) wrapSelection(element);
			},
			children: "Make cloze from selection"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Back",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: `${fieldClass} min-h-28`,
				value: back,
				onChange: (event) => setBack(event.target.value),
				placeholder: "Answer or explanation"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex min-h-11 items-center justify-between gap-3 rounded-lg border border-line bg-surface px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-semibold text-fg",
				children: "Also study in reverse"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: reverse,
				onChange: (event) => setReverse(event.target.checked),
				className: "size-5 accent-primary"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-line bg-surface p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-fg",
					children: "Image"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex min-h-11 cursor-pointer items-center gap-2 text-sm font-semibold text-primary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }),
						"Add",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "sr-only",
							onChange: (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								compressImage(file).then(setImage).catch((caught) => {
									setError(caught instanceof Error ? caught.message : "Couldn't read that image.");
								});
							}
						})
					]
				})]
			}), image ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: image,
					alt: "",
					className: "max-h-40 w-full rounded-lg object-contain"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-2 inline-flex min-h-11 items-center gap-2 text-sm text-muted",
					onClick: () => setImage(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Remove image"]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Optional. Compressed before it's saved."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			disabled: busy,
			onClick: () => void save(),
			children: busy ? "Saving…" : existing ? "Save changes" : "Save card"
		})
	] });
}
//#endregion
export { CreatePage as component };
