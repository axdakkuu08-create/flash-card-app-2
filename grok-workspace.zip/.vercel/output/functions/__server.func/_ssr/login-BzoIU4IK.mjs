import { o as SignInPanel } from "./shell-BH10JKgo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BzoIU4IK.js
var SplitComponent = SignInPanel;
//#endregion
export { SplitComponent as component };
