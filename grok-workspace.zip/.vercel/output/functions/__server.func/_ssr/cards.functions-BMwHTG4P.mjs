import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware, x as validateData } from "./flashcards-DY5jnvyq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cards.functions-BMwHTG4P.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asText(value) {
	if (typeof value === "string") return value;
	if (value == null) return "";
	return String(value);
}
function asIso(value) {
	if (value instanceof Date) return value.toISOString();
	if (typeof value === "string" && value) return value;
	return (/* @__PURE__ */ new Date()).toISOString();
}
function cleanTime(value) {
	if (typeof value !== "string") return "09:00";
	const match = /^(\d{2}):(\d{2})$/.exec(value);
	if (!match) return "09:00";
	const hour = Number(match[1]);
	const minute = Number(match[2]);
	if (hour > 23 || minute > 59) return "09:00";
	return value;
}
var getLibrary_createServerFn_handler = createServerRpc({
	id: "cf2228d3be923940e62dda92952d57489b4b4f172ca0bcf5519c2255862f25b4",
	name: "getLibrary",
	filename: "src/lib/cards.functions.ts"
}, (opts) => getLibrary.__executeServer(opts));
var getLibrary = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getLibrary_createServerFn_handler, async ({ context }) => {
	const { getSql } = await import("./db-CkJgLcb0.mjs").then((n) => n.t).then((n) => n.t);
	const row = (await (await getSql())`
      select payload, updated_at from flashcard_libraries where user_id = ${context.userId}
    `)[0];
	if (!row) return null;
	return {
		library: validateData(JSON.parse(asText(row.payload))),
		updatedAt: asIso(row.updated_at)
	};
});
var saveLibrary_createServerFn_handler = createServerRpc({
	id: "bf318fb953e361550c4fa268e4ee4b2721b8acba6e1cc59b5d5ee7a7fcf4eeee",
	name: "saveLibrary",
	filename: "src/lib/cards.functions.ts"
}, (opts) => saveLibrary.__executeServer(opts));
var saveLibrary = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => validateData(input)).handler(saveLibrary_createServerFn_handler, async ({ context, data }) => {
	const { getSql } = await import("./db-CkJgLcb0.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	const payload = JSON.stringify(data);
	await sql`
      insert into flashcard_libraries (user_id, payload)
      values (${context.userId}, ${payload})
      on conflict (user_id) do update
      set payload = excluded.payload, updated_at = now()
    `;
	return {
		ok: true,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
});
var getReminder_createServerFn_handler = createServerRpc({
	id: "3dc14270a9d6fc2b7b7e6bd5631b1a2ded9649a2ee77f4674cf423ec19580c29",
	name: "getReminder",
	filename: "src/lib/cards.functions.ts"
}, (opts) => getReminder.__executeServer(opts));
var getReminder = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getReminder_createServerFn_handler, async ({ context }) => {
	const { getSql } = await import("./db-CkJgLcb0.mjs").then((n) => n.t).then((n) => n.t);
	const row = (await (await getSql())`
      select enabled, remind_time from flashcard_reminders where user_id = ${context.userId}
    `)[0];
	if (!row) return {
		enabled: false,
		time: "09:00"
	};
	return {
		enabled: row.enabled === true || row.enabled === 1 || row.enabled === "t" || row.enabled === "true",
		time: cleanTime(row.remind_time)
	};
});
var saveReminder_createServerFn_handler = createServerRpc({
	id: "175b93a8fd6fb1e6c32cb92cd8bcd6f2c069e82c4d9254f2ca03a52bd9689cd7",
	name: "saveReminder",
	filename: "src/lib/cards.functions.ts"
}, (opts) => saveReminder.__executeServer(opts));
var saveReminder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const record = typeof input === "object" && input !== null ? input : {};
	return {
		enabled: record.enabled === true,
		time: cleanTime(record.time)
	};
}).handler(saveReminder_createServerFn_handler, async ({ context, data }) => {
	const { getSql } = await import("./db-CkJgLcb0.mjs").then((n) => n.t).then((n) => n.t);
	await (await getSql())`
      insert into flashcard_reminders (user_id, enabled, remind_time)
      values (${context.userId}, ${data.enabled}, ${data.time})
      on conflict (user_id) do update
      set enabled = excluded.enabled, remind_time = excluded.remind_time
    `;
	return data;
});
//#endregion
export { getLibrary_createServerFn_handler, getReminder_createServerFn_handler, saveLibrary_createServerFn_handler, saveReminder_createServerFn_handler };
