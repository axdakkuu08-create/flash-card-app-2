import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cardStatus, o as dueQueue } from "./flashcards-DY5jnvyq.mjs";
import { i as Search, t as X } from "../_libs/lucide-react.mjs";
import { c as useLibrary, s as fieldClass, t as AppFrame } from "./shell-BH10JKgo.mjs";
import { t as useNow } from "./use-now-B7ZNXveZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/decks-Dmp-XRvr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DecksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecksBody, {}) });
}
function DecksBody() {
	const now = useNow();
	const library = useLibrary((state) => state.library);
	const ready = useLibrary((state) => state.ready);
	const [query, setQuery] = (0, import_react.useState)("");
	const decks = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return library.decks.filter((deck) => deck.title.toLowerCase().includes(needle));
	}, [library.decks, query]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading your cards…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.16em] text-muted",
				children: "YOUR COLLECTION"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl text-fg",
				children: "Decks"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [library.decks.length, " stored with your account"]
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 rounded-lg border border-line bg-bg px-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					"aria-label": "Search decks",
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search your decks",
					className: `${fieldClass} border-0 bg-transparent px-0`
				}),
				query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Clear search",
					onClick: () => setQuery(""),
					className: "grid h-11 w-11 place-items-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}) : null
			]
		}),
		decks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-line bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-fg",
					children: query ? "No matching decks" : "Your first deck is waiting"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: query ? "Try a different search." : "Create a card and give it a home."
				}),
				!query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/create",
					className: "mt-4 flex min-h-11 items-center justify-center rounded-lg bg-primary text-sm font-semibold text-primary-ink",
					children: "Create a card"
				}) : null
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: decks.map((deck) => {
				const cards = library.cards.filter((card) => card.deckId === deck.id);
				const due = dueQueue(cards, now).length;
				const mastered = cards.filter((card) => cardStatus(card) === "mastered").length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/decks/$deckId",
						params: { deckId: deck.id },
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl text-fg",
							children: deck.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								cards.length,
								" cards · ",
								due,
								" due · ",
								mastered,
								" mastered"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/study",
						search: { deckId: deck.id },
						className: "mt-3 flex min-h-11 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg",
						children: "Study"
					})]
				}, deck.id);
			})
		})
	] });
}
//#endregion
export { DecksPage as component };
