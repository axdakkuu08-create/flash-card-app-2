import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as dueLabel, d as isCloze, n as cardStatus, u as hideCloze, y as statusLabel } from "./flashcards-DY5jnvyq.mjs";
import { n as Route$1 } from "./router-CRcXBGnh.mjs";
import { c as useLibrary, i as Modal, n as Button, s as fieldClass, t as AppFrame } from "./shell-BH10JKgo.mjs";
import { t as useNow } from "./use-now-B7ZNXveZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/decks._deckId-DxZ_KHs4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DeckPage() {
	const { deckId } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeckBody, { deckId }) });
}
function DeckBody({ deckId }) {
	const now = useNow();
	const navigate = useNavigate();
	const library = useLibrary((state) => state.library);
	const ready = useLibrary((state) => state.ready);
	const renameDeck = useLibrary((state) => state.renameDeck);
	const deleteDeck = useLibrary((state) => state.deleteDeck);
	const deleteCard = useLibrary((state) => state.deleteCard);
	const deck = library.decks.find((item) => item.id === deckId);
	const cards = library.cards.filter((card) => card.deckId === deckId);
	const [title, setTitle] = (0, import_react.useState)("");
	const [named, setNamed] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [confirmDeck, setConfirmDeck] = (0, import_react.useState)(false);
	const [pendingCard, setPendingCard] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!deck || named) return;
		setTitle(deck.title);
		setNamed(true);
	}, [deck, named]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading your cards…"
	});
	if (!deck) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl text-fg",
			children: "Deck not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/decks",
			className: "mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-primary",
			children: "Back to decks"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-[0.16em] text-muted",
			children: "DECK"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl text-fg",
			children: deck.title
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				setError("");
				renameDeck(deck.id, title).catch((caught) => {
					setError(caught instanceof Error ? caught.message : "Couldn't rename that deck.");
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold tracking-wide text-muted",
					htmlFor: "deck-name",
					children: "Name"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "deck-name",
						className: fieldClass,
						value: title,
						maxLength: 120,
						onChange: (event) => setTitle(event.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "ghost",
						className: "shrink-0",
						children: "Rename"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: error
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/study",
				search: { deckId: deck.id },
				className: "flex min-h-11 items-center justify-center rounded-lg bg-primary text-sm font-semibold text-primary-ink",
				children: "Study this deck"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/create",
				search: { deckId: deck.id },
				className: "flex min-h-11 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg",
				children: "Add a card"
			})]
		}),
		cards.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-lg border border-line bg-surface p-4 text-sm text-muted",
			children: "This deck has no cards yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: cards.map((card) => {
				const status = cardStatus(card);
				const front = isCloze(card.front) ? hideCloze(card.front) : card.front;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap text-base font-semibold text-fg",
							children: front
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								statusLabel(status),
								" · ",
								dueLabel(card.nextReview, now),
								card.reverse ? " · Reverse on" : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/create",
								search: { card: card.id },
								className: "flex min-h-11 flex-1 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg",
								children: "Edit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 flex-1 rounded-lg border border-line text-sm font-semibold text-fg",
								onClick: () => setPendingCard(card.id),
								children: "Delete"
							})]
						})
					]
				}, card.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "text-sm font-semibold text-muted",
			onClick: () => setConfirmDeck(true),
			children: "Delete this deck and its cards"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: confirmDeck,
			title: "Delete deck?",
			onClose: () => setConfirmDeck(false),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"“",
					deck.title,
					"” and every card in it will be removed from this device and your account."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				onClick: () => {
					deleteDeck(deck.id).then(() => navigate({ to: "/decks" }));
				},
				children: "Delete deck"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: Boolean(pendingCard),
			title: "Delete card?",
			onClose: () => setPendingCard(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "This removes one card and its review history."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				onClick: () => {
					if (!pendingCard) return;
					deleteCard(pendingCard);
					setPendingCard(null);
				},
				children: "Delete card"
			})]
		})
	] });
}
//#endregion
export { DeckPage as component };
