import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { c as emptyLibrary, f as makeId, g as rateCard, i as createInitialData, o as dueQueue, p as mergeLibraries, s as duplicateTitle, t as authMiddleware, v as serializeBackup, x as validateData } from "./flashcards-DY5jnvyq.mjs";
import { i as signOut, r as signIn, t as authClient } from "./client-IWHfIGH2.mjs";
import { a as hasGateSessionMarker, t as GROK_PROVIDERS } from "./server-VOzpyIDn.mjs";
import { a as RefreshCw, d as ChartColumn, l as House, o as Plus, s as Layers, t as X, u as GalleryHorizontalEnd } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BH10JKgo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function resolveSignInGateState(input) {
	if (input.isPending) return "pending";
	return input.hasUser ? "signed_in" : "signed_out";
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
function SignInGate({ children, fallback }) {
	const { user, isPending } = useCurrentUserState();
	const state = resolveSignInGateState({
		isPending,
		hasUser: user !== null
	});
	if (state === "pending") return null;
	if (state === "signed_in") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInButtons, {}) });
}
function SignInButtons() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex w-full max-w-sm flex-col gap-2",
		children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => signIn(p.providerId, { callbackURL: "/" }),
			className: "w-full cursor-pointer rounded-md border border-neutral-300 px-4 py-2 hover:bg-neutral-100 dark:border-neutral-700 dark:hover:bg-neutral-900",
			children: ["Continue with ", p.label]
		}, p.providerId))
	});
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function cleanTime(value) {
	if (typeof value !== "string") return "09:00";
	const match = /^(\d{2}):(\d{2})$/.exec(value);
	if (!match) return "09:00";
	const hour = Number(match[1]);
	const minute = Number(match[2]);
	if (hour > 23 || minute > 59) return "09:00";
	return value;
}
var getLibrary = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("cf2228d3be923940e62dda92952d57489b4b4f172ca0bcf5519c2255862f25b4"));
var saveLibrary = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => validateData(input)).handler(createSsrRpc("bf318fb953e361550c4fa268e4ee4b2721b8acba6e1cc59b5d5ee7a7fcf4eeee"));
var getReminder = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3dc14270a9d6fc2b7b7e6bd5631b1a2ded9649a2ee77f4674cf423ec19580c29"));
var saveReminder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const record = typeof input === "object" && input !== null ? input : {};
	return {
		enabled: record.enabled === true,
		time: cleanTime(record.time)
	};
}).handler(createSsrRpc("175b93a8fd6fb1e6c32cb92cd8bcd6f2c069e82c4d9254f2ca03a52bd9689cd7"));
var STORAGE_KEY = "flashcards-offline-data-v3";
var REMINDER_KEY = "flashcards-reminder-v3";
function readEnvelope() {
	if (typeof localStorage === "undefined") return { kind: "empty" };
	const raw = localStorage.getItem(STORAGE_KEY);
	if (!raw) return { kind: "empty" };
	try {
		const parsed = JSON.parse(raw);
		if (typeof parsed === "object" && parsed !== null && "library" in parsed) {
			const envelope = parsed;
			return {
				kind: "ok",
				library: validateData(envelope.library),
				dirty: envelope.dirty === true
			};
		}
		return {
			kind: "ok",
			library: validateData(parsed),
			dirty: false
		};
	} catch {
		return {
			kind: "corrupt",
			raw
		};
	}
}
function writeEnvelope(library, dirty) {
	const envelope = {
		v: 3,
		dirty,
		library
	};
	localStorage.setItem(STORAGE_KEY, JSON.stringify(envelope));
}
function readReminder() {
	try {
		const raw = localStorage.getItem(REMINDER_KEY);
		if (!raw) return {
			enabled: false,
			time: "09:00"
		};
		const parsed = JSON.parse(raw);
		return {
			enabled: parsed.enabled === true,
			time: /^\d{2}:\d{2}$/.test(parsed.time) ? parsed.time : "09:00"
		};
	} catch {
		return {
			enabled: false,
			time: "09:00"
		};
	}
}
function messageOf(error) {
	if (error instanceof Error && error.message) return error.message;
	return "Something went wrong.";
}
function isNetwork(error) {
	const message = messageOf(error).toLowerCase();
	return error instanceof TypeError || /fetch|network|failed to|load failed|offline|timeout/.test(message);
}
async function pushLibrary(library) {
	await saveLibrary({ data: library });
}
async function runBootstrap(userId, set) {
	const local = readEnvelope();
	const reminder = readReminder();
	if (local.kind === "corrupt") {
		set({
			ready: true,
			userId,
			corruptRaw: local.raw,
			library: emptyLibrary(),
			dirty: false,
			reminder,
			error: "The copy saved on this device can't be read. It was left untouched."
		});
		try {
			const remoteReminder = await getReminder();
			localStorage.setItem(REMINDER_KEY, JSON.stringify(remoteReminder));
			set({ reminder: remoteReminder });
		} catch {}
		return;
	}
	let library = local.kind === "ok" ? local.library : emptyLibrary();
	let dirty = local.kind === "ok" ? local.dirty : false;
	set({
		userId,
		library,
		dirty,
		corruptRaw: null,
		reminder,
		ready: false,
		error: null
	});
	try {
		set({ syncing: true });
		if (local.kind === "ok" && dirty) await pushLibrary(library);
		const remote = await getLibrary();
		if (!remote) {
			if (local.kind === "empty" || !library.initialized) library = createInitialData();
			await pushLibrary(library);
		} else if (!(local.kind === "ok" && dirty)) library = remote.library;
		writeEnvelope(library, false);
		const remoteReminder = await getReminder();
		localStorage.setItem(REMINDER_KEY, JSON.stringify(remoteReminder));
		set({
			library,
			dirty: false,
			offline: false,
			syncing: false,
			ready: true,
			lastSyncedAt: Date.now(),
			reminder: remoteReminder,
			error: null
		});
	} catch (error) {
		if (local.kind === "empty") {
			library = createInitialData();
			dirty = true;
			writeEnvelope(library, true);
		}
		set({
			library,
			dirty,
			ready: true,
			syncing: false,
			offline: true,
			error: isNetwork(error) ? null : messageOf(error)
		});
	}
}
var bootPromise = null;
var bootUser = null;
var useLibrary = create((set, get) => ({
	ready: false,
	syncing: false,
	offline: false,
	dirty: false,
	error: null,
	notice: null,
	corruptRaw: null,
	library: emptyLibrary(),
	userId: null,
	lastSyncedAt: null,
	reminder: {
		enabled: false,
		time: "09:00"
	},
	undo: null,
	setNotice: (notice) => set({ notice }),
	bootstrap: (userId) => {
		if (bootUser === userId && bootPromise) return bootPromise;
		bootUser = userId;
		bootPromise = runBootstrap(userId, set);
		return bootPromise;
	},
	sync: async () => {
		const { userId, library, dirty, corruptRaw } = get();
		if (!userId || corruptRaw) return;
		set({
			syncing: true,
			error: null
		});
		try {
			if (dirty) await pushLibrary(library);
			const remote = await getLibrary();
			const next = remote?.library ?? library;
			if (!remote) await pushLibrary(next);
			writeEnvelope(next, false);
			set({
				library: next,
				dirty: false,
				offline: false,
				syncing: false,
				lastSyncedAt: Date.now()
			});
		} catch (error) {
			set({
				syncing: false,
				offline: true,
				error: isNetwork(error) ? null : messageOf(error)
			});
		}
	},
	addCard: async (input) => {
		const title = input.newDeckTitle?.trim() ?? "";
		const front = input.front.trim();
		const back = input.back.trim();
		if (!front || !back) throw new Error("Enter both the front and the back of the card.");
		let deckId = input.deckId;
		const now = Date.now();
		const cardId = makeId("card");
		await commit((library) => {
			const decks = [...library.decks];
			if (title) {
				if (duplicateTitle(decks, title)) throw new Error("A deck with that name already exists. Pick it from the list.");
				deckId = makeId("deck");
				decks.push({
					id: deckId,
					title,
					createdAt: now
				});
			}
			if (!deckId || !decks.some((deck) => deck.id === deckId)) throw new Error("Choose an existing deck or enter a new deck name.");
			const scheduleNow = now;
			const card = {
				id: cardId,
				deckId,
				front,
				back,
				image: input.image,
				reverse: input.reverse,
				mastery: 0,
				repetitions: 0,
				intervalDays: 0,
				easeFactor: 2.5,
				nextReview: scheduleNow,
				revMastery: 0,
				revRepetitions: 0,
				revIntervalDays: 0,
				revEaseFactor: 2.5,
				revNextReview: scheduleNow,
				createdAt: scheduleNow,
				reviewHistory: []
			};
			return {
				initialized: true,
				decks,
				cards: [...library.cards, card]
			};
		}, "Card saved on this device.");
		return deckId ?? "";
	},
	updateCard: async (cardId, input) => {
		const front = input.front.trim();
		const back = input.back.trim();
		if (!front || !back) throw new Error("Enter both the front and the back of the card.");
		await commit((library) => {
			if (!library.decks.some((deck) => deck.id === input.deckId)) throw new Error("Choose a deck.");
			return {
				...library,
				initialized: true,
				cards: library.cards.map((card) => card.id === cardId ? {
					...card,
					deckId: input.deckId,
					front,
					back,
					image: input.image,
					reverse: input.reverse
				} : card)
			};
		}, "Card updated.");
	},
	renameDeck: async (deckId, title) => {
		const nextTitle = title.trim();
		if (!nextTitle) throw new Error("A deck needs a name.");
		await commit((library) => {
			if (duplicateTitle(library.decks, nextTitle, deckId)) throw new Error("A deck with that name already exists.");
			return {
				...library,
				decks: library.decks.map((deck) => deck.id === deckId ? {
					...deck,
					title: nextTitle.slice(0, 120)
				} : deck)
			};
		}, "Deck renamed.");
	},
	deleteDeck: async (deckId) => {
		await commit((library) => ({
			...library,
			decks: library.decks.filter((deck) => deck.id !== deckId),
			cards: library.cards.filter((card) => card.deckId !== deckId)
		}), "Deck deleted.");
	},
	deleteCard: async (cardId) => {
		await commit((library) => ({
			...library,
			cards: library.cards.filter((card) => card.id !== cardId)
		}), "Card deleted.");
	},
	rate: async (cardId, side, rating) => {
		const current = get().library.cards.find((card) => card.id === cardId);
		if (!current) return;
		set({ undo: {
			until: Date.now() + 8e3,
			before: current,
			label: [
				"Hard",
				"Good",
				"Easy"
			][rating]
		} });
		await commit((library) => ({
			...library,
			cards: library.cards.map((card) => card.id === cardId ? rateCard(card, side, rating) : card)
		}));
	},
	undoRate: async () => {
		const undo = get().undo;
		if (!undo || undo.until < Date.now()) {
			set({ undo: null });
			return;
		}
		await commit((library) => ({
			...library,
			cards: library.cards.map((card) => card.id === undo.before.id ? undo.before : card)
		}), "Last rating undone.");
		set({ undo: null });
	},
	importReplace: async (library) => {
		const next = validateData({
			...library,
			initialized: true
		});
		await commit(() => next, "Backup restored. Your library was replaced.");
	},
	importMerge: async (incoming) => {
		let summary = "";
		await commit((library) => {
			const merged = mergeLibraries(library, incoming);
			summary = `Merged ${merged.addedCards} ${merged.addedCards === 1 ? "card" : "cards"} and ${merged.addedDecks} ${merged.addedDecks === 1 ? "deck" : "decks"}. Skipped ${merged.skippedCards} duplicates.`;
			return merged.library;
		}, "");
		set({ notice: summary });
		return summary;
	},
	exportJson: () => serializeBackup(get().library),
	startFresh: async () => {
		const next = createInitialData();
		localStorage.removeItem(STORAGE_KEY);
		await commit(() => next, "Started a fresh sample library.");
		set({
			corruptRaw: null,
			error: null
		});
	},
	adoptAccountLibrary: async () => {
		const remote = await getLibrary();
		if (!remote) throw new Error("There's no library on your account yet.");
		writeEnvelope(remote.library, false);
		set({
			library: remote.library,
			dirty: false,
			corruptRaw: null,
			offline: false,
			error: null,
			notice: "Loaded the library from your account.",
			lastSyncedAt: Date.now()
		});
	},
	setReminder: async (reminder) => {
		localStorage.setItem(REMINDER_KEY, JSON.stringify(reminder));
		set({ reminder });
		try {
			set({
				reminder: await saveReminder({ data: reminder }),
				offline: false
			});
		} catch (error) {
			if (!isNetwork(error)) set({ error: messageOf(error) });
			else set({ offline: true });
		}
	}
}));
async function commit(recipe, notice) {
	const state = useLibrary.getState();
	if (state.corruptRaw) throw new Error("This device's saved copy can't be read. Download it or start fresh before editing.");
	const next = validateData(recipe(state.library));
	writeEnvelope(next, true);
	useLibrary.setState({
		library: next,
		dirty: true,
		notice: notice || state.notice,
		error: null
	});
	if (!state.userId) return;
	useLibrary.setState({ syncing: true });
	try {
		await pushLibrary(next);
		writeEnvelope(next, false);
		useLibrary.setState({
			dirty: false,
			offline: false,
			syncing: false,
			lastSyncedAt: Date.now()
		});
	} catch (error) {
		useLibrary.setState({
			syncing: false,
			offline: true,
			error: isNetwork(error) ? null : messageOf(error)
		});
	}
}
function Button({ variant = "primary", className = "", ...props }) {
	const look = variant === "primary" ? "bg-primary text-primary-ink" : variant === "ghost" ? "border border-line bg-surface text-fg" : "bg-transparent text-primary";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: `inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-semibold transition-opacity disabled:cursor-not-allowed disabled:opacity-40 ${look} ${className}`
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-2 block text-xs font-semibold tracking-wide text-muted",
			children: label
		}), children]
	});
}
var fieldClass = "w-full rounded-lg border border-line bg-bg px-3 py-3 text-base text-fg outline-none placeholder:text-muted focus-visible:border-primary";
function Modal({ open, title, children, onClose }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "w-full max-w-md rounded-lg border border-line bg-surface p-5 shadow-xl",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-fg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close",
					onClick: onClose,
					className: "grid h-11 w-11 place-items-center rounded-lg text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})
	});
}
function Notice({ tone = "info", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: tone === "error" ? "alert" : "status",
		className: `rounded-lg border px-3 py-3 text-sm ${tone === "error" ? "border-line bg-surface-2 text-fg" : "border-line bg-surface text-muted"}`,
		children
	});
}
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/study",
		label: "Study",
		icon: GalleryHorizontalEnd
	},
	{
		to: "/create",
		label: "Create",
		icon: Plus,
		create: true
	},
	{
		to: "/decks",
		label: "Decks",
		icon: Layers
	},
	{
		to: "/stats",
		label: "Stats",
		icon: ChartColumn
	}
];
function SkeletonShell() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-lg px-4 pt-8 dock-offset",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-36 animate-pulse rounded-lg bg-surface" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-32 animate-pulse rounded-lg bg-surface" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 animate-pulse rounded-lg bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 animate-pulse rounded-lg bg-surface" })]
			})
		]
	});
}
function SignInPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-5 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.2em] text-primary",
					children: "FLASHCARDS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl text-fg",
					children: "Study once. Keep it everywhere."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-base leading-relaxed text-muted",
					children: "Cards stay available on this device and sync to your account when you're online."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInButtons, {})
				})
			]
		})
	});
}
function AppFrame({ children }) {
	const { isPending, user } = useCurrentUserState();
	const bootstrap = useLibrary((state) => state.bootstrap);
	(0, import_react.useEffect)(() => {
		if (!user?.id) return;
		bootstrap(user.id);
	}, [bootstrap, user?.id]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonShell, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInPanel, {}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children })
	});
}
function Shell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const notice = useLibrary((state) => state.notice);
	const setNotice = useLibrary((state) => state.setNotice);
	const error = useLibrary((state) => state.error);
	const corruptRaw = useLibrary((state) => state.corruptRaw);
	const offline = useLibrary((state) => state.offline);
	const dirty = useLibrary((state) => state.dirty);
	const syncing = useLibrary((state) => state.syncing);
	const ready = useLibrary((state) => state.ready);
	const reminder = useLibrary((state) => state.reminder);
	const cards = useLibrary((state) => state.library.cards);
	const sync = useLibrary((state) => state.sync);
	(0, import_react.useEffect)(() => {
		if (!notice) return;
		const id = window.setTimeout(() => setNotice(null), 5e3);
		return () => window.clearTimeout(id);
	}, [notice, setNotice]);
	useDailyReminder(ready, reminder.enabled, reminder.time, cards);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto flex w-full max-w-lg items-center justify-between gap-3 px-4 pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-primary",
					children: "FLASHCARDS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: syncing ? "Syncing" : offline && dirty ? "Saved on this device" : offline ? "Offline" : dirty ? "Waiting to sync" : "Synced"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-w-48 items-center gap-2 overflow-hidden text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Sync now",
						onClick: () => void sync(),
						className: "grid h-11 w-11 place-items-center rounded-lg border border-line bg-surface text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 ${syncing ? "animate-spin" : ""}` })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-lg px-4 pt-5 dock-offset",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4",
					children: [
						corruptRaw ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CorruptBanner, { raw: corruptRaw }) : null,
						error && !corruptRaw ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
							tone: "error",
							children: error
						}) : null,
						notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: notice }) : null,
						children
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Primary",
				className: "dock-bar fixed inset-x-0 z-40 px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex h-16 max-w-lg items-center justify-between rounded-full border border-line bg-surface px-2",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
						const Icon = item.icon;
						if ("create" in item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							"aria-label": "Create a flashcard",
							"aria-current": active ? "page" : void 0,
							className: "-mt-7 grid h-14 w-14 place-items-center rounded-full border-4 border-bg bg-primary text-primary-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-6" })
						}, item.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							"aria-label": item.label,
							"aria-current": active ? "page" : void 0,
							className: `flex h-11 items-center gap-1 rounded-full px-3 text-xs font-semibold ${active ? "bg-fg text-bg" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), active ? item.label : null]
						}, item.to);
					})
				})
			})
		]
	});
}
function CorruptBanner({ raw }) {
	const startFresh = useLibrary((state) => state.startFresh);
	const adopt = useLibrary((state) => state.adoptAccountLibrary);
	const setNotice = useLibrary((state) => state.setNotice);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-fg",
				children: "This device's copy can't be read"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Nothing was replaced with the sample deck. Download the unreadable file, load the library from your account, or start fresh."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg border border-line px-4 text-sm font-semibold text-fg",
						onClick: () => downloadText("flashcards-unreadable.json", raw),
						children: "Download unreadable copy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg border border-line px-4 text-sm font-semibold text-fg",
						onClick: () => {
							adopt().catch((error) => {
								setNotice(error instanceof Error ? error.message : "Couldn't load the account library.");
							});
						},
						children: "Load account library"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink",
						onClick: () => {
							if (window.confirm("Replace the unreadable copy with a fresh sample library?")) startFresh();
						},
						children: "Start fresh"
					})
				]
			})
		]
	});
}
function downloadText(filename, text) {
	const blob = new Blob([text], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	anchor.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
function useDailyReminder(ready, enabled, time, cards) {
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const was = localStorage.getItem("flashcards-reminder-enabled") === "1";
		if (enabled && !was) {
			const now = /* @__PURE__ */ new Date();
			const [hour, minute] = time.split(":").map(Number);
			const scheduled = new Date(now);
			scheduled.setHours(hour, minute, 0, 0);
			if (now.getTime() >= scheduled.getTime()) localStorage.setItem("flashcards-reminder-fired", now.toDateString());
		}
		localStorage.setItem("flashcards-reminder-enabled", enabled ? "1" : "0");
	}, [
		enabled,
		ready,
		time
	]);
	(0, import_react.useEffect)(() => {
		if (!ready || !enabled) return;
		const tick = () => {
			if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
			const now = /* @__PURE__ */ new Date();
			const [hour, minute] = time.split(":").map(Number);
			const scheduled = new Date(now);
			scheduled.setHours(hour, minute, 0, 0);
			if (now.getTime() + 15e3 < scheduled.getTime()) return;
			const stamp = now.toDateString();
			if (localStorage.getItem("flashcards-reminder-fired") === stamp) return;
			if (now.getTime() < scheduled.getTime()) return;
			localStorage.setItem("flashcards-reminder-fired", stamp);
			const due = dueQueue(cards, Date.now()).length;
			new Notification("Flashcards", { body: `You have ${due} ${due === 1 ? "card" : "cards"} due` });
		};
		tick();
		const id = window.setInterval(tick, 2e4);
		return () => window.clearInterval(id);
	}, [
		cards,
		enabled,
		ready,
		time
	]);
}
//#endregion
export { Notice as a, useLibrary as c, Modal as i, Button as n, SignInPanel as o, Field as r, fieldClass as s, AppFrame as t };
