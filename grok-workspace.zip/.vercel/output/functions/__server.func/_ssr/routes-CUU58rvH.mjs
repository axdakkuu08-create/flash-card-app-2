import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as streaks, m as parseImportText, n as cardStatus, o as dueQueue } from "./flashcards-DY5jnvyq.mjs";
import { c as useLibrary, i as Modal, n as Button, t as AppFrame } from "./shell-BH10JKgo.mjs";
import { t as useNow } from "./use-now-B7ZNXveZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CUU58rvH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeBody, {}) });
}
function HomeBody() {
	const now = useNow();
	const navigate = useNavigate();
	const library = useLibrary((state) => state.library);
	const ready = useLibrary((state) => state.ready);
	const reminder = useLibrary((state) => state.reminder);
	const setReminder = useLibrary((state) => state.setReminder);
	const exportJson = useLibrary((state) => state.exportJson);
	const importReplace = useLibrary((state) => state.importReplace);
	const importMerge = useLibrary((state) => state.importMerge);
	const setNotice = useLibrary((state) => state.setNotice);
	const corruptRaw = useLibrary((state) => state.corruptRaw);
	const fileRef = (0, import_react.useRef)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading your cards…"
	});
	const due = dueQueue(library.cards, now).length;
	const mastered = library.cards.filter((card) => cardStatus(card) === "mastered").length;
	const mastery = library.cards.length ? Math.round(mastered / library.cards.length * 100) : 0;
	const streak = streaks(library.cards, now);
	const onFile = async (file) => {
		if (!file) return;
		try {
			const text = await file.text();
			const parsed = parseImportText(text, file.name);
			setPending({
				name: file.name,
				library: parsed
			});
		} catch (error) {
			setNotice(error instanceof Error ? error.message : "That file could not be imported.");
		}
	};
	const runImport = async (mode) => {
		if (!pending) return;
		setBusy(true);
		try {
			if (mode === "replace") await importReplace(pending.library);
			else await importMerge(pending.library);
			setPending(null);
			await navigate({ to: "/decks" });
		} catch (error) {
			setNotice(error instanceof Error ? error.message : "Import failed.");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-[0.16em] text-muted",
			children: "SMALL SESSIONS ADD UP"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl text-fg",
			children: "A little practice, a lot of recall."
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					label: "Total cards",
					value: String(library.cards.length),
					detail: `${library.decks.length} decks`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					label: "Due now",
					value: String(due),
					detail: due ? "Ready when you are" : "All clear"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					label: "Mastery",
					value: `${mastery}%`,
					detail: `${mastered} mastered`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
					label: "Streak",
					value: String(streak.current),
					detail: streak.studiedToday ? "Studied today" : `Best ${streak.longest}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/study",
			className: "flex min-h-12 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink",
			children: due ? `Start studying · ${due} due` : "Open study session"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-lg border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-fg",
					children: "Keep it portable"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Export JSON, or import JSON, CSV, or an Anki text export."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						disabled: Boolean(corruptRaw),
						onClick: () => downloadText(`flashcards-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`, exportJson()),
						children: "Export"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						disabled: Boolean(corruptRaw),
						onClick: () => fileRef.current?.click(),
						children: "Import"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: ".json,.csv,.txt,.tsv,application/json,text/csv,text/plain",
					className: "sr-only",
					onChange: (event) => {
						onFile(event.target.files?.[0]);
						event.target.value = "";
					}
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-lg border border-line bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-fg",
					children: "Daily reminder"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "One notification: how many cards are due."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "switch",
					"aria-checked": reminder.enabled,
					"aria-label": "Daily reminder",
					onClick: () => void toggleReminder(reminder.enabled, reminder.time, setReminder, setNotice),
					className: `relative h-8 w-14 rounded-full ${reminder.enabled ? "bg-primary" : "bg-surface-2"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 h-6 w-6 rounded-full bg-fg ${reminder.enabled ? "right-1" : "left-1"}` })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-xs font-semibold tracking-wide text-muted",
				children: ["Time", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "time",
					value: reminder.time,
					onChange: (event) => void setReminder({
						...reminder,
						time: event.target.value || "09:00"
					}),
					className: "mt-2 w-full rounded-lg border border-line bg-bg px-3 py-3 text-fg"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: Boolean(pending),
			title: "Import cards",
			onClose: () => setPending(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					pending?.name,
					" has ",
					pending?.library.decks.length,
					" decks and ",
					pending?.library.cards.length,
					" cards. Replace wipes this library. Merge adds new cards and skips duplicates."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					onClick: () => void runImport("merge"),
					children: "Merge into library"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					disabled: busy,
					onClick: () => void runImport("replace"),
					children: "Replace everything"
				})]
			})]
		})
	] });
}
async function toggleReminder(enabled, time, setReminder, setNotice) {
	if (!enabled) {
		if (typeof Notification === "undefined") {
			setNotice("This browser can't show notifications.");
			return;
		}
		if (await Notification.requestPermission() !== "granted") {
			setNotice("Notifications stay off until you allow them.");
			return;
		}
	}
	await setReminder({
		enabled: !enabled,
		time
	});
}
function Metric({ label, value, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-3xl tabular-nums text-fg",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: detail
			})
		]
	});
}
function downloadText(filename, text) {
	const blob = new Blob([text], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	anchor.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
//#endregion
export { Home as component };
