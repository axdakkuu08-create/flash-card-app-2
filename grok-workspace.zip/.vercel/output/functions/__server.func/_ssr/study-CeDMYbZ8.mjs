import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as revealCloze, d as isCloze, h as previewIntervalLabel, o as dueQueue, u as hideCloze } from "./flashcards-DY5jnvyq.mjs";
import { r as Route$2 } from "./router-CRcXBGnh.mjs";
import { c as useLibrary, t as AppFrame } from "./shell-BH10JKgo.mjs";
import { t as useNow } from "./use-now-B7ZNXveZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/study-CeDMYbZ8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudyPage() {
	const { deckId } = Route$2.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyBody, { deckId }) });
}
function getDeckTitleSafe(libraryDecks, deckId) {
	return libraryDecks.find((deck) => deck.id === deckId)?.title;
}
function StudyBody({ deckId }) {
	const now = useNow(1e3);
	const navigate = useNavigate();
	const library = useLibrary((state) => state.library);
	const ready = useLibrary((state) => state.ready);
	const rate = useLibrary((state) => state.rate);
	const undo = useLibrary((state) => state.undo);
	const undoRate = useLibrary((state) => state.undoRate);
	const [flippedId, setFlippedId] = (0, import_react.useState)(null);
	const queue = dueQueue(library.cards, now, deckId);
	const item = queue[0];
	const flipped = Boolean(item && flippedId === `${item.card.id}:${item.side}`);
	const deckTitle = deckId ? getDeckTitleSafe(library.decks, deckId) : void 0;
	const toggle = (0, import_react.useCallback)(() => {
		if (!item) return;
		const key = `${item.card.id}:${item.side}`;
		setFlippedId((current) => current === key ? null : key);
	}, [item]);
	const grade = (0, import_react.useCallback)((rating) => {
		if (!item || !flipped) return;
		setFlippedId(null);
		rate(item.card.id, item.side, rating);
	}, [
		flipped,
		item,
		rate
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target && [
				"INPUT",
				"TEXTAREA",
				"SELECT"
			].includes(target.tagName)) return;
			if (event.code === "Space" && item) {
				event.preventDefault();
				toggle();
			} else if (flipped && [
				"1",
				"2",
				"3"
			].includes(event.key)) grade(Number(event.key) - 1);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		flipped,
		grade,
		item,
		toggle
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading your cards…"
	});
	const undoVisible = Boolean(undo && undo.until > now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.16em] text-muted",
				children: "FOCUSED REVIEW"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl text-fg",
					children: "Study"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold tabular-nums text-primary",
					children: [queue.length, " due"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: deckTitle ? deckTitle : deckId ? "That deck is gone" : "All decks"
			})
		] }),
		undoVisible && undo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 rounded-lg border border-line bg-surface px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-fg",
				children: ["Rated ", undo.label]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 px-3 text-sm font-semibold text-primary",
				onClick: () => void undoRate(),
				children: "Undo"
			})]
		}) : null,
		!item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-line bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-fg",
					children: "You're all caught up"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: deckId ? "This deck has nothing due. Other decks may still be waiting." : "Nothing is waiting for review. Add a card, or come back when the next one is due."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-2",
					children: [deckId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink",
						onClick: () => void navigate({ to: "/study" }),
						children: "Study all decks"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/create",
						className: "flex min-h-11 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg",
						children: "Add a flashcard"
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: getDeckTitle(library.decks, item.card.deckId)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold tabular-nums text-primary",
					children: ["1 of ", queue.length]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: toggle,
				"aria-label": flipped ? "Hide the answer" : "Reveal the answer",
				className: "flip-scene w-full text-left",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `flip-card block ${flipped ? "is-flipped" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFace, {
						card: item.card,
						side: item.side,
						revealed: false
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFace, {
						card: item.card,
						side: item.side,
						revealed: true
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					0,
					1,
					2
				].map((rating) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingButton, {
					card: item.card,
					side: item.side,
					rating,
					disabled: !flipped,
					onPress: () => grade(rating)
				}, rating))
			}),
			!flipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted",
				children: "Recall it first. Ratings unlock after the flip."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-muted",
				children: "Space flips · 1 Hard · 2 Good · 3 Easy"
			})
		] })
	] });
}
function CardFace({ card, side, revealed }) {
	const cloze = side === "front" && isCloze(card.front);
	const question = side === "reverse" ? card.back : cloze ? hideCloze(card.front) : card.front;
	const answer = side === "reverse" ? revealCloze(card.front) : cloze ? revealCloze(card.front) : card.back;
	const extra = revealed && side === "front" && cloze ? card.back : null;
	const showImage = Boolean(card.image) && (side === "front" && !revealed || side === "reverse" && revealed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `flip-face flex flex-col rounded-lg border p-5 ${revealed ? "flip-back border-primary bg-surface-2" : "border-line bg-surface"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-semibold tracking-wide text-primary",
				children: revealed ? "ANSWER" : side === "reverse" ? "REVERSE" : cloze ? "CLOZE" : "QUESTION"
			}),
			showImage && card.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: card.image,
				alt: "",
				className: "mt-3 max-h-40 w-full rounded-lg object-contain"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-4 whitespace-pre-wrap text-center text-xl font-semibold leading-snug text-fg",
				children: revealed ? answer : question
			}),
			extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-3 whitespace-pre-wrap text-center text-sm text-muted",
				children: extra
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-auto pt-6 text-center text-xs font-semibold tracking-wide text-muted",
				children: revealed ? "HOW WELL DID YOU REMEMBER?" : "TAP OR PRESS SPACE"
			})
		]
	});
}
function RatingButton({ card, side, rating, disabled, onPress }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		onClick: onPress,
		className: "min-h-20 rounded-lg border border-line bg-surface px-2 py-3 text-left disabled:opacity-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center justify-between text-sm font-semibold text-fg",
			children: [[
				"Hard",
				"Good",
				"Easy"
			][rating], /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: [
					"1",
					"2",
					"3"
				][rating]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-xs text-muted",
			children: previewIntervalLabel(card, side, rating)
		})]
	});
}
function getDeckTitle(decks, deckId) {
	return decks.find((deck) => deck.id === deckId)?.title ?? "Deck";
}
//#endregion
export { StudyPage as component };
