//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B4g78lAr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/create",
			"/decks",
			"/login",
			"/stats",
			"/study",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DySb2Ow6.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-Dq_E1BfH.js",
			"/assets/lazyRouteComponent-CzBkfNKX.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DySb2Ow6.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Ciufsh86.js",
			"/assets/shell-D_Xzw36i.js",
			"/assets/useNavigate-CCvvVGwx.js",
			"/assets/use-now-Cc3Hl5Kg.js"
		]
	},
	"/create": {
		filePath: "/workspace/src/routes/create.tsx",
		children: void 0,
		preloads: [
			"/assets/create-D5zW_rO7.js",
			"/assets/shell-D_Xzw36i.js",
			"/assets/useNavigate-CCvvVGwx.js"
		]
	},
	"/decks": {
		filePath: "/workspace/src/routes/decks.tsx",
		children: ["/decks/$deckId"],
		preloads: [
			"/assets/decks-BEi2lqmG.js",
			"/assets/shell-D_Xzw36i.js",
			"/assets/use-now-Cc3Hl5Kg.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-C6BW2-t8.js", "/assets/shell-D_Xzw36i.js"]
	},
	"/stats": {
		filePath: "/workspace/src/routes/stats.tsx",
		children: void 0,
		preloads: [
			"/assets/stats-DieMk3tE.js",
			"/assets/shell-D_Xzw36i.js",
			"/assets/use-now-Cc3Hl5Kg.js"
		]
	},
	"/study": {
		filePath: "/workspace/src/routes/study.tsx",
		children: void 0,
		preloads: [
			"/assets/study-CHVb5rYy.js",
			"/assets/shell-D_Xzw36i.js",
			"/assets/useNavigate-CCvvVGwx.js",
			"/assets/use-now-Cc3Hl5Kg.js"
		]
	},
	"/decks/$deckId": {
		filePath: "/workspace/src/routes/decks.$deckId.tsx",
		children: void 0,
		preloads: ["/assets/decks._deckId-DGXajF9_.js", "/assets/useNavigate-CCvvVGwx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
