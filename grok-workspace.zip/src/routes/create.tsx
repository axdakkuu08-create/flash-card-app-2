import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ImagePlus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { AppFrame } from "@/components/shell";
import { Button, Field, fieldClass, Notice } from "@/components/ui";
import { compressImage } from "@/lib/image";
import { useLibrary } from "@/lib/library-store";

export const Route = createFileRoute("/create")({
  validateSearch: (search: Record<string, unknown>): { card?: string; deckId?: string } => ({
    card: typeof search.card === "string" ? search.card : undefined,
    deckId: typeof search.deckId === "string" ? search.deckId : undefined,
  }),
  component: CreatePage,
});

function CreatePage() {
  const search = Route.useSearch();
  return (
    <AppFrame>
      <CreateBody cardId={search.card} deckId={search.deckId} />
    </AppFrame>
  );
}

function CreateBody({ cardId, deckId }: { cardId?: string; deckId?: string }) {
  const navigate = useNavigate();
  const library = useLibrary((state) => state.library);
  const ready = useLibrary((state) => state.ready);
  const addCard = useLibrary((state) => state.addCard);
  const updateCard = useLibrary((state) => state.updateCard);
  const existing = library.cards.find((card) => card.id === cardId);
  const [selectedDeck, setSelectedDeck] = useState(deckId ?? existing?.deckId ?? library.decks[0]?.id ?? "");
  const [newDeck, setNewDeck] = useState("");
  const [front, setFront] = useState(existing?.front ?? "");
  const [back, setBack] = useState(existing?.back ?? "");
  const [image, setImage] = useState<string | null>(existing?.image ?? null);
  const [reverse, setReverse] = useState(existing?.reverse ?? false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!existing) return;
    setSelectedDeck(existing.deckId);
    setFront(existing.front);
    setBack(existing.back);
    setImage(existing.image);
    setReverse(existing.reverse);
  }, [existing]);

  useEffect(() => {
    if (existing || selectedDeck || library.decks.length === 0) return;
    const preferred = deckId && library.decks.some((deck) => deck.id === deckId) ? deckId : library.decks[0]?.id;
    if (preferred) setSelectedDeck(preferred);
  }, [deckId, existing, library.decks, selectedDeck]);

  if (!ready) return <p className="text-muted">Loading your cards…</p>;
  if (cardId && !existing) return <Notice tone="error">That card is no longer on this device.</Notice>;

  const save = async () => {
    setBusy(true);
    setError("");
    try {
      if (existing) {
        if (!selectedDeck) throw new Error("Choose a deck.");
        await updateCard(existing.id, { deckId: selectedDeck, front, back, image, reverse });
        await navigate({ to: "/decks/$deckId", params: { deckId: selectedDeck } });
      } else {
        const savedDeck = await addCard({
          deckId: selectedDeck,
          newDeckTitle: newDeck,
          front,
          back,
          image,
          reverse,
        });
        await navigate({ to: "/decks/$deckId", params: { deckId: savedDeck } });
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Couldn't save that card.");
    } finally {
      setBusy(false);
    }
  };

  const wrapSelection = (element: HTMLTextAreaElement) => {
    const start = element.selectionStart ?? 0;
    const end = element.selectionEnd ?? 0;
    if (start === end) {
      setFront((current) => `${current}{{answer}}`);
      return;
    }
    const next = `${front.slice(0, start)}{{${front.slice(start, end)}}}${front.slice(end)}`;
    setFront(next);
  };

  return (
    <>
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-muted">{existing ? "EDIT" : "NEW CARD"}</p>
        <h1 className="mt-2 font-display text-4xl text-fg">{existing ? "Edit card" : "Create a card"}</h1>
      </header>
      {error ? <Notice tone="error">{error}</Notice> : null}
      {existing ? (
        <Field label="Deck">
          <select className={fieldClass} value={selectedDeck} onChange={(event) => setSelectedDeck(event.target.value)}>
            {library.decks.map((deck) => (
              <option key={deck.id} value={deck.id}>
                {deck.title}
              </option>
            ))}
          </select>
        </Field>
      ) : (
        <>
          <Field label="Deck">
            <select className={fieldClass} value={selectedDeck} onChange={(event) => setSelectedDeck(event.target.value)}>
              <option value="">Choose a deck</option>
              {library.decks.map((deck) => (
                <option key={deck.id} value={deck.id}>
                  {deck.title}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Or a new deck name">
            <input className={fieldClass} value={newDeck} onChange={(event) => setNewDeck(event.target.value)} placeholder="Biology · Cell structure" maxLength={120} />
          </Field>
        </>
      )}
      <Field label="Front">
        <textarea
          id="card-front"
          className={`${fieldClass} min-h-28`}
          value={front}
          onChange={(event) => setFront(event.target.value)}
          placeholder="Question, or wrap a hidden word in {{braces}}"
        />
      </Field>
      <button
        type="button"
        className="self-start text-sm font-semibold text-primary"
        onClick={() => {
          const element = document.getElementById("card-front");
          if (element instanceof HTMLTextAreaElement) wrapSelection(element);
        }}
      >
        Make cloze from selection
      </button>
      <Field label="Back">
        <textarea className={`${fieldClass} min-h-28`} value={back} onChange={(event) => setBack(event.target.value)} placeholder="Answer or explanation" />
      </Field>
      <label className="flex min-h-11 items-center justify-between gap-3 rounded-lg border border-line bg-surface px-3">
        <span className="text-sm font-semibold text-fg">Also study in reverse</span>
        <input type="checkbox" checked={reverse} onChange={(event) => setReverse(event.target.checked)} className="size-5 accent-primary" />
      </label>
      <div className="rounded-lg border border-line bg-surface p-3">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm font-semibold text-fg">Image</p>
          <label className="inline-flex min-h-11 cursor-pointer items-center gap-2 text-sm font-semibold text-primary">
            <ImagePlus className="size-4" />
            Add
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                void compressImage(file).then(setImage).catch((caught: unknown) => {
                  setError(caught instanceof Error ? caught.message : "Couldn't read that image.");
                });
              }}
            />
          </label>
        </div>
        {image ? (
          <div className="mt-3">
            <img src={image} alt="" className="max-h-40 w-full rounded-lg object-contain" />
            <button type="button" className="mt-2 inline-flex min-h-11 items-center gap-2 text-sm text-muted" onClick={() => setImage(null)}>
              <Trash2 className="size-4" /> Remove image
            </button>
          </div>
        ) : (
          <p className="mt-2 text-sm text-muted">Optional. Compressed before it's saved.</p>
        )}
      </div>
      <Button disabled={busy} onClick={() => void save()}>
        {busy ? "Saving…" : existing ? "Save changes" : "Save card"}
      </Button>
    </>
  );
}
