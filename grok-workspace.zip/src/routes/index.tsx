import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { AppFrame } from "@/components/shell";
import { Button, Modal } from "@/components/ui";
import { cardStatus, dueQueue, parseImportText, streaks, type Library } from "@/lib/flashcards";
import { useLibrary } from "@/lib/library-store";
import { useNow } from "@/lib/use-now";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <AppFrame>
      <HomeBody />
    </AppFrame>
  );
}

function HomeBody() {
  const now = useNow();
  const navigate = useNavigate();
  const library = useLibrary((state) => state.library);
  const ready = useLibrary((state) => state.ready);
  const reminder = useLibrary((state) => state.reminder);
  const setReminder = useLibrary((state) => state.setReminder);
  const exportJson = useLibrary((state) => state.exportJson);
  const importReplace = useLibrary((state) => state.importReplace);
  const importMerge = useLibrary((state) => state.importMerge);
  const setNotice = useLibrary((state) => state.setNotice);
  const corruptRaw = useLibrary((state) => state.corruptRaw);
  const fileRef = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<{ name: string; library: Library } | null>(null);
  const [busy, setBusy] = useState(false);

  if (!ready) return <p className="text-muted">Loading your cards…</p>;

  const due = dueQueue(library.cards, now).length;
  const mastered = library.cards.filter((card) => cardStatus(card) === "mastered").length;
  const mastery = library.cards.length ? Math.round((mastered / library.cards.length) * 100) : 0;
  const streak = streaks(library.cards, now);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = parseImportText(text, file.name);
      setPending({ name: file.name, library: parsed });
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "That file could not be imported.");
    }
  };

  const runImport = async (mode: "replace" | "merge") => {
    if (!pending) return;
    setBusy(true);
    try {
      if (mode === "replace") await importReplace(pending.library);
      else await importMerge(pending.library);
      setPending(null);
      await navigate({ to: "/decks" });
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Import failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <section>
        <p className="text-xs font-semibold tracking-[0.16em] text-muted">SMALL SESSIONS ADD UP</p>
        <h1 className="mt-2 font-display text-4xl text-fg">A little practice, a lot of recall.</h1>
      </section>
      <div className="grid grid-cols-2 gap-3">
        <Metric label="Total cards" value={String(library.cards.length)} detail={`${library.decks.length} decks`} />
        <Metric label="Due now" value={String(due)} detail={due ? "Ready when you are" : "All clear"} />
        <Metric label="Mastery" value={`${mastery}%`} detail={`${mastered} mastered`} />
        <Metric label="Streak" value={String(streak.current)} detail={streak.studiedToday ? "Studied today" : `Best ${streak.longest}`} />
      </div>
      <Link
        to="/study"
        className="flex min-h-12 items-center justify-center rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink"
      >
        {due ? `Start studying · ${due} due` : "Open study session"}
      </Link>
      <section className="rounded-lg border border-line bg-surface p-4">
        <h2 className="font-display text-2xl text-fg">Keep it portable</h2>
        <p className="mt-1 text-sm text-muted">Export JSON, or import JSON, CSV, or an Anki text export.</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <Button
            variant="ghost"
            disabled={Boolean(corruptRaw)}
            onClick={() => downloadText(`flashcards-backup-${new Date().toISOString().slice(0, 10)}.json`, exportJson())}
          >
            Export
          </Button>
          <Button variant="ghost" disabled={Boolean(corruptRaw)} onClick={() => fileRef.current?.click()}>
            Import
          </Button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept=".json,.csv,.txt,.tsv,application/json,text/csv,text/plain"
          className="sr-only"
          onChange={(event) => {
            void onFile(event.target.files?.[0]);
            event.target.value = "";
          }}
        />
      </section>
      <section className="rounded-lg border border-line bg-surface p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl text-fg">Daily reminder</h2>
            <p className="mt-1 text-sm text-muted">One notification: how many cards are due.</p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={reminder.enabled}
            aria-label="Daily reminder"
            onClick={() => void toggleReminder(reminder.enabled, reminder.time, setReminder, setNotice)}
            className={`relative h-8 w-14 rounded-full ${reminder.enabled ? "bg-primary" : "bg-surface-2"}`}
          >
            <span className={`absolute top-1 h-6 w-6 rounded-full bg-fg ${reminder.enabled ? "right-1" : "left-1"}`} />
          </button>
        </div>
        <label className="mt-4 block text-xs font-semibold tracking-wide text-muted">
          Time
          <input
            type="time"
            value={reminder.time}
            onChange={(event) => void setReminder({ ...reminder, time: event.target.value || "09:00" })}
            className="mt-2 w-full rounded-lg border border-line bg-bg px-3 py-3 text-fg"
          />
        </label>
      </section>
      <Modal open={Boolean(pending)} title="Import cards" onClose={() => setPending(null)}>
        <p className="text-sm text-muted">
          {pending?.name} has {pending?.library.decks.length} decks and {pending?.library.cards.length} cards. Replace wipes this library. Merge adds new cards and skips duplicates.
        </p>
        <div className="mt-4 flex flex-col gap-2">
          <Button disabled={busy} onClick={() => void runImport("merge")}>
            Merge into library
          </Button>
          <Button variant="ghost" disabled={busy} onClick={() => void runImport("replace")}>
            Replace everything
          </Button>
        </div>
      </Modal>
    </>
  );
}

async function toggleReminder(
  enabled: boolean,
  time: string,
  setReminder: (reminder: { enabled: boolean; time: string }) => Promise<void>,
  setNotice: (notice: string | null) => void,
) {
  if (!enabled) {
    if (typeof Notification === "undefined") {
      setNotice("This browser can't show notifications.");
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      setNotice("Notifications stay off until you allow them.");
      return;
    }
  }
  await setReminder({ enabled: !enabled, time });
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-lg border border-line bg-surface p-4">
      <p className="text-xs font-semibold tracking-wide text-muted">{label}</p>
      <p className="mt-2 font-display text-3xl tabular-nums text-fg">{value}</p>
      <p className="mt-1 text-sm text-muted">{detail}</p>
    </div>
  );
}

function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
