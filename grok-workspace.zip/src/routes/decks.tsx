import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { useMemo, useState } from "react";
import { AppFrame } from "@/components/shell";
import { fieldClass } from "@/components/ui";
import { cardStatus, dueQueue } from "@/lib/flashcards";
import { useLibrary } from "@/lib/library-store";
import { useNow } from "@/lib/use-now";

export const Route = createFileRoute("/decks")({
  component: DecksPage,
});

function DecksPage() {
  return (
    <AppFrame>
      <DecksBody />
    </AppFrame>
  );
}

function DecksBody() {
  const now = useNow();
  const library = useLibrary((state) => state.library);
  const ready = useLibrary((state) => state.ready);
  const [query, setQuery] = useState("");
  const decks = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return library.decks.filter((deck) => deck.title.toLowerCase().includes(needle));
  }, [library.decks, query]);

  if (!ready) return <p className="text-muted">Loading your cards…</p>;

  return (
    <>
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-muted">YOUR COLLECTION</p>
        <h1 className="mt-2 font-display text-4xl text-fg">Decks</h1>
        <p className="mt-1 text-sm text-muted">{library.decks.length} stored with your account</p>
      </header>
      <div className="flex items-center gap-2 rounded-lg border border-line bg-bg px-3">
        <Search className="size-4 text-muted" />
        <input
          aria-label="Search decks"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search your decks"
          className={`${fieldClass} border-0 bg-transparent px-0`}
        />
        {query ? (
          <button type="button" aria-label="Clear search" onClick={() => setQuery("")} className="grid h-11 w-11 place-items-center text-muted">
            <X className="size-4" />
          </button>
        ) : null}
      </div>
      {decks.length === 0 ? (
        <div className="rounded-lg border border-line bg-surface p-5">
          <h2 className="font-display text-2xl text-fg">{query ? "No matching decks" : "Your first deck is waiting"}</h2>
          <p className="mt-2 text-sm text-muted">{query ? "Try a different search." : "Create a card and give it a home."}</p>
          {!query ? (
            <Link to="/create" className="mt-4 flex min-h-11 items-center justify-center rounded-lg bg-primary text-sm font-semibold text-primary-ink">
              Create a card
            </Link>
          ) : null}
        </div>
      ) : (
        <ul className="flex flex-col gap-3">
          {decks.map((deck) => {
            const cards = library.cards.filter((card) => card.deckId === deck.id);
            const due = dueQueue(cards, now).length;
            const mastered = cards.filter((card) => cardStatus(card) === "mastered").length;
            return (
              <li key={deck.id} className="rounded-lg border border-line bg-surface p-4">
                <Link to="/decks/$deckId" params={{ deckId: deck.id }} className="block">
                  <h2 className="font-display text-2xl text-fg">{deck.title}</h2>
                  <p className="mt-1 text-sm text-muted">
                    {cards.length} cards · {due} due · {mastered} mastered
                  </p>
                </Link>
                <Link
                  to="/study"
                  search={{ deckId: deck.id }}
                  className="mt-3 flex min-h-11 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg"
                >
                  Study
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
