import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { AppFrame } from "@/components/shell";
import { dueQueue, hideCloze, isCloze, previewIntervalLabel, revealCloze, type Card, type Rating, type Side } from "@/lib/flashcards";
import { useLibrary } from "@/lib/library-store";
import { useNow } from "@/lib/use-now";

export const Route = createFileRoute("/study")({
  validateSearch: (search: Record<string, unknown>): { deckId?: string } => ({
    deckId: typeof search.deckId === "string" ? search.deckId : undefined,
  }),
  component: StudyPage,
});

function StudyPage() {
  const { deckId } = Route.useSearch();
  return (
    <AppFrame>
      <StudyBody deckId={deckId} />
    </AppFrame>
  );
}

function getDeckTitleSafe(libraryDecks: { id: string; title: string }[], deckId: string) {
  return libraryDecks.find((deck) => deck.id === deckId)?.title;
}

function StudyBody({ deckId }: { deckId?: string }) {
  const now = useNow(1000);
  const navigate = useNavigate();
  const library = useLibrary((state) => state.library);
  const ready = useLibrary((state) => state.ready);
  const rate = useLibrary((state) => state.rate);
  const undo = useLibrary((state) => state.undo);
  const undoRate = useLibrary((state) => state.undoRate);
  const [flippedId, setFlippedId] = useState<string | null>(null);
  const queue = dueQueue(library.cards, now, deckId);
  const item = queue[0];
  const flipped = Boolean(item && flippedId === `${item.card.id}:${item.side}`);
  const deckTitle = deckId ? getDeckTitleSafe(library.decks, deckId) : undefined;

  const toggle = useCallback(() => {
    if (!item) return;
    const key = `${item.card.id}:${item.side}`;
    setFlippedId((current) => (current === key ? null : key));
  }, [item]);

  const grade = useCallback(
    (rating: Rating) => {
      if (!item || !flipped) return;
      setFlippedId(null);
      void rate(item.card.id, item.side, rating);
    },
    [flipped, item, rate],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (event.code === "Space" && item) {
        event.preventDefault();
        toggle();
      } else if (flipped && ["1", "2", "3"].includes(event.key)) {
        grade((Number(event.key) - 1) as Rating);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [flipped, grade, item, toggle]);

  if (!ready) return <p className="text-muted">Loading your cards…</p>;

  const undoVisible = Boolean(undo && undo.until > now);

  return (
    <>
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-muted">FOCUSED REVIEW</p>
        <div className="mt-2 flex items-end justify-between gap-3">
          <h1 className="font-display text-4xl text-fg">Study</h1>
          <p className="text-sm font-semibold tabular-nums text-primary">{queue.length} due</p>
        </div>
        <p className="mt-1 text-sm text-muted">{deckTitle ? deckTitle : deckId ? "That deck is gone" : "All decks"}</p>
      </header>

      {undoVisible && undo ? (
        <div className="flex items-center justify-between gap-3 rounded-lg border border-line bg-surface px-3 py-2">
          <p className="text-sm text-fg">Rated {undo.label}</p>
          <button type="button" className="min-h-11 px-3 text-sm font-semibold text-primary" onClick={() => void undoRate()}>
            Undo
          </button>
        </div>
      ) : null}

      {!item ? (
        <div className="rounded-lg border border-line bg-surface p-5">
          <h2 className="font-display text-2xl text-fg">You're all caught up</h2>
          <p className="mt-2 text-sm text-muted">
            {deckId
              ? "This deck has nothing due. Other decks may still be waiting."
              : "Nothing is waiting for review. Add a card, or come back when the next one is due."}
          </p>
          <div className="mt-4 flex flex-col gap-2">
            {deckId ? (
              <button type="button" className="min-h-11 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink" onClick={() => void navigate({ to: "/study" })}>
                Study all decks
              </button>
            ) : null}
            <Link to="/create" className="flex min-h-11 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg">
              Add a flashcard
            </Link>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between text-sm">
            <p className="text-muted">{getDeckTitle(library.decks, item.card.deckId)}</p>
            <p className="font-semibold tabular-nums text-primary">1 of {queue.length}</p>
          </div>
          <button
            type="button"
            onClick={toggle}
            aria-label={flipped ? "Hide the answer" : "Reveal the answer"}
            className="flip-scene w-full text-left"
          >
            <span className={`flip-card block ${flipped ? "is-flipped" : ""}`}>
              <CardFace card={item.card} side={item.side} revealed={false} />
              <CardFace card={item.card} side={item.side} revealed />
            </span>
          </button>
          <div className="grid grid-cols-3 gap-2">
            {([0, 1, 2] as const).map((rating) => (
              <RatingButton key={rating} card={item.card} side={item.side} rating={rating} disabled={!flipped} onPress={() => grade(rating)} />
            ))}
          </div>
          {!flipped ? <p className="text-center text-sm text-muted">Recall it first. Ratings unlock after the flip.</p> : null}
          <p className="text-center text-xs text-muted">Space flips · 1 Hard · 2 Good · 3 Easy</p>
        </>
      )}
    </>
  );
}

function CardFace({ card, side, revealed }: { card: Card; side: Side; revealed: boolean }) {
  const cloze = side === "front" && isCloze(card.front);
  const question = side === "reverse" ? card.back : cloze ? hideCloze(card.front) : card.front;
  const answer = side === "reverse" ? revealCloze(card.front) : cloze ? revealCloze(card.front) : card.back;
  const extra = revealed && side === "front" && cloze ? card.back : null;
  const showImage = Boolean(card.image) && ((side === "front" && !revealed) || (side === "reverse" && revealed));
  return (
    <span className={`flip-face flex flex-col rounded-lg border p-5 ${revealed ? "flip-back border-primary bg-surface-2" : "border-line bg-surface"}`}>
      <span className="text-xs font-semibold tracking-wide text-primary">{revealed ? "ANSWER" : side === "reverse" ? "REVERSE" : cloze ? "CLOZE" : "QUESTION"}</span>
      {showImage && card.image ? <img src={card.image} alt="" className="mt-3 max-h-40 w-full rounded-lg object-contain" /> : null}
      <span className="mt-4 whitespace-pre-wrap text-center text-xl font-semibold leading-snug text-fg">{revealed ? answer : question}</span>
      {extra ? <span className="mt-3 whitespace-pre-wrap text-center text-sm text-muted">{extra}</span> : null}
      <span className="mt-auto pt-6 text-center text-xs font-semibold tracking-wide text-muted">{revealed ? "HOW WELL DID YOU REMEMBER?" : "TAP OR PRESS SPACE"}</span>
    </span>
  );
}

function RatingButton({
  card,
  side,
  rating,
  disabled,
  onPress,
}: {
  card: Card;
  side: Side;
  rating: Rating;
  disabled: boolean;
  onPress: () => void;
}) {
  const labels = ["Hard", "Good", "Easy"] as const;
  const keys = ["1", "2", "3"] as const;
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onPress}
      className="min-h-20 rounded-lg border border-line bg-surface px-2 py-3 text-left disabled:opacity-40"
    >
      <span className="flex items-center justify-between text-sm font-semibold text-fg">
        {labels[rating]}
        <span className="text-xs text-muted">{keys[rating]}</span>
      </span>
      <span className="mt-1 block text-xs text-muted">{previewIntervalLabel(card, side, rating)}</span>
    </button>
  );
}

function getDeckTitle(decks: { id: string; title: string }[], deckId: string) {
  return decks.find((deck) => deck.id === deckId)?.title ?? "Deck";
}
