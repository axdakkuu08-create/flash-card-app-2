import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, XAxis } from "recharts";
import { AppFrame } from "@/components/shell";
import { countByStatus, forecast, streaks } from "@/lib/flashcards";
import { useLibrary } from "@/lib/library-store";
import { useNow } from "@/lib/use-now";

export const Route = createFileRoute("/stats")({
  component: StatsPage,
});

function StatsPage() {
  return (
    <AppFrame>
      <StatsBody />
    </AppFrame>
  );
}

function StatsBody() {
  const now = useNow();
  const library = useLibrary((state) => state.library);
  const ready = useLibrary((state) => state.ready);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const counts = useMemo(() => countByStatus(library.cards), [library.cards]);
  const ahead = useMemo(() => forecast(library.cards, now), [library.cards, now]);
  const streak = useMemo(() => streaks(library.cards, now), [library.cards, now]);
  const reviews = library.cards.reduce((total, card) => total + card.reviewHistory.length, 0);

  if (!ready) return <p className="text-muted">Loading your cards…</p>;

  const mastery = library.cards.length ? Math.round((counts.mastered / library.cards.length) * 100) : 0;

  return (
    <>
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-muted">A CLEARER PICTURE</p>
        <h1 className="mt-2 font-display text-4xl text-fg">Your progress</h1>
      </header>
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Mastered" value={counts.mastered} />
        <Stat label="Learning" value={counts.learning} />
        <Stat label="Needs review" value={counts.review} />
        <Stat label="Reviews" value={reviews} />
      </div>
      <section className="rounded-lg border border-line bg-surface p-4">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold tracking-wide text-muted">STREAK</p>
            <p className="font-display text-3xl tabular-nums text-fg">{streak.current} days</p>
          </div>
          <p className="text-sm text-muted">Longest {streak.longest}</p>
        </div>
        <p className="mt-3 text-sm text-muted">{mastery}% of cards mastered</p>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-bg">
          <div className="h-full bg-primary" style={{ width: `${mastery}%` }} />
        </div>
      </section>
      <section className="rounded-lg border border-line bg-surface p-4">
        <h2 className="font-display text-2xl text-fg">Coming up</h2>
        <p className="mt-1 text-sm text-muted">
          {ahead.tomorrow} due tomorrow · {ahead.week} in the next 7 days. Due now is separate.
        </p>
        <div className="mt-4 h-40">
          {mounted ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ahead.days}>
                <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Bar dataKey="count" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : null}
        </div>
      </section>
      <section className="flex flex-col gap-3">
        <h2 className="font-display text-2xl text-fg">Deck by deck</h2>
        {library.decks.length === 0 ? <p className="text-sm text-muted">Create a deck to see it here.</p> : null}
        {library.decks.map((deck) => {
          const cards = library.cards.filter((card) => card.deckId === deck.id);
          const breakdown = countByStatus(cards);
          const history = cards.reduce((total, card) => total + card.reviewHistory.length, 0);
          const percent = cards.length ? Math.round((breakdown.mastered / cards.length) * 100) : 0;
          return (
            <article key={deck.id} className="rounded-lg border border-line bg-surface p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-semibold text-fg">{deck.title}</h3>
                  <p className="text-sm text-muted">
                    {cards.length} cards · {history} reviews
                  </p>
                </div>
                <p className="text-sm font-semibold tabular-nums text-primary">{percent}%</p>
              </div>
              <p className="mt-3 text-sm text-muted">
                {breakdown.mastered} mastered · {breakdown.learning} learning · {breakdown.review} need review
              </p>
            </article>
          );
        })}
      </section>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg border border-line bg-surface p-4">
      <p className="text-xs font-semibold tracking-wide text-muted">{label}</p>
      <p className="mt-2 font-display text-3xl tabular-nums text-fg">{value}</p>
    </div>
  );
}
