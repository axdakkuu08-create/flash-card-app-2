import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppFrame } from "@/components/shell";
import { Button, fieldClass, Modal } from "@/components/ui";
import { cardStatus, dueLabel, hideCloze, isCloze, statusLabel } from "@/lib/flashcards";
import { useLibrary } from "@/lib/library-store";
import { useNow } from "@/lib/use-now";

export const Route = createFileRoute("/decks/$deckId")({
  component: DeckPage,
});

function DeckPage() {
  const { deckId } = Route.useParams();
  return (
    <AppFrame>
      <DeckBody deckId={deckId} />
    </AppFrame>
  );
}

function DeckBody({ deckId }: { deckId: string }) {
  const now = useNow();
  const navigate = useNavigate();
  const library = useLibrary((state) => state.library);
  const ready = useLibrary((state) => state.ready);
  const renameDeck = useLibrary((state) => state.renameDeck);
  const deleteDeck = useLibrary((state) => state.deleteDeck);
  const deleteCard = useLibrary((state) => state.deleteCard);
  const deck = library.decks.find((item) => item.id === deckId);
  const cards = library.cards.filter((card) => card.deckId === deckId);
  const [title, setTitle] = useState("");
  const [named, setNamed] = useState(false);
  const [error, setError] = useState("");
  const [confirmDeck, setConfirmDeck] = useState(false);
  const [pendingCard, setPendingCard] = useState<string | null>(null);

  useEffect(() => {
    if (!deck || named) return;
    setTitle(deck.title);
    setNamed(true);
  }, [deck, named]);

  if (!ready) return <p className="text-muted">Loading your cards…</p>;
  if (!deck) {
    return (
      <div className="rounded-lg border border-line bg-surface p-5">
        <h1 className="font-display text-3xl text-fg">Deck not found</h1>
        <Link to="/decks" className="mt-4 inline-flex min-h-11 items-center text-sm font-semibold text-primary">
          Back to decks
        </Link>
      </div>
    );
  }

  return (
    <>
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-muted">DECK</p>
        <h1 className="mt-2 font-display text-4xl text-fg">{deck.title}</h1>
      </header>
      <form
        className="flex flex-col gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          setError("");
          void renameDeck(deck.id, title).catch((caught: unknown) => {
            setError(caught instanceof Error ? caught.message : "Couldn't rename that deck.");
          });
        }}
      >
        <label className="text-xs font-semibold tracking-wide text-muted" htmlFor="deck-name">
          Name
        </label>
        <div className="flex gap-2">
          <input id="deck-name" className={fieldClass} value={title} maxLength={120} onChange={(event) => setTitle(event.target.value)} />
          <Button type="submit" variant="ghost" className="shrink-0">
            Rename
          </Button>
        </div>
        {error ? <p className="text-sm text-fg">{error}</p> : null}
      </form>
      <div className="grid grid-cols-2 gap-2">
        <Link to="/study" search={{ deckId: deck.id }} className="flex min-h-11 items-center justify-center rounded-lg bg-primary text-sm font-semibold text-primary-ink">
          Study this deck
        </Link>
        <Link to="/create" search={{ deckId: deck.id }} className="flex min-h-11 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg">
          Add a card
        </Link>
      </div>
      {cards.length === 0 ? (
        <p className="rounded-lg border border-line bg-surface p-4 text-sm text-muted">This deck has no cards yet.</p>
      ) : (
        <ul className="flex flex-col gap-3">
          {cards.map((card) => {
            const status = cardStatus(card);
            const front = isCloze(card.front) ? hideCloze(card.front) : card.front;
            return (
              <li key={card.id} className="rounded-lg border border-line bg-surface p-4">
                <p className="whitespace-pre-wrap text-base font-semibold text-fg">{front}</p>
                <p className="mt-2 text-sm text-muted">
                  {statusLabel(status)} · {dueLabel(card.nextReview, now)}
                  {card.reverse ? " · Reverse on" : ""}
                </p>
                <div className="mt-3 flex gap-2">
                  <Link to="/create" search={{ card: card.id }} className="flex min-h-11 flex-1 items-center justify-center rounded-lg border border-line text-sm font-semibold text-fg">
                    Edit
                  </Link>
                  <button type="button" className="min-h-11 flex-1 rounded-lg border border-line text-sm font-semibold text-fg" onClick={() => setPendingCard(card.id)}>
                    Delete
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <button type="button" className="text-sm font-semibold text-muted" onClick={() => setConfirmDeck(true)}>
        Delete this deck and its cards
      </button>
      <Modal open={confirmDeck} title="Delete deck?" onClose={() => setConfirmDeck(false)}>
        <p className="text-sm text-muted">“{deck.title}” and every card in it will be removed from this device and your account.</p>
        <Button
          className="mt-4 w-full"
          onClick={() => {
            void deleteDeck(deck.id).then(() => navigate({ to: "/decks" }));
          }}
        >
          Delete deck
        </Button>
      </Modal>
      <Modal open={Boolean(pendingCard)} title="Delete card?" onClose={() => setPendingCard(null)}>
        <p className="text-sm text-muted">This removes one card and its review history.</p>
        <Button
          className="mt-4 w-full"
          onClick={() => {
            if (!pendingCard) return;
            void deleteCard(pendingCard);
            setPendingCard(null);
          }}
        >
          Delete card
        </Button>
      </Modal>
    </>
  );
}
