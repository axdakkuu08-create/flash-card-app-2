import { createFileRoute } from "@tanstack/react-router";
import { SignInPanel } from "@/components/shell";

export const Route = createFileRoute("/login")({
  component: SignInPanel,
});
