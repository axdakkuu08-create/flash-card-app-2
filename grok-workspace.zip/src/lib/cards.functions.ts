import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { validateData, type Library } from "@/lib/flashcards";

export type Reminder = { enabled: boolean; time: string };

function asText(value: unknown): string {
  if (typeof value === "string") return value;
  if (value == null) return "";
  return String(value);
}

function asIso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value) return value;
  return new Date().toISOString();
}

function cleanTime(value: unknown): string {
  if (typeof value !== "string") return "09:00";
  const match = /^(\d{2}):(\d{2})$/.exec(value);
  if (!match) return "09:00";
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) return "09:00";
  return value;
}

export const getLibrary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ library: Library; updatedAt: string } | null> => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql<{ payload: unknown; updated_at: unknown }>`
      select payload, updated_at from flashcard_libraries where user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) return null;
    const library = validateData(JSON.parse(asText(row.payload)) as unknown);
    return { library, updatedAt: asIso(row.updated_at) };
  });

export const saveLibrary = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => validateData(input))
  .handler(async ({ context, data }) => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const payload = JSON.stringify(data);
    await sql`
      insert into flashcard_libraries (user_id, payload)
      values (${context.userId}, ${payload})
      on conflict (user_id) do update
      set payload = excluded.payload, updated_at = now()
    `;
    return { ok: true as const, updatedAt: new Date().toISOString() };
  });

export const getReminder = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Reminder> => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql<{ enabled: unknown; remind_time: unknown }>`
      select enabled, remind_time from flashcard_reminders where user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) return { enabled: false, time: "09:00" };
    return { enabled: row.enabled === true || row.enabled === 1 || row.enabled === "t" || row.enabled === "true", time: cleanTime(row.remind_time) };
  });

export const saveReminder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown): Reminder => {
    const record = typeof input === "object" && input !== null ? (input as Record<string, unknown>) : {};
    return { enabled: record.enabled === true, time: cleanTime(record.time) };
  })
  .handler(async ({ context, data }) => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    await sql`
      insert into flashcard_reminders (user_id, enabled, remind_time)
      values (${context.userId}, ${data.enabled}, ${data.time})
      on conflict (user_id) do update
      set enabled = excluded.enabled, remind_time = excluded.remind_time
    `;
    return data;
  });
