import { create } from "zustand";
import { getLibrary, getReminder, saveLibrary, saveReminder, type Reminder } from "@/lib/cards.functions";
import {
  createInitialData,
  duplicateTitle,
  emptyLibrary,
  makeId,
  mergeLibraries,
  rateCard,
  serializeBackup,
  validateData,
  type Card,
  type Library,
  type Side,
} from "@/lib/flashcards";

const STORAGE_KEY = "flashcards-offline-data-v3";
const REMINDER_KEY = "flashcards-reminder-v3";

type UndoState = {
  until: number;
  before: Card;
  label: string;
};

type Envelope = { v: 3; dirty: boolean; library: Library };

export type LibraryState = {
  ready: boolean;
  syncing: boolean;
  offline: boolean;
  dirty: boolean;
  error: string | null;
  notice: string | null;
  corruptRaw: string | null;
  library: Library;
  userId: string | null;
  lastSyncedAt: number | null;
  reminder: Reminder;
  undo: UndoState | null;
  bootstrap: (userId: string) => Promise<void>;
  sync: () => Promise<void>;
  setNotice: (notice: string | null) => void;
  addCard: (input: {
    deckId?: string;
    newDeckTitle?: string;
    front: string;
    back: string;
    image: string | null;
    reverse: boolean;
  }) => Promise<string>;
  updateCard: (cardId: string, input: { deckId: string; front: string; back: string; image: string | null; reverse: boolean }) => Promise<void>;
  renameDeck: (deckId: string, title: string) => Promise<void>;
  deleteDeck: (deckId: string) => Promise<void>;
  deleteCard: (cardId: string) => Promise<void>;
  rate: (cardId: string, side: Side, rating: 0 | 1 | 2) => Promise<void>;
  undoRate: () => Promise<void>;
  importReplace: (library: Library) => Promise<void>;
  importMerge: (incoming: Library) => Promise<string>;
  exportJson: () => string;
  startFresh: () => Promise<void>;
  adoptAccountLibrary: () => Promise<void>;
  setReminder: (reminder: Reminder) => Promise<void>;
};

function readEnvelope(): { kind: "empty" } | { kind: "ok"; library: Library; dirty: boolean } | { kind: "corrupt"; raw: string } {
  if (typeof localStorage === "undefined") return { kind: "empty" };
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return { kind: "empty" };
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (typeof parsed === "object" && parsed !== null && "library" in parsed) {
      const envelope = parsed as Envelope;
      return { kind: "ok", library: validateData(envelope.library), dirty: envelope.dirty === true };
    }
    return { kind: "ok", library: validateData(parsed), dirty: false };
  } catch {
    return { kind: "corrupt", raw };
  }
}

function writeEnvelope(library: Library, dirty: boolean) {
  const envelope: Envelope = { v: 3, dirty, library };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(envelope));
}

function readReminder(): Reminder {
  try {
    const raw = localStorage.getItem(REMINDER_KEY);
    if (!raw) return { enabled: false, time: "09:00" };
    const parsed = JSON.parse(raw) as Reminder;
    return {
      enabled: parsed.enabled === true,
      time: /^\d{2}:\d{2}$/.test(parsed.time) ? parsed.time : "09:00",
    };
  } catch {
    return { enabled: false, time: "09:00" };
  }
}

function messageOf(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong.";
}

function isNetwork(error: unknown): boolean {
  const message = messageOf(error).toLowerCase();
  return error instanceof TypeError || /fetch|network|failed to|load failed|offline|timeout/.test(message);
}

async function pushLibrary(library: Library) {
  await saveLibrary({ data: library });
}

async function runBootstrap(userId: string, set: (partial: Partial<LibraryState>) => void) {
  const local = readEnvelope();
  const reminder = readReminder();
  if (local.kind === "corrupt") {
    set({
      ready: true,
      userId,
      corruptRaw: local.raw,
      library: emptyLibrary(),
      dirty: false,
      reminder,
      error: "The copy saved on this device can't be read. It was left untouched.",
    });
    try {
      const remoteReminder = await getReminder();
      localStorage.setItem(REMINDER_KEY, JSON.stringify(remoteReminder));
      set({ reminder: remoteReminder });
    } catch {
      /* reminder can wait */
    }
    return;
  }

  let library = local.kind === "ok" ? local.library : emptyLibrary();
  let dirty = local.kind === "ok" ? local.dirty : false;
  set({ userId, library, dirty, corruptRaw: null, reminder, ready: false, error: null });

  try {
    set({ syncing: true });
    if (local.kind === "ok" && dirty) await pushLibrary(library);
    const remote = await getLibrary();
    if (!remote) {
      if (local.kind === "empty" || !library.initialized) library = createInitialData();
      await pushLibrary(library);
    } else if (!(local.kind === "ok" && dirty)) {
      library = remote.library;
    }
    writeEnvelope(library, false);
    const remoteReminder = await getReminder();
    localStorage.setItem(REMINDER_KEY, JSON.stringify(remoteReminder));
    set({
      library,
      dirty: false,
      offline: false,
      syncing: false,
      ready: true,
      lastSyncedAt: Date.now(),
      reminder: remoteReminder,
      error: null,
    });
  } catch (error) {
    if (local.kind === "empty") {
      library = createInitialData();
      dirty = true;
      writeEnvelope(library, true);
    }
    set({
      library,
      dirty,
      ready: true,
      syncing: false,
      offline: true,
      error: isNetwork(error) ? null : messageOf(error),
    });
  }
}

let bootPromise: Promise<void> | null = null;
let bootUser: string | null = null;

export const useLibrary = create<LibraryState>((set, get) => ({
  ready: false,
  syncing: false,
  offline: false,
  dirty: false,
  error: null,
  notice: null,
  corruptRaw: null,
  library: emptyLibrary(),
  userId: null,
  lastSyncedAt: null,
  reminder: { enabled: false, time: "09:00" },
  undo: null,

  setNotice: (notice) => set({ notice }),

  bootstrap: (userId) => {
    if (bootUser === userId && bootPromise) return bootPromise;
    bootUser = userId;
    bootPromise = runBootstrap(userId, set);
    return bootPromise;
  },

  sync: async () => {
    const { userId, library, dirty, corruptRaw } = get();
    if (!userId || corruptRaw) return;
    set({ syncing: true, error: null });
    try {
      if (dirty) await pushLibrary(library);
      const remote = await getLibrary();
      const next = remote?.library ?? library;
      if (!remote) await pushLibrary(next);
      writeEnvelope(next, false);
      set({ library: next, dirty: false, offline: false, syncing: false, lastSyncedAt: Date.now() });
    } catch (error) {
      set({
        syncing: false,
        offline: true,
        error: isNetwork(error) ? null : messageOf(error),
      });
    }
  },

  addCard: async (input) => {
    const title = input.newDeckTitle?.trim() ?? "";
    const front = input.front.trim();
    const back = input.back.trim();
    if (!front || !back) throw new Error("Enter both the front and the back of the card.");
    let deckId = input.deckId;
    const now = Date.now();
    const cardId = makeId("card");
    await commit((library) => {
      const decks = [...library.decks];
      if (title) {
        if (duplicateTitle(decks, title)) throw new Error("A deck with that name already exists. Pick it from the list.");
        deckId = makeId("deck");
        decks.push({ id: deckId, title, createdAt: now });
      }
      if (!deckId || !decks.some((deck) => deck.id === deckId)) {
        throw new Error("Choose an existing deck or enter a new deck name.");
      }
      const scheduleNow = now;
      const card: Card = {
        id: cardId,
        deckId,
        front,
        back,
        image: input.image,
        reverse: input.reverse,
        mastery: 0,
        repetitions: 0,
        intervalDays: 0,
        easeFactor: 2.5,
        nextReview: scheduleNow,
        revMastery: 0,
        revRepetitions: 0,
        revIntervalDays: 0,
        revEaseFactor: 2.5,
        revNextReview: scheduleNow,
        createdAt: scheduleNow,
        reviewHistory: [],
      };
      return { initialized: true, decks, cards: [...library.cards, card] };
    }, "Card saved on this device.");
    return deckId ?? "";
  },

  updateCard: async (cardId, input) => {
    const front = input.front.trim();
    const back = input.back.trim();
    if (!front || !back) throw new Error("Enter both the front and the back of the card.");
    await commit((library) => {
      if (!library.decks.some((deck) => deck.id === input.deckId)) throw new Error("Choose a deck.");
      return {
        ...library,
        initialized: true,
        cards: library.cards.map((card) =>
          card.id === cardId ? { ...card, deckId: input.deckId, front, back, image: input.image, reverse: input.reverse } : card,
        ),
      };
    }, "Card updated.");
  },

  renameDeck: async (deckId, title) => {
    const nextTitle = title.trim();
    if (!nextTitle) throw new Error("A deck needs a name.");
    await commit((library) => {
      if (duplicateTitle(library.decks, nextTitle, deckId)) throw new Error("A deck with that name already exists.");
      return {
        ...library,
        decks: library.decks.map((deck) => (deck.id === deckId ? { ...deck, title: nextTitle.slice(0, 120) } : deck)),
      };
    }, "Deck renamed.");
  },

  deleteDeck: async (deckId) => {
    await commit(
      (library) => ({
        ...library,
        decks: library.decks.filter((deck) => deck.id !== deckId),
        cards: library.cards.filter((card) => card.deckId !== deckId),
      }),
      "Deck deleted.",
    );
  },

  deleteCard: async (cardId) => {
    await commit(
      (library) => ({ ...library, cards: library.cards.filter((card) => card.id !== cardId) }),
      "Card deleted.",
    );
  },

  rate: async (cardId, side, rating) => {
    const current = get().library.cards.find((card) => card.id === cardId);
    if (!current) return;
    const labels = ["Hard", "Good", "Easy"] as const;
    set({ undo: { until: Date.now() + 8000, before: current, label: labels[rating] } });
    await commit((library) => ({
      ...library,
      cards: library.cards.map((card) => (card.id === cardId ? rateCard(card, side, rating) : card)),
    }));
  },

  undoRate: async () => {
    const undo = get().undo;
    if (!undo || undo.until < Date.now()) {
      set({ undo: null });
      return;
    }
    await commit((library) => ({
      ...library,
      cards: library.cards.map((card) => (card.id === undo.before.id ? undo.before : card)),
    }), "Last rating undone.");
    set({ undo: null });
  },

  importReplace: async (library) => {
    const next = validateData({ ...library, initialized: true });
    await commit(() => next, "Backup restored. Your library was replaced.");
  },

  importMerge: async (incoming) => {
    let summary = "";
    await commit((library) => {
      const merged = mergeLibraries(library, incoming);
      summary = `Merged ${merged.addedCards} ${merged.addedCards === 1 ? "card" : "cards"} and ${merged.addedDecks} ${merged.addedDecks === 1 ? "deck" : "decks"}. Skipped ${merged.skippedCards} duplicates.`;
      return merged.library;
    }, "");
    set({ notice: summary });
    return summary;
  },

  exportJson: () => serializeBackup(get().library),

  startFresh: async () => {
    const next = createInitialData();
    localStorage.removeItem(STORAGE_KEY);
    await commit(() => next, "Started a fresh sample library.");
    set({ corruptRaw: null, error: null });
  },

  adoptAccountLibrary: async () => {
    const remote = await getLibrary();
    if (!remote) throw new Error("There's no library on your account yet.");
    writeEnvelope(remote.library, false);
    set({
      library: remote.library,
      dirty: false,
      corruptRaw: null,
      offline: false,
      error: null,
      notice: "Loaded the library from your account.",
      lastSyncedAt: Date.now(),
    });
  },

  setReminder: async (reminder) => {
    localStorage.setItem(REMINDER_KEY, JSON.stringify(reminder));
    set({ reminder });
    try {
      const saved = await saveReminder({ data: reminder });
      set({ reminder: saved, offline: false });
    } catch (error) {
      if (!isNetwork(error)) set({ error: messageOf(error) });
      else set({ offline: true });
    }
  },
}));

async function commit(recipe: (library: Library) => Library, notice?: string) {
  const state = useLibrary.getState();
  if (state.corruptRaw) {
    throw new Error("This device's saved copy can't be read. Download it or start fresh before editing.");
  }
  const next = validateData(recipe(state.library));
  writeEnvelope(next, true);
  useLibrary.setState({ library: next, dirty: true, notice: notice || state.notice, error: null });
  if (!state.userId) return;
  useLibrary.setState({ syncing: true });
  try {
    await pushLibrary(next);
    writeEnvelope(next, false);
    useLibrary.setState({ dirty: false, offline: false, syncing: false, lastSyncedAt: Date.now() });
  } catch (error) {
    useLibrary.setState({
      syncing: false,
      offline: true,
      error: isNetwork(error) ? null : messageOf(error),
    });
  }
}
