export type Rating = 0 | 1 | 2;
export type Side = "front" | "reverse";

export type ReviewRecord = {
  id: string;
  reviewedAt: number;
  rating: Rating;
  intervalDays: number;
  nextReview: number;
  side: Side;
};

export type Deck = {
  id: string;
  title: string;
  createdAt: number;
};

export type Card = {
  id: string;
  deckId: string;
  front: string;
  back: string;
  image: string | null;
  reverse: boolean;
  mastery: 0 | 1 | 2;
  repetitions: number;
  intervalDays: number;
  easeFactor: number;
  nextReview: number;
  revMastery: 0 | 1 | 2;
  revRepetitions: number;
  revIntervalDays: number;
  revEaseFactor: number;
  revNextReview: number;
  createdAt: number;
  reviewHistory: ReviewRecord[];
};

export type Library = {
  initialized: boolean;
  decks: Deck[];
  cards: Card[];
};

export type Schedule = {
  mastery: 0 | 1 | 2;
  repetitions: number;
  intervalDays: number;
  easeFactor: number;
  nextReview: number;
};

export const BACKUP_APP_NAME = "FlashcardsOffline";
export const BACKUP_VERSION = 3;
const IMAGE_MAX = 700_000;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isFiniteNumber = (value: unknown): value is number =>
  typeof value === "number" && Number.isFinite(value);

export function makeId(prefix: string): string {
  const random = globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2);
  return `${prefix}-${random}`;
}

export function emptyLibrary(): Library {
  return { initialized: false, decks: [], cards: [] };
}

export function freshSchedule(now = Date.now()): Schedule {
  return { mastery: 0, repetitions: 0, intervalDays: 0, easeFactor: 2.5, nextReview: now };
}

export function createInitialData(now = Date.now()): Library {
  const architecture = "deck-core-1";
  const craft = "deck-craft-1";
  const fresh = freshSchedule(now);
  return {
    initialized: true,
    decks: [
      { id: architecture, title: "System Architecture", createdAt: now },
      { id: craft, title: "Study craft", createdAt: now },
    ],
    cards: [
      {
        id: "card-1",
        deckId: architecture,
        front: "What is IndexedDB used for in offline web apps?",
        back: "Client-side structured storage for large datasets and offline persistence.",
        image: null,
        reverse: false,
        ...spreadSchedule(fresh, fresh),
        mastery: 1,
        repetitions: 1,
        intervalDays: 1,
        createdAt: now,
        reviewHistory: [],
      },
      {
        id: "card-2",
        deckId: architecture,
        front: "How does Capacitor package a web app into an APK?",
        back: "It wraps local web assets inside a native Android WebView container with a JS-to-Native bridge.",
        image: null,
        reverse: true,
        ...spreadSchedule(fresh, fresh),
        createdAt: now,
        reviewHistory: [],
      },
      {
        id: "card-3",
        deckId: craft,
        front: "SM-2 schedules the next review with an {{ease factor}} that starts at 2.5.",
        back: "Hard lowers ease by 0.2. Easy raises it by 0.15. The floor is 1.3.",
        image: null,
        reverse: false,
        ...spreadSchedule(fresh, fresh),
        createdAt: now,
        reviewHistory: [],
      },
    ],
  };
}

function spreadSchedule(front: Schedule, reverse: Schedule) {
  return {
    mastery: front.mastery,
    repetitions: front.repetitions,
    intervalDays: front.intervalDays,
    easeFactor: front.easeFactor,
    nextReview: front.nextReview,
    revMastery: reverse.mastery,
    revRepetitions: reverse.repetitions,
    revIntervalDays: reverse.intervalDays,
    revEaseFactor: reverse.easeFactor,
    revNextReview: reverse.nextReview,
  };
}

function cleanId(value: unknown): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, 200);
}

function cleanText(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function cleanImage(value: unknown): string | null {
  if (typeof value !== "string" || !value) return null;
  if (!/^data:image\/(jpeg|png|webp);base64,/i.test(value)) {
    throw new Error("Card images must be a JPEG, PNG, or WebP.");
  }
  if (value.length > IMAGE_MAX) throw new Error("A card image is too large. Use a smaller picture.");
  return value;
}

function asMastery(value: unknown): 0 | 1 | 2 {
  const n = Number(value ?? 0);
  return n === 2 ? 2 : n === 1 ? 1 : 0;
}

export function validateData(value: unknown): Library {
  if (!isRecord(value) || !Array.isArray(value.decks) || !Array.isArray(value.cards)) {
    throw new Error("This file is not a valid Flashcards backup.");
  }

  const decks: Deck[] = value.decks.map((item) => {
    if (!isRecord(item)) throw new Error("A deck entry is malformed.");
    const id = cleanId(item.id);
    const title = cleanText(item.title, 120);
    if (!id || !title) throw new Error("Every deck needs an ID and a title.");
    return {
      id,
      title,
      createdAt: isFiniteNumber(item.createdAt) ? item.createdAt : Date.now(),
    };
  });

  if (new Set(decks.map((deck) => deck.id)).size !== decks.length) {
    throw new Error("The backup contains duplicate deck IDs.");
  }
  const titles = decks.map((deck) => deck.title.toLowerCase());
  if (new Set(titles).size !== titles.length) {
    throw new Error("Two decks can't share the same name.");
  }

  const deckIds = new Set(decks.map((deck) => deck.id));
  const now = Date.now();
  const cards: Card[] = value.cards.map((item) => {
    if (!isRecord(item)) throw new Error("A flashcard entry is malformed.");
    const id = cleanId(item.id);
    const deckId = cleanId(item.deckId);
    const front = cleanText(item.front, 10000);
    const back = cleanText(item.back, 10000);
    if (!id || !deckIds.has(deckId) || !front || !back) {
      throw new Error("Every flashcard needs a valid deck, question, and answer.");
    }
    const reviewHistory: ReviewRecord[] = Array.isArray(item.reviewHistory)
      ? item.reviewHistory
          .filter(isRecord)
          .filter((record) => isFiniteNumber(record.reviewedAt) && [0, 1, 2].includes(Number(record.rating)))
          .slice(-200)
          .map((record) => ({
            id: cleanId(record.id) || makeId("review"),
            reviewedAt: Number(record.reviewedAt),
            rating: Number(record.rating) as Rating,
            intervalDays: Math.max(0, Number(record.intervalDays) || 0),
            nextReview: isFiniteNumber(record.nextReview) ? record.nextReview : now,
            side: record.side === "reverse" ? "reverse" : "front",
          }))
      : [];

    return {
      id,
      deckId,
      front,
      back,
      image: cleanImage(item.image),
      reverse: item.reverse === true,
      mastery: asMastery(item.mastery),
      repetitions: Math.max(0, Math.floor(Number(item.repetitions) || 0)),
      intervalDays: Math.max(0, Number(item.intervalDays) || 0),
      easeFactor: Math.max(1.3, Number(item.easeFactor) || 2.5),
      nextReview: isFiniteNumber(item.nextReview) ? item.nextReview : now,
      revMastery: asMastery(item.revMastery),
      revRepetitions: Math.max(0, Math.floor(Number(item.revRepetitions) || 0)),
      revIntervalDays: Math.max(0, Number(item.revIntervalDays) || 0),
      revEaseFactor: Math.max(1.3, Number(item.revEaseFactor) || 2.5),
      revNextReview: isFiniteNumber(item.revNextReview) ? item.revNextReview : now,
      createdAt: isFiniteNumber(item.createdAt) ? item.createdAt : now,
      reviewHistory,
    };
  });

  if (new Set(cards.map((card) => card.id)).size !== cards.length) {
    throw new Error("The backup contains duplicate flashcard IDs.");
  }

  return {
    initialized: value.initialized !== false,
    decks,
    cards,
  };
}

export function parseBackup(text: string): Library {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error("That file is not valid JSON.");
  }
  if (!isRecord(parsed) || parsed.app !== BACKUP_APP_NAME || (parsed.version !== 2 && parsed.version !== BACKUP_VERSION)) {
    throw new Error("Unsupported backup format. Choose a Flashcards Offline v2 or v3 JSON backup.");
  }
  return validateData(parsed);
}

export function serializeBackup(data: Library): string {
  return JSON.stringify(
    {
      app: BACKUP_APP_NAME,
      version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(),
      initialized: true,
      decks: data.decks,
      cards: data.cards,
    },
    null,
    2,
  );
}

export function scheduleOf(card: Card, side: Side): Schedule {
  if (side === "reverse") {
    return {
      mastery: card.revMastery,
      repetitions: card.revRepetitions,
      intervalDays: card.revIntervalDays,
      easeFactor: card.revEaseFactor,
      nextReview: card.revNextReview,
    };
  }
  return {
    mastery: card.mastery,
    repetitions: card.repetitions,
    intervalDays: card.intervalDays,
    easeFactor: card.easeFactor,
    nextReview: card.nextReview,
  };
}

export function withSchedule(card: Card, side: Side, schedule: Schedule): Card {
  if (side === "reverse") {
    return {
      ...card,
      revMastery: schedule.mastery,
      revRepetitions: schedule.repetitions,
      revIntervalDays: schedule.intervalDays,
      revEaseFactor: schedule.easeFactor,
      revNextReview: schedule.nextReview,
    };
  }
  return { ...card, ...schedule };
}

export function applyRating(schedule: Schedule, rating: Rating, reviewedAt = Date.now()): Schedule {
  let repetitions = schedule.repetitions || 0;
  let intervalDays = schedule.intervalDays || 0;
  let easeFactor = schedule.easeFactor || 2.5;

  if (rating === 0) {
    return {
      mastery: 0,
      repetitions: 0,
      intervalDays: 0,
      easeFactor: Math.max(1.3, easeFactor - 0.2),
      nextReview: reviewedAt + 2 * 60 * 1000,
    };
  }

  if (repetitions === 0) intervalDays = rating === 2 ? 3 : 1;
  else if (repetitions === 1) intervalDays = rating === 2 ? 6 : 3;
  else intervalDays = Math.round(intervalDays * easeFactor * (rating === 2 ? 1.3 : 1));

  repetitions += 1;
  easeFactor = Math.max(1.3, easeFactor + (rating === 2 ? 0.15 : 0));
  return {
    mastery: rating === 2 || repetitions >= 2 ? 2 : 1,
    repetitions,
    intervalDays,
    easeFactor,
    nextReview: reviewedAt + intervalDays * 24 * 60 * 60 * 1000,
  };
}

export function rateCard(card: Card, side: Side, rating: Rating, reviewedAt = Date.now()): Card {
  const next = applyRating(scheduleOf(card, side), rating, reviewedAt);
  const review: ReviewRecord = {
    id: makeId("review"),
    reviewedAt,
    rating,
    intervalDays: next.intervalDays,
    nextReview: next.nextReview,
    side,
  };
  return {
    ...withSchedule(card, side, next),
    reviewHistory: [...card.reviewHistory, review].slice(-200),
  };
}

export function intervalLabel(milliseconds: number): string {
  if (milliseconds <= 2 * 60 * 1000) return "2 min";
  if (milliseconds < 60 * 60 * 1000) return `${Math.max(1, Math.round(milliseconds / 60000))} min`;
  if (milliseconds < 24 * 60 * 60 * 1000) return `${Math.max(1, Math.round(milliseconds / 3600000))} hr`;
  const days = Math.max(1, Math.round(milliseconds / 86400000));
  return `${days} ${days === 1 ? "day" : "days"}`;
}

export function previewIntervalLabel(card: Card, side: Side, rating: Rating): string {
  if (rating === 0) return "2 min";
  const schedule = scheduleOf(card, side);
  let intervalDays = schedule.intervalDays || 0;
  const repetitions = schedule.repetitions || 0;
  if (repetitions === 0) intervalDays = rating === 2 ? 3 : 1;
  else if (repetitions === 1) intervalDays = rating === 2 ? 6 : 3;
  else intervalDays = Math.round(intervalDays * (schedule.easeFactor || 2.5) * (rating === 2 ? 1.3 : 1));
  return intervalLabel(intervalDays * 24 * 60 * 60 * 1000);
}

export type QueueItem = { card: Card; side: Side; nextReview: number };

export function allSides(cards: Card[], deckId?: string): QueueItem[] {
  const items: QueueItem[] = [];
  for (const card of cards) {
    if (deckId && card.deckId !== deckId) continue;
    items.push({ card, side: "front", nextReview: card.nextReview });
    if (card.reverse) items.push({ card, side: "reverse", nextReview: card.revNextReview });
  }
  return items;
}

export function dueQueue(cards: Card[], now = Date.now(), deckId?: string): QueueItem[] {
  return allSides(cards, deckId)
    .filter((item) => item.nextReview <= now)
    .sort((a, b) => a.nextReview - b.nextReview || a.card.createdAt - b.card.createdAt);
}

export function isCloze(text: string): boolean {
  return /\{\{[^{}]+\}\}/.test(text);
}

export function hideCloze(text: string): string {
  return text.replace(/\{\{[^{}]+\}\}/g, "______");
}

export function revealCloze(text: string): string {
  return text.replace(/\{\{([^{}]+)\}\}/g, "$1");
}

export type CardStatus = "review" | "learning" | "mastered";

export function cardStatus(card: Card): CardStatus {
  const sides = [card.mastery, ...(card.reverse ? [card.revMastery] : [])];
  if (sides.every((mastery) => mastery >= 2)) return "mastered";
  if (sides.some((mastery) => mastery >= 1)) return "learning";
  return "review";
}

export function statusLabel(status: CardStatus): string {
  if (status === "mastered") return "Mastered";
  if (status === "learning") return "Learning";
  return "Needs review";
}

function startOfLocalDay(ts: number): number {
  const date = new Date(ts);
  date.setHours(0, 0, 0, 0);
  return date.getTime();
}

function dayKey(ts: number): string {
  const date = new Date(ts);
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}

export function forecast(cards: Card[], now = Date.now()) {
  const start = startOfLocalDay(now);
  const days = Array.from({ length: 7 }, (_, index) => {
    const from = start + index * 86400000;
    const to = from + 86400000;
    const count = allSides(cards).filter((item) => item.nextReview > now && item.nextReview >= from && item.nextReview < to).length;
    const label =
      index === 0 ? "Today" : index === 1 ? "Tomorrow" : new Date(from).toLocaleDateString(undefined, { weekday: "short" });
    return { label, count };
  });
  const week = days.reduce((sum, day) => sum + day.count, 0);
  return { days, tomorrow: days[1]?.count ?? 0, week };
}

export function streaks(cards: Card[], now = Date.now()) {
  const days = new Set<string>();
  for (const card of cards) {
    for (const review of card.reviewHistory) days.add(dayKey(review.reviewedAt));
  }
  const today = dayKey(now);
  const yesterday = dayKey(startOfLocalDay(now) - 86400000);
  let current = 0;
  if (days.has(today) || days.has(yesterday)) {
    let cursor = days.has(today) ? startOfLocalDay(now) : startOfLocalDay(now) - 86400000;
    while (days.has(dayKey(cursor))) {
      current += 1;
      cursor -= 86400000;
    }
  }
  let longest = 0;
  let run = 0;
  const sorted = [...days].sort((a, b) => {
    const [ay, am, ad] = a.split("-").map(Number);
    const [by, bm, bd] = b.split("-").map(Number);
    return new Date(ay, am - 1, ad).getTime() - new Date(by, bm - 1, bd).getTime();
  });
  let prev: number | null = null;
  for (const key of sorted) {
    const [year, month, day] = key.split("-").map(Number);
    const ts = new Date(year, month - 1, day).getTime();
    if (prev !== null && ts - prev === 86400000) run += 1;
    else run = 1;
    longest = Math.max(longest, run);
    prev = ts;
  }
  return { current, longest, studiedToday: days.has(today) };
}

export function dueLabel(ts: number, now: number): string {
  if (ts <= now) return "Due now";
  return `In ${intervalLabel(ts - now)}`;
}

export type MergeResult = {
  library: Library;
  addedDecks: number;
  addedCards: number;
  skippedCards: number;
};

export function mergeLibraries(base: Library, incoming: Library): MergeResult {
  const decks = base.decks.map((deck) => ({ ...deck }));
  const cards = base.cards.map((card) => ({ ...card, reviewHistory: card.reviewHistory.map((review) => ({ ...review })) }));
  const byId = new Map(decks.map((deck) => [deck.id, deck]));
  const byTitle = new Map(decks.map((deck) => [deck.title.trim().toLowerCase(), deck]));
  const idMap = new Map<string, string>();
  let addedDecks = 0;

  for (const deck of incoming.decks) {
    const titleKey = deck.title.trim().toLowerCase();
    const existing = byId.get(deck.id) ?? byTitle.get(titleKey);
    if (existing) {
      idMap.set(deck.id, existing.id);
      continue;
    }
    const copy = { ...deck, title: deck.title.trim() };
    decks.push(copy);
    byId.set(copy.id, copy);
    byTitle.set(titleKey, copy);
    idMap.set(deck.id, copy.id);
    addedDecks += 1;
  }

  const cardIds = new Set(cards.map((card) => card.id));
  const contentKey = (card: Card) => `${card.deckId}\u0000${card.front.trim().toLowerCase()}\u0000${card.back.trim().toLowerCase()}`;
  const content = new Set(cards.map(contentKey));
  let addedCards = 0;
  let skippedCards = 0;

  for (const card of incoming.cards) {
    const deckId = idMap.get(card.deckId);
    if (!deckId) {
      skippedCards += 1;
      continue;
    }
    const next: Card = { ...card, deckId, reviewHistory: card.reviewHistory.map((review) => ({ ...review })) };
    if (cardIds.has(next.id) || content.has(contentKey(next))) {
      skippedCards += 1;
      continue;
    }
    if (cardIds.has(next.id)) next.id = makeId("card");
    cards.push(next);
    cardIds.add(next.id);
    content.add(contentKey(next));
    addedCards += 1;
  }

  return {
    library: validateData({ initialized: true, decks, cards }),
    addedDecks,
    addedCards,
    skippedCards,
  };
}

export function duplicateTitle(decks: Deck[], title: string, exceptId?: string): boolean {
  const key = title.trim().toLowerCase();
  return decks.some((deck) => deck.id !== exceptId && deck.title.trim().toLowerCase() === key);
}

function stripHtml(value: string): string {
  return value
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(div|p|li)>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, '"')
    .replace(/&#39;|'/g, "'")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function ankiCloze(text: string): string {
  return text.replace(/\{\{c\d+::([^}:]+)(?:::[^}]*)?\}\}/g, "{{$1}}");
}

function deckForTitle(map: Map<string, Deck>, title: string, now: number): Deck {
  const key = title.trim().toLowerCase();
  const existing = map.get(key);
  if (existing) return existing;
  const deck = { id: makeId("deck"), title: title.trim().slice(0, 120) || "Imported", createdAt: now };
  map.set(deck.title.toLowerCase(), deck);
  return deck;
}

function blankCard(deckId: string, front: string, back: string, now: number, reverse = false): Card {
  const schedule = freshSchedule(now);
  return {
    id: makeId("card"),
    deckId,
    front,
    back,
    image: null,
    reverse,
    ...spreadSchedule(schedule, schedule),
    createdAt: now,
    reviewHistory: [],
  };
}

export function parseCsv(text: string): Library {
  const rows = parseCsvRows(text).filter((row) => row.some((cell) => cell.trim()));
  if (!rows.length) throw new Error("No rows found in that CSV.");
  const header = rows[0].map((cell) => cell.trim().toLowerCase());
  const hasHeader = header.includes("front") && header.includes("back");
  const dataRows = hasHeader ? rows.slice(1) : rows;
  const index = (name: string, fallback: number) => {
    if (!hasHeader) return fallback;
    const found = header.indexOf(name);
    return found >= 0 ? found : -1;
  };
  const frontIndex = index("front", 0);
  const backIndex = index("back", 1);
  const deckIndex = index("deck", 2);
  const reverseIndex = index("reverse", -1);
  const now = Date.now();
  const decks = new Map<string, Deck>();
  const cards: Card[] = [];

  for (const row of dataRows) {
    const front = ankiCloze((row[frontIndex] ?? "").trim());
    const back = (row[backIndex] ?? "").trim();
    if (!front || !back) continue;
    const title = deckIndex >= 0 ? row[deckIndex]?.trim() || "Imported" : "Imported";
    const deck = deckForTitle(decks, title, now);
    const reverseRaw = reverseIndex >= 0 ? (row[reverseIndex] ?? "").trim().toLowerCase() : "";
    const reverse = reverseRaw === "1" || reverseRaw === "true" || reverseRaw === "yes";
    cards.push(blankCard(deck.id, front, back, now, reverse));
  }
  if (!cards.length) throw new Error("That CSV needs a front and a back on each row.");
  return validateData({ initialized: true, decks: [...decks.values()], cards });
}

function parseCsvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const source = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quoted) {
      if (char === '"') {
        if (source[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else quoted = false;
      } else cell += char;
      continue;
    }
    if (char === '"') {
      quoted = true;
      continue;
    }
    if (char === ",") {
      row.push(cell);
      cell = "";
      continue;
    }
    if (char === "\n" || char === "\r") {
      if (char === "\r" && source[i + 1] === "\n") i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += char;
  }
  if (cell.length || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

export function parseAnkiText(text: string): Library {
  const lines = text.split(/\r?\n/);
  let separator = "\t";
  let html = false;
  let deckTitle = "Imported";
  let sawDirective = false;
  const now = Date.now();
  const decks = new Map<string, Deck>();
  const cards: Card[] = [];

  for (const line of lines) {
    if (!line.trim()) continue;
    if (line.startsWith("#")) {
      sawDirective = true;
      if (line.toLowerCase().startsWith("#separator:")) {
        const value = line.slice("#separator:".length).trim().toLowerCase();
        separator = value === "comma" ? "," : value === "semicolon" ? ";" : value === "space" ? " " : "\t";
      } else if (line.toLowerCase().startsWith("#deck:")) {
        deckTitle = stripHtml(line.slice("#deck:".length).trim()) || "Imported";
      } else if (line.toLowerCase().startsWith("#html:")) {
        html = line.slice("#html:".length).trim().toLowerCase() === "true";
      }
      continue;
    }
    const parts = line.split(separator);
    if (parts.length < 2) continue;
    let front = parts[0]?.trim() ?? "";
    let back = parts[1]?.trim() ?? "";
    if (html) {
      front = stripHtml(front);
      back = stripHtml(back);
    }
    front = ankiCloze(front);
    back = ankiCloze(back);
    if (!front || !back) continue;
    const deck = deckForTitle(decks, deckTitle, now);
    cards.push(blankCard(deck.id, front, back, now));
  }

  if (!sawDirective && !text.includes("\t")) {
    throw new Error("That text file is not an Anki export. Use a tab-separated export or CSV.");
  }
  if (!cards.length) throw new Error("No flashcards found in that Anki export.");
  return validateData({ initialized: true, decks: [...decks.values()], cards });
}

export function parseImportText(text: string, filename = ""): Library {
  const trimmed = text.trim();
  if (!trimmed) throw new Error("That file is empty.");
  const lower = filename.toLowerCase();
  if (trimmed.startsWith("{") || lower.endsWith(".json")) {
    return parseBackup(trimmed);
  }
  if (trimmed.startsWith("#") || lower.endsWith(".txt") || lower.endsWith(".tsv")) {
    return parseAnkiText(trimmed);
  }
  if (trimmed.includes("\t") && !trimmed.includes(",")) return parseAnkiText(trimmed);
  return parseCsv(trimmed);
}

export function countByStatus(cards: Card[]) {
  return cards.reduce(
    (counts, card) => {
      counts[cardStatus(card)] += 1;
      return counts;
    },
    { review: 0, learning: 0, mastered: 0 },
  );
}
