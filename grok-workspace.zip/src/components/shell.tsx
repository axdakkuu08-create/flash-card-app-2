import { Link, useRouterState } from "@tanstack/react-router";
import { BarChart3, GalleryHorizontalEnd, Home, Layers, Plus, RefreshCw } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { SignInButtons, SignInGate, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { dueQueue } from "@/lib/flashcards";
import { useLibrary } from "@/lib/library-store";
import { Notice } from "@/components/ui";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/study", label: "Study", icon: GalleryHorizontalEnd },
  { to: "/create", label: "Create", icon: Plus, create: true },
  { to: "/decks", label: "Decks", icon: Layers },
  { to: "/stats", label: "Stats", icon: BarChart3 },
] as const;

export function SkeletonShell() {
  return (
    <main className="mx-auto min-h-screen w-full max-w-lg px-4 pt-8 dock-offset">
      <p className="text-xs font-semibold tracking-[0.18em] text-primary">FLASHCARDS</p>
      <h1 className="mt-3 font-display text-4xl text-fg">Loading your cards</h1>
      <p className="mt-2 text-sm text-muted">Checking this device and your account.</p>
      <div className="mt-6 h-32 animate-pulse rounded-lg bg-surface" />
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="h-28 animate-pulse rounded-lg bg-surface" />
        <div className="h-28 animate-pulse rounded-lg bg-surface" />
      </div>
    </main>
  );
}

export function SignInPanel() {
  return (
    <main className="grid min-h-screen place-items-center px-5 py-10">
      <div className="w-full max-w-sm">
        <p className="text-xs font-semibold tracking-[0.2em] text-primary">FLASHCARDS</p>
        <h1 className="mt-3 font-display text-4xl text-fg">Study once. Keep it everywhere.</h1>
        <p className="mt-3 text-base leading-relaxed text-muted">
          Cards stay available on this device and sync to your account when you're online.
        </p>
        <div className="mt-8">
          <SignInButtons />
        </div>
      </div>
    </main>
  );
}

export function AppFrame({ children }: { children: ReactNode }) {
  const { isPending, user } = useCurrentUserState();
  const bootstrap = useLibrary((state) => state.bootstrap);
  useEffect(() => {
    if (!user?.id) return;
    void bootstrap(user.id);
  }, [bootstrap, user?.id]);
  if (isPending) return <SkeletonShell />;
  return (
    <SignInGate fallback={<SignInPanel />}>
      <Shell>{children}</Shell>
    </SignInGate>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const notice = useLibrary((state) => state.notice);
  const setNotice = useLibrary((state) => state.setNotice);
  const error = useLibrary((state) => state.error);
  const corruptRaw = useLibrary((state) => state.corruptRaw);
  const offline = useLibrary((state) => state.offline);
  const dirty = useLibrary((state) => state.dirty);
  const syncing = useLibrary((state) => state.syncing);
  const ready = useLibrary((state) => state.ready);
  const reminder = useLibrary((state) => state.reminder);
  const cards = useLibrary((state) => state.library.cards);
  const sync = useLibrary((state) => state.sync);

  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(() => setNotice(null), 5000);
    return () => window.clearTimeout(id);
  }, [notice, setNotice]);

  useDailyReminder(ready, reminder.enabled, reminder.time, cards);

  const status = syncing ? "Syncing" : offline && dirty ? "Saved on this device" : offline ? "Offline" : dirty ? "Waiting to sync" : "Synced";

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex w-full max-w-lg items-center justify-between gap-3 px-4 pt-5">
        <div>
          <p className="text-xs font-semibold tracking-[0.18em] text-primary">FLASHCARDS</p>
          <p className="text-sm text-muted">{status}</p>
        </div>
        <div className="flex max-w-48 items-center gap-2 overflow-hidden text-fg">
          <button
            type="button"
            aria-label="Sync now"
            onClick={() => void sync()}
            className="grid h-11 w-11 place-items-center rounded-lg border border-line bg-surface text-fg"
          >
            <RefreshCw className={`size-4 ${syncing ? "animate-spin" : ""}`} />
          </button>
          <UserButton />
        </div>
      </header>
      <main className="mx-auto w-full max-w-lg px-4 pt-5 dock-offset">
        <div className="flex flex-col gap-4">
          {corruptRaw ? (
            <CorruptBanner raw={corruptRaw} />
          ) : null}
          {error && !corruptRaw ? <Notice tone="error">{error}</Notice> : null}
          {notice ? <Notice>{notice}</Notice> : null}
          {children}
        </div>
      </main>
      <nav aria-label="Primary" className="dock-bar fixed inset-x-0 z-40 px-4">
        <div className="mx-auto flex h-16 max-w-lg items-center justify-between rounded-full border border-line bg-surface px-2">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
            const Icon = item.icon;
            if ("create" in item) {
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  aria-label="Create a flashcard"
                  aria-current={active ? "page" : undefined}
                  className="-mt-7 grid h-14 w-14 place-items-center rounded-full border-4 border-bg bg-primary text-primary-ink"
                >
                  <Plus className="size-6" />
                </Link>
              );
            }
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-label={item.label}
                aria-current={active ? "page" : undefined}
                className={`flex h-11 items-center gap-1 rounded-full px-3 text-xs font-semibold ${active ? "bg-fg text-bg" : "text-muted"}`}
              >
                <Icon className="size-4" />
                {active ? item.label : null}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function CorruptBanner({ raw }: { raw: string }) {
  const startFresh = useLibrary((state) => state.startFresh);
  const adopt = useLibrary((state) => state.adoptAccountLibrary);
  const setNotice = useLibrary((state) => state.setNotice);
  return (
    <div className="rounded-lg border border-line bg-surface p-4">
      <h2 className="font-display text-xl text-fg">This device's copy can't be read</h2>
      <p className="mt-2 text-sm text-muted">
        Nothing was replaced with the sample deck. Download the unreadable file, load the library from your account, or start fresh.
      </p>
      <div className="mt-4 flex flex-col gap-2">
        <button
          type="button"
          className="min-h-11 rounded-lg border border-line px-4 text-sm font-semibold text-fg"
          onClick={() => downloadText("flashcards-unreadable.json", raw)}
        >
          Download unreadable copy
        </button>
        <button
          type="button"
          className="min-h-11 rounded-lg border border-line px-4 text-sm font-semibold text-fg"
          onClick={() => {
            void adopt().catch((error: unknown) => {
              setNotice(error instanceof Error ? error.message : "Couldn't load the account library.");
            });
          }}
        >
          Load account library
        </button>
        <button
          type="button"
          className="min-h-11 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink"
          onClick={() => {
            if (window.confirm("Replace the unreadable copy with a fresh sample library?")) void startFresh();
          }}
        >
          Start fresh
        </button>
      </div>
    </div>
  );
}

function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function useDailyReminder(ready: boolean, enabled: boolean, time: string, cards: Parameters<typeof dueQueue>[0]) {
  useEffect(() => {
    if (!ready) return;
    const was = localStorage.getItem("flashcards-reminder-enabled") === "1";
    if (enabled && !was) {
      const now = new Date();
      const [hour, minute] = time.split(":").map(Number);
      const scheduled = new Date(now);
      scheduled.setHours(hour, minute, 0, 0);
      if (now.getTime() >= scheduled.getTime()) {
        localStorage.setItem("flashcards-reminder-fired", now.toDateString());
      }
    }
    localStorage.setItem("flashcards-reminder-enabled", enabled ? "1" : "0");
  }, [enabled, ready, time]);

  useEffect(() => {
    if (!ready || !enabled) return;
    const tick = () => {
      if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
      const now = new Date();
      const [hour, minute] = time.split(":").map(Number);
      const scheduled = new Date(now);
      scheduled.setHours(hour, minute, 0, 0);
      if (now.getTime() + 15000 < scheduled.getTime()) return;
      const stamp = now.toDateString();
      if (localStorage.getItem("flashcards-reminder-fired") === stamp) return;
      if (now.getTime() < scheduled.getTime()) return;
      localStorage.setItem("flashcards-reminder-fired", stamp);
      const due = dueQueue(cards, Date.now()).length;
      const noun = due === 1 ? "card" : "cards";
      new Notification("Flashcards", { body: `You have ${due} ${noun} due` });
    };
    tick();
    const id = window.setInterval(tick, 20000);
    return () => window.clearInterval(id);
  }, [cards, enabled, ready, time]);
}
