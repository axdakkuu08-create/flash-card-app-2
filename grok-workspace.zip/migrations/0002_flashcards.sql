create table if not exists flashcard_libraries (
  user_id text primary key,
  payload text not null,
  updated_at timestamptz not null default now()
);

create table if not exists flashcard_reminders (
  user_id text primary key,
  enabled boolean not null default false,
  remind_time text not null default '09:00'
);
