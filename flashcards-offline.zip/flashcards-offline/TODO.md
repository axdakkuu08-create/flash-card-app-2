# Flashcards Offline — TODO

## Product outcomes

- [x] **Dashboard and navigation** — The Home Dashboard uses an asymmetric Bento-style layout and displays Total Cards, Due Today, and Mastery Progress percentage; it provides a Start Study Session action and offline JSON Export Backup / Import Backup actions. A status badge distinguishes online/local-ready and offline/local-ready states without blocking offline use. Primary navigation is a rounded translucent floating dock above the system gesture safe area, with expanding labels for the active item and an elevated center `+` action to create a card. Keep the approved dark navy, cyan/indigo, glass-card visual identity, adapted to portrait one-handed mobile use.

- [x] **Offline-first local persistence** — Decks and cards persist on-device without a backend or network dependency. Persist card mastery, repetitions, SM-2 interval days, ease factor, next-review timestamp, creation time, and review history; new cards are due immediately. On an empty store, initialize a usable sample deck and cards. Core study, creation, deck management, statistics, and backups remain available offline.

- [x] **Study session and SM-2** — Present one due card at a time, ordered by next-review timestamp, with optional per-deck filtering. Tap/activate the card to reveal the answer with a 3D `rotateY(180deg)` flip. On platforms supporting keyboard input, `Space` flips and `1`/`2`/`3` select Hard/Good/Easy without capturing keystrokes while editing inputs. Provide Hard, Good, and Easy actions with dynamic previews of the next interval. Hard repeats after 2 minutes and resets repetitions while lowering ease factor by 0.2 to a 1.3 minimum; Good/Easy apply the source intervals and ease updates. Persist every review and its rating, time, interval, and next-review timestamp. When the due queue is empty, show an all-caught-up state with routes to add a card and, when filtered, study all decks.

- [x] **Create flashcards** — The Create screen requires both a front (question/prompt) and back (answer/explanation), and lets the user select an existing deck or create a new deck inline. Saving initializes an unreviewed card with mastery 0, repetitions 0, interval 0 days, ease factor 2.5, and a next-review timestamp of now; the result is stored locally with clear validation and save feedback.

- [x] **Deck management** — The Decks screen supports live case-insensitive title search and shows each matching deck's card total and due count. Each deck has a direct Study action. Deleting a deck requires explicit confirmation and cascades to every card in that deck. Empty and no-search-match states explain how to continue.

- [x] **Mastery statistics** — The Stats screen shows overall and per-deck progress using color-coded Needs Review (mastery 0), Learning (mastery 1), and Mastered (mastery 2+) categories. Use locally stored review history for review totals and recent-review counts; show each deck's total cards and review count as well as its mastery breakdown.

- [x] **Complete JSON backup and restore** — Export the complete deck/card set, including scheduling state and review history, as a downloadable/shareable JSON backup with app identity and version metadata. Import accepts a selected JSON file offline, validates the Flashcards Offline v2 structure, IDs, required content, and deck references, and asks before replacing all current local data. Show success or actionable failure feedback; do not require an account or backend.

- [x] **Accessible mobile experience** — Use readable contrast, clear action/selected/disabled states, meaningful screen-reader labels and hints, and touch controls with comfortable mobile hit areas. Keep screens portrait-oriented and usable one-handed; preserve keyboard support where available.

- [x] **Native app identity** — Deliver a distinct square app launcher icon plus coordinated adaptive icon, monochrome icon, favicon, and splash assets in the approved dark-navy/cyan/indigo identity. Preserve the initialized Expo scheme and platform identifiers.
