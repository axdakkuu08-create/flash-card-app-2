import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type ScrollViewProps,
  type TextInputProps,
  type ViewStyle,
} from "react-native";

export const COLORS = {
  background: "#08111F",
  backgroundSoft: "#0B1726",
  surface: "#101F31",
  surfaceRaised: "#14263B",
  border: "#23384F",
  text: "#F4F8FC",
  muted: "#91A4B9",
  cyan: "#38BDF8",
  cyanSoft: "#12324A",
  indigo: "#818CF8",
  green: "#4AD5A5",
  greenSoft: "#12352F",
  amber: "#F7C66D",
  amberSoft: "#3A2D19",
  red: "#FF838A",
  redSoft: "#3A2028",
};

export function AppPage({ children, contentStyle, ...props }: ScrollViewProps & { contentStyle?: StyleProp<ViewStyle> }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={styles.page}>
      <View pointerEvents="none" style={styles.glowTop} />
      <View pointerEvents="none" style={styles.glowSide} />
      <ScrollView
        {...props}
        style={styles.scroll}
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(insets.top, 16), paddingBottom: Math.max(insets.bottom, 16) + 116 },
          contentStyle,
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {children}
      </ScrollView>
    </View>
  );
}

export function BrandMark({ size = 34 }: { size?: number }) {
  return (
    <View style={[styles.brandMark, { width: size, height: size, borderRadius: size * 0.31 }]}>
      <View style={[styles.brandCardBack, { width: size * 0.48, height: size * 0.61 }]} />
      <View style={[styles.brandCardFront, { width: size * 0.48, height: size * 0.61 }]}>
        <View style={[styles.brandLine, { width: size * 0.25 }]} />
        <View style={[styles.brandLine, { width: size * 0.19 }]} />
      </View>
      <View style={[styles.brandSpark, { width: size * 0.16, height: size * 0.16 }]} />
    </View>
  );
}

export function StatusPill({ label, online }: { label: string; online: boolean | null }) {
  const tint = online === false ? COLORS.amber : COLORS.green;
  return (
    <View style={[styles.statusPill, { borderColor: `${tint}55`, backgroundColor: `${tint}15` }]}>
      <View style={[styles.statusDot, { backgroundColor: tint }]} />
      <Text style={[styles.statusText, { color: tint }]}>{label}</Text>
    </View>
  );
}

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  right,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  return (
    <View style={styles.pageHeader}>
      <View style={styles.pageHeading}>
        <Text style={styles.eyebrow}>{eyebrow}</Text>
        <Text accessibilityRole="header" style={styles.pageTitle}>{title}</Text>
        {subtitle ? <Text style={styles.pageSubtitle}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function Surface({ children, style, ...props }: React.ComponentProps<typeof View>) {
  return <View {...props} style={[styles.surface, style]}>{children}</View>;
}

export function SectionHeading({ title, detail }: { title: string; detail?: string }) {
  return (
    <View style={styles.sectionHeading}>
      <Text accessibilityRole="header" style={styles.sectionTitle}>{title}</Text>
      {detail ? <Text style={styles.sectionDetail}>{detail}</Text> : null}
    </View>
  );
}

export function MetricCard({
  label,
  value,
  detail,
  accent = COLORS.cyan,
  icon,
  style,
}: {
  label: string;
  value: string | number;
  detail?: string;
  accent?: string;
  icon: React.ComponentProps<typeof Ionicons>["name"];
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View style={[styles.metricCard, style]}>
      <View style={[styles.metricIcon, { backgroundColor: `${accent}18` }]}>
        <Ionicons name={icon} size={18} color={accent} />
      </View>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={[styles.metricValue, { color: accent }]}>{value}</Text>
      {detail ? <Text style={styles.metricDetail}>{detail}</Text> : null}
    </View>
  );
}

export function ProgressBar({ value, color = COLORS.cyan }: { value: number; color?: string }) {
  const width = `${Math.max(0, Math.min(100, value))}%` as `${number}%`;
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityValue={{ min: 0, max: 100, now: Math.round(value) }}
      style={styles.progressTrack}
    >
      <View style={[styles.progressFill, { width, backgroundColor: color }]} />
    </View>
  );
}

export function PrimaryButton({
  title,
  onPress,
  icon,
  disabled = false,
  accessibilityLabel,
}: {
  title: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof Ionicons>["name"];
  disabled?: boolean;
  accessibilityLabel?: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? title}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [styles.primaryButton, disabled && styles.disabledButton, pressed && !disabled && styles.pressed]}
    >
      <Text style={styles.primaryButtonText}>{title}</Text>
      {icon ? <Ionicons name={icon} size={19} color={COLORS.background} /> : null}
    </Pressable>
  );
}

export function SecondaryButton({
  title,
  onPress,
  icon,
  destructive = false,
  compact = false,
}: {
  title: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof Ionicons>["name"];
  destructive?: boolean;
  compact?: boolean;
}) {
  const color = destructive ? COLORS.red : COLORS.text;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      onPress={onPress}
      style={({ pressed }) => [
        styles.secondaryButton,
        compact && styles.compactButton,
        destructive && styles.destructiveButton,
        pressed && styles.pressed,
      ]}
    >
      {icon ? <Ionicons name={icon} size={17} color={color} /> : null}
      <Text style={[styles.secondaryButtonText, { color }]}>{title}</Text>
    </Pressable>
  );
}

export function TextField({
  label,
  hint,
  style,
  ...props
}: TextInputProps & { label: string; hint?: string }) {
  const [focused, setFocused] = useState(false);
  return (
    <View>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        {...props}
        accessibilityLabel={props.accessibilityLabel ?? label}
        placeholderTextColor={COLORS.muted}
        onFocus={(event) => {
          setFocused(true);
          props.onFocus?.(event);
        }}
        onBlur={(event) => {
          setFocused(false);
          props.onBlur?.(event);
        }}
        style={[styles.input, props.multiline && styles.multilineInput, focused && styles.inputFocused, style]}
      />
      {hint ? <Text style={styles.fieldHint}>{hint}</Text> : null}
    </View>
  );
}

export function Notice({ message, type = "success" }: { message: string; type?: "success" | "error" | "info" }) {
  if (!message) return null;
  const color = type === "error" ? COLORS.red : type === "info" ? COLORS.cyan : COLORS.green;
  return (
    <View accessibilityRole="alert" style={[styles.notice, { borderColor: `${color}55`, backgroundColor: `${color}12` }]}>
      <Ionicons name={type === "error" ? "alert-circle-outline" : "checkmark-circle-outline"} size={18} color={color} />
      <Text style={[styles.noticeText, { color }]}>{message}</Text>
    </View>
  );
}

export function EmptyState({
  icon = "sparkles-outline",
  title,
  message,
  action,
}: {
  icon?: React.ComponentProps<typeof Ionicons>["name"];
  title: string;
  message: string;
  action?: React.ReactNode;
}) {
  return (
    <Surface style={styles.emptyState}>
      <View style={styles.emptyIcon}><Ionicons name={icon} size={26} color={COLORS.cyan} /></View>
      <Text accessibilityRole="header" style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyMessage}>{message}</Text>
      {action ? <View style={styles.emptyAction}>{action}</View> : null}
    </Surface>
  );
}

export function ConfirmDialog({
  visible,
  title,
  message,
  confirmLabel,
  destructive = false,
  onCancel,
  onConfirm,
}: {
  visible: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  destructive?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const insets = useSafeAreaInsets();
  const color = destructive ? COLORS.red : COLORS.cyan;
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel} statusBarTranslucent>
      <View style={[styles.modalOverlay, { paddingTop: Math.max(insets.top, 20), paddingBottom: Math.max(insets.bottom, 20) }]}>
        <View accessibilityViewIsModal accessibilityRole="alert" style={styles.modalCard}>
          <View style={[styles.modalIcon, { backgroundColor: `${color}18` }]}>
            <Ionicons name={destructive ? "trash-outline" : "cloud-upload-outline"} size={22} color={color} />
          </View>
          <Text accessibilityRole="header" style={styles.modalTitle}>{title}</Text>
          <Text style={styles.modalMessage}>{message}</Text>
          <View style={styles.modalActions}>
            <SecondaryButton title="Cancel" onPress={onCancel} compact />
            <Pressable
              accessibilityRole="button"
              onPress={onConfirm}
              style={({ pressed }) => [styles.modalConfirm, { backgroundColor: color }, pressed && styles.pressed]}
            >
              <Text style={styles.modalConfirmText}>{confirmLabel}</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export function LoadingState({ label = "Loading your cards" }: { label?: string }) {
  return (
    <View style={styles.loadingState}>
      <ActivityIndicator color={COLORS.cyan} size="large" />
      <Text style={styles.loadingLabel}>{label}</Text>
    </View>
  );
}

export function Tag({ children, tint = COLORS.cyan }: { children: React.ReactNode; tint?: string }) {
  return (
    <View style={[styles.tag, { backgroundColor: `${tint}16`, borderColor: `${tint}40` }]}>
      <Text style={[styles.tagText, { color: tint }]}>{children}</Text>
    </View>
  );
}

export function createStyles<const T extends Record<string, object>>(styles: T): T {
  return StyleSheet.create(styles as T & StyleSheet.NamedStyles<T>) as T;
}

const styles = createStyles({
  page: { flex: 1, backgroundColor: COLORS.background, overflow: "hidden" },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 20, flexGrow: 1, gap: 18 },
  glowTop: { position: "absolute", width: 280, height: 280, borderRadius: 160, top: -170, right: -90, backgroundColor: "rgba(56,189,248,0.10)" },
  glowSide: { position: "absolute", width: 240, height: 240, borderRadius: 140, top: 310, left: -200, backgroundColor: "rgba(129,140,248,0.07)" },
  brandMark: { alignItems: "center", justifyContent: "center", backgroundColor: COLORS.surfaceRaised, overflow: "hidden" },
  brandCardBack: { position: "absolute", right: "17%", top: "13%", borderRadius: 4, backgroundColor: COLORS.indigo, transform: [{ rotate: "12deg" }] },
  brandCardFront: { position: "absolute", left: "18%", bottom: "15%", alignItems: "flex-start", justifyContent: "center", gap: 3, paddingLeft: 3, borderRadius: 4, backgroundColor: COLORS.cyan, transform: [{ rotate: "-8deg" }] },
  brandLine: { height: 2, borderRadius: 2, backgroundColor: COLORS.background },
  brandSpark: { position: "absolute", right: "11%", top: "17%", borderRadius: 5, backgroundColor: COLORS.text },
  statusPill: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, paddingVertical: 7, borderWidth: 1, borderRadius: 999 },
  statusDot: { width: 6, height: 6, borderRadius: 4 },
  statusText: { fontSize: 10, fontWeight: "700", letterSpacing: 0.1 },
  pageHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 2 },
  pageHeading: { flex: 1, gap: 5 },
  eyebrow: { color: COLORS.cyan, fontSize: 10, fontWeight: "800", letterSpacing: 1.4, textTransform: "uppercase" },
  pageTitle: { color: COLORS.text, fontSize: 28, lineHeight: 34, fontWeight: "800", letterSpacing: -0.7 },
  pageSubtitle: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginTop: 1 },
  surface: { backgroundColor: "rgba(16,31,49,0.94)", borderColor: COLORS.border, borderWidth: 1, borderRadius: 22, padding: 18 },
  sectionHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", gap: 12, marginBottom: 10 },
  sectionTitle: { color: COLORS.text, fontSize: 16, fontWeight: "700" },
  sectionDetail: { color: COLORS.muted, fontSize: 11, fontWeight: "600" },
  metricCard: { flex: 1, minWidth: 130, backgroundColor: "rgba(16,31,49,0.92)", borderColor: COLORS.border, borderWidth: 1, borderRadius: 20, padding: 16, gap: 6 },
  metricIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center", marginBottom: 4 },
  metricLabel: { color: COLORS.muted, fontSize: 11, fontWeight: "700", letterSpacing: 0.4 },
  metricValue: { fontSize: 30, lineHeight: 34, fontWeight: "800", letterSpacing: -0.8 },
  metricDetail: { color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  progressTrack: { width: "100%", height: 8, borderRadius: 8, overflow: "hidden", backgroundColor: "#22354A" },
  progressFill: { height: "100%", borderRadius: 8 },
  primaryButton: { minHeight: 54, paddingHorizontal: 18, paddingVertical: 14, borderRadius: 17, backgroundColor: COLORS.cyan, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 10, shadowColor: COLORS.cyan, shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.15, shadowRadius: 14, elevation: 3 },
  primaryButtonText: { color: COLORS.background, fontSize: 14, fontWeight: "800", letterSpacing: 0.1 },
  disabledButton: { opacity: 0.45 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.985 }] },
  secondaryButton: { minHeight: 46, paddingHorizontal: 13, paddingVertical: 11, borderRadius: 14, borderColor: COLORS.border, borderWidth: 1, backgroundColor: "#0D1A2A", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8 },
  compactButton: { minHeight: 42, paddingHorizontal: 14 },
  destructiveButton: { borderColor: "#63333E", backgroundColor: COLORS.redSoft },
  secondaryButtonText: { color: COLORS.text, fontSize: 12, fontWeight: "700" },
  fieldLabel: { color: COLORS.text, fontSize: 12, fontWeight: "700", marginBottom: 7 },
  input: { minHeight: 50, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: "#0A1625", color: COLORS.text, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, lineHeight: 20 },
  multilineInput: { minHeight: 106, textAlignVertical: "top" },
  inputFocused: { borderColor: COLORS.cyan },
  fieldHint: { color: COLORS.muted, fontSize: 11, marginTop: 6 },
  notice: { flexDirection: "row", alignItems: "center", gap: 9, padding: 12, borderWidth: 1, borderRadius: 14 },
  noticeText: { flex: 1, fontSize: 12, lineHeight: 18, fontWeight: "600" },
  emptyState: { alignItems: "center", paddingVertical: 28, paddingHorizontal: 20, gap: 10 },
  emptyIcon: { width: 54, height: 54, alignItems: "center", justifyContent: "center", borderRadius: 18, backgroundColor: COLORS.cyanSoft, marginBottom: 3 },
  emptyTitle: { color: COLORS.text, fontSize: 18, fontWeight: "800", textAlign: "center" },
  emptyMessage: { color: COLORS.muted, fontSize: 13, lineHeight: 20, textAlign: "center", maxWidth: 300 },
  emptyAction: { width: "100%", marginTop: 5 },
  modalOverlay: { flex: 1, paddingHorizontal: 24, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(2,8,15,0.75)" },
  modalCard: { width: "100%", maxWidth: 420, padding: 22, borderRadius: 24, backgroundColor: COLORS.surface, borderColor: COLORS.border, borderWidth: 1 },
  modalIcon: { width: 46, height: 46, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 15 },
  modalTitle: { color: COLORS.text, fontSize: 19, lineHeight: 24, fontWeight: "800" },
  modalMessage: { color: COLORS.muted, fontSize: 13, lineHeight: 20, marginTop: 8 },
  modalActions: { flexDirection: "row", gap: 10, marginTop: 22, justifyContent: "flex-end" },
  modalConfirm: { minHeight: 42, borderRadius: 14, paddingHorizontal: 15, alignItems: "center", justifyContent: "center" },
  modalConfirmText: { color: COLORS.background, fontSize: 12, fontWeight: "800" },
  loadingState: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14, backgroundColor: COLORS.background },
  loadingLabel: { color: COLORS.muted, fontSize: 13, fontWeight: "600" },
  tag: { alignSelf: "flex-start", borderRadius: 999, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 6 },
  tagText: { fontSize: 10, letterSpacing: 0.4, fontWeight: "800", textTransform: "uppercase" },
});
