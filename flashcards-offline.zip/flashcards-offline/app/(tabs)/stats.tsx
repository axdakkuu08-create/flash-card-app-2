import { Ionicons } from "@expo/vector-icons";
import { useMemo } from "react";
import { Text, View } from "react-native";

import { AppPage, COLORS, createStyles, MetricCard, PageHeader, ProgressBar, SectionHeading, Surface, Tag } from "@/components/flashcards-ui";
import { useFlashcards } from "@/hooks/flashcards-provider";
import { useNow } from "@/hooks/use-now";
import { countRecentReviews } from "@/lib/flashcards";

export default function StatsScreen() {
  const { data, ready } = useFlashcards();
  const now = useNow();
  const stats = useMemo(() => {
    const mastered = data.cards.filter((card) => card.mastery >= 2).length;
    const learning = data.cards.filter((card) => card.mastery === 1).length;
    const needsReview = data.cards.filter((card) => card.mastery === 0).length;
    const reviewCount = data.cards.reduce((total, card) => total + card.reviewHistory.length, 0);
    const recentReviews = countRecentReviews(data.cards, now);
    return { mastered, learning, needsReview, reviewCount, recentReviews };
  }, [data, now]);

  if (!ready) return <AppPage><View style={{ flex: 1 }} /></AppPage>;

  return (
    <AppPage>
      <PageHeader eyebrow="A CLEARER PICTURE" title="Your progress" subtitle="Learning momentum, saved with your cards on this device." />

      <View style={styles.statsGrid}>
        <MetricCard label="MASTERED" value={stats.mastered} detail="Confident recall" accent={COLORS.green} icon="checkmark-circle-outline" />
        <MetricCard label="LEARNING" value={stats.learning} detail="Building a rhythm" accent={COLORS.amber} icon="hourglass-outline" />
      </View>
      <View style={styles.statsGrid}>
        <MetricCard label="NEEDS REVIEW" value={stats.needsReview} detail="Keep these in rotation" accent={COLORS.red} icon="refresh-outline" />
        <MetricCard label="REVIEWS" value={stats.reviewCount} detail={`${stats.recentReviews} in the last 7 days`} accent={COLORS.cyan} icon="time-outline" />
      </View>

      <Surface style={styles.overallCard}>
        <View style={styles.overallTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>THE BIG PICTURE</Text>
            <Text accessibilityRole="header" style={styles.overallTitle}>Cards mastered</Text>
          </View>
          <Text style={styles.overallPercent}>{data.cards.length ? Math.round((stats.mastered / data.cards.length) * 100) : 0}%</Text>
        </View>
        <ProgressBar value={data.cards.length ? (stats.mastered / data.cards.length) * 100 : 0} color={COLORS.green} />
        <Text style={styles.overallDetail}>{stats.mastered} mastered · {stats.learning} learning · {stats.needsReview} need review</Text>
      </Surface>

      <View style={styles.section}>
        <SectionHeading title="Deck-by-deck" detail={`${data.decks.length} total`} />
        {data.decks.length ? data.decks.map((deck, index) => {
          const cards = data.cards.filter((card) => card.deckId === deck.id);
          const mastered = cards.filter((card) => card.mastery >= 2).length;
          const learning = cards.filter((card) => card.mastery === 1).length;
          const needsReview = cards.filter((card) => card.mastery === 0).length;
          const historyCount = cards.reduce((total, card) => total + card.reviewHistory.length, 0);
          const percent = cards.length ? Math.round((mastered / cards.length) * 100) : 0;
          const accent = index % 2 ? COLORS.indigo : COLORS.cyan;
          return (
            <Surface key={deck.id} style={styles.deckStatCard}>
              <View style={styles.deckStatTop}>
                <View style={[styles.deckIcon, { backgroundColor: `${accent}18` }]}><Ionicons name="layers-outline" size={17} color={accent} /></View>
                <View style={{ flex: 1 }}>
                  <Text accessibilityRole="header" style={styles.deckTitle}>{deck.title}</Text>
                  <Text style={styles.deckSub}>{cards.length} {cards.length === 1 ? "card" : "cards"} · {historyCount} {historyCount === 1 ? "review" : "reviews"}</Text>
                </View>
                <Tag tint={accent}>{percent}%</Tag>
              </View>
              <ProgressBar value={percent} color={accent} />
              <View style={styles.deckBreakdown}>
                <CountLabel color={COLORS.green} label="mastered" count={mastered} />
                <CountLabel color={COLORS.amber} label="learning" count={learning} />
                <CountLabel color={COLORS.red} label="review" count={needsReview} />
              </View>
            </Surface>
          );
        }) : (
          <Surface style={styles.noDecks}>
            <Ionicons name="bar-chart-outline" size={22} color={COLORS.muted} />
            <Text style={styles.noDecksText}>Create a deck to start seeing your learning progress here.</Text>
          </Surface>
        )}
      </View>

      <View style={styles.footnote}>
        <Ionicons name="lock-closed-outline" size={14} color={COLORS.muted} />
        <Text style={styles.footnoteText}>Progress is calculated from your local mastery state and review history.</Text>
      </View>
    </AppPage>
  );
}

function CountLabel({ color, label, count }: { color: string; label: string; count: number }) {
  return (
    <View style={styles.countLabel}>
      <View style={[styles.countDot, { backgroundColor: color }]} />
      <Text style={styles.countText}>{count} {label}</Text>
    </View>
  );
}

const styles = createStyles({
  statsGrid: { flexDirection: "row", gap: 10 },
  overallCard: { gap: 14 },
  overallTop: { flexDirection: "row", alignItems: "center" },
  eyebrow: { color: COLORS.green, fontSize: 9, letterSpacing: 1.1, fontWeight: "800", marginBottom: 4 },
  overallTitle: { color: COLORS.text, fontSize: 16, fontWeight: "800" },
  overallPercent: { color: COLORS.green, fontSize: 28, fontWeight: "800" },
  overallDetail: { color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  section: { gap: 10 },
  deckStatCard: { padding: 15, gap: 13 },
  deckStatTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  deckIcon: { width: 36, height: 36, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  deckTitle: { color: COLORS.text, fontSize: 13, fontWeight: "800" },
  deckSub: { color: COLORS.muted, fontSize: 10, marginTop: 3 },
  deckBreakdown: { flexDirection: "row", flexWrap: "wrap", gap: 11 },
  countLabel: { flexDirection: "row", alignItems: "center", gap: 5 },
  countDot: { width: 6, height: 6, borderRadius: 4 },
  countText: { color: COLORS.muted, fontSize: 9, fontWeight: "700" },
  noDecks: { flexDirection: "row", alignItems: "center", gap: 10 },
  noDecksText: { flex: 1, color: COLORS.muted, fontSize: 12, lineHeight: 18 },
  footnote: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 6 },
  footnoteText: { flex: 1, color: COLORS.muted, fontSize: 10, lineHeight: 15 },
});
