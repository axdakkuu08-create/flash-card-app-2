import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Animated, Platform, Pressable, Text, View } from "react-native";

import { AppPage, COLORS, createStyles, EmptyState, PageHeader, PrimaryButton, Surface, Tag } from "@/components/flashcards-ui";
import { dueCards, getDeck, useFlashcards } from "@/hooks/flashcards-provider";
import { useNow } from "@/hooks/use-now";
import { previewIntervalLabel, type Flashcard, type Rating } from "@/lib/flashcards";

export default function StudyScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ deckId?: string | string[] }>();
  const deckId = Array.isArray(params.deckId) ? params.deckId[0] : params.deckId;
  const { data, ready, rateCard } = useFlashcards();
  const now = useNow();
  const [flippedCardId, setFlippedCardId] = useState<string | null>(null);
  const [rotation] = useState(() => new Animated.Value(0));

  const queue = useMemo(() => dueCards(data.cards, now, deckId), [data.cards, deckId, now]);
  const card = queue[0];
  const deck = card ? getDeck(data, card.deckId) : undefined;
  const flipped = Boolean(card && flippedCardId === card.id);

  const toggleFlip = useCallback(() => {
    if (!card) return;
    const next = !flipped;
    setFlippedCardId(next ? card.id : null);
    Animated.timing(rotation, { toValue: next ? 180 : 0, duration: 420, useNativeDriver: true }).start();
  }, [card, flipped, rotation]);

  const handleRating = useCallback(async (rating: Rating) => {
    if (!card) return;
    const currentId = card.id;
    setFlippedCardId(null);
    rotation.setValue(0);
    await rateCard(currentId, rating);
  }, [card, rateCard, rotation]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (event.code === "Space" && card) {
        event.preventDefault();
        toggleFlip();
      } else if (["1", "2", "3"].includes(event.key) && card && flipped) {
        void handleRating((Number(event.key) - 1) as Rating);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [card, flipped, handleRating, toggleFlip]);

  const faceRotation = rotation.interpolate({ inputRange: [0, 180], outputRange: ["0deg", "180deg"] });
  const backRotation = rotation.interpolate({ inputRange: [0, 180], outputRange: ["180deg", "360deg"] });

  if (!ready) return <AppPage><View style={{ flex: 1 }} /></AppPage>;

  const noDueMessage = deckId
    ? "This deck has no cards due right now. Your other decks are still ready to study."
    : "You have no cards waiting for review. Add a few cards or come back when your next review is due.";

  return (
    <AppPage>
      <PageHeader
        eyebrow="FOCUSED REVIEW"
        title="Study session"
        subtitle={deck ? `Deck · ${deck.title}` : deckId ? "Selected deck" : "All decks"}
        right={<Tag tint={queue.length ? COLORS.amber : COLORS.green}>{queue.length} DUE</Tag>}
      />

      {!card ? (
        <EmptyState
          icon="checkmark-done-outline"
          title="You’re all caught up"
          message={noDueMessage}
          action={
            <View style={{ gap: 10 }}>
              {deckId ? <PrimaryButton title="Study all decks" icon="albums-outline" onPress={() => router.replace("/study")} /> : null}
              <PrimaryButton title="Add a flashcard" icon="add" onPress={() => router.push("/create")} />
              {data.cards.length ? <Pressable accessibilityRole="button" onPress={() => router.push("/decks")} style={styles.secondaryLink}><Text style={styles.secondaryLinkText}>Browse your decks</Text></Pressable> : null}
            </View>
          }
        />
      ) : (
        <>
          <View style={styles.queueRow}>
            <Text style={styles.queueLabel}>{deck?.title ?? "Your cards"}</Text>
            <Text style={styles.queueCount}>Card 1 of {queue.length}</Text>
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={flipped ? `Answer: ${card.back}. Tap to show the question.` : `Question: ${card.front}. Tap to reveal the answer.`}
            accessibilityHint="Flips the flashcard. On web, press Space."
            accessibilityState={{ selected: flipped }}
            onPress={toggleFlip}
            style={({ pressed }) => [styles.cardPressable, pressed && styles.cardPressed]}
          >
            <View style={styles.cardScene}>
              <Animated.View style={[styles.cardFace, styles.frontFace, { transform: [{ perspective: 1000 }, { rotateY: faceRotation }] }]}>
                <View style={styles.cardFaceTop}>
                  <View style={styles.cardTag}><Text style={styles.cardTagText}>QUESTION</Text></View>
                  <Ionicons name="swap-horizontal" size={18} color={COLORS.muted} />
                </View>
                <Text accessibilityRole="header" style={styles.cardText}>{card.front}</Text>
                <Text style={styles.cardHint}>TAP OR PRESS SPACE TO FLIP</Text>
              </Animated.View>
              <Animated.View style={[styles.cardFace, styles.backFace, { transform: [{ perspective: 1000 }, { rotateY: backRotation }] }]}>
                <View style={styles.cardFaceTop}>
                  <View style={[styles.cardTag, styles.answerTag]}><Text style={[styles.cardTagText, { color: COLORS.green }]}>ANSWER</Text></View>
                  <Ionicons name="checkmark-circle-outline" size={18} color={COLORS.green} />
                </View>
                <Text accessibilityRole="header" style={styles.cardText}>{card.back}</Text>
                <Text style={styles.cardHint}>HOW WELL DID YOU REMEMBER?</Text>
              </Animated.View>
            </View>
          </Pressable>

          <View style={styles.ratingHeading}>
            <Text style={styles.ratingTitle}>Rate your recall</Text>
            <Text style={styles.ratingSubtitle}>Your next review adjusts as you go</Text>
          </View>
          <View style={styles.ratingRow}>
            <RatingButton title="Hard" keyHint="1" color={COLORS.red} tint={COLORS.redSoft} card={card} rating={0} disabled={!flipped} onPress={() => void handleRating(0)} />
            <RatingButton title="Good" keyHint="2" color={COLORS.amber} tint={COLORS.amberSoft} card={card} rating={1} disabled={!flipped} onPress={() => void handleRating(1)} />
            <RatingButton title="Easy" keyHint="3" color={COLORS.green} tint={COLORS.greenSoft} card={card} rating={2} disabled={!flipped} onPress={() => void handleRating(2)} />
          </View>
          {!flipped ? (
            <Surface style={styles.flipReminder}>
              <Ionicons name="bulb-outline" size={17} color={COLORS.cyan} />
              <Text style={styles.flipReminderText}>Try to recall the answer before you reveal it. Ratings unlock after the card flips.</Text>
            </Surface>
          ) : null}
          {Platform.OS === "web" ? (
            <View style={styles.keyboardHint}>
              <Ionicons name="keypad-outline" size={14} color={COLORS.muted} />
              <Text style={styles.keyboardHintText}>Keyboard: Space to flip · 1 Hard · 2 Good · 3 Easy</Text>
            </View>
          ) : null}
        </>
      )}
    </AppPage>
  );
}

function RatingButton({
  title,
  keyHint,
  color,
  tint,
  card,
  rating,
  disabled,
  onPress,
}: {
  title: string;
  keyHint: string;
  color: string;
  tint: string;
  card: Flashcard;
  rating: Rating;
  disabled: boolean;
  onPress: () => void;
}) {
  const interval = previewIntervalLabel(card, rating);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${title}, review again in ${interval}`}
      accessibilityHint={disabled ? "Flip the card to enable this rating." : undefined}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [styles.ratingButton, { borderColor: `${color}70`, backgroundColor: tint }, disabled && styles.ratingDisabled, pressed && !disabled && styles.cardPressed]}
    >
      <View style={styles.ratingTitleRow}>
        <Text style={[styles.ratingButtonTitle, { color }]}>{title}</Text>
        <Text style={[styles.keyHint, { color }]}>{keyHint}</Text>
      </View>
      <Text style={styles.ratingInterval}>{interval}</Text>
    </Pressable>
  );
}

const styles = createStyles({
  queueRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: -6 },
  queueLabel: { color: COLORS.muted, fontSize: 12, fontWeight: "700", flex: 1, paddingRight: 10 },
  queueCount: { color: COLORS.cyan, fontSize: 11, fontWeight: "800" },
  cardPressable: { width: "100%" },
  cardScene: { minHeight: 300, position: "relative" },
  cardFace: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 26, borderWidth: 1, borderColor: "#2B4963", backgroundColor: "#11253A", padding: 22, alignItems: "center", justifyContent: "center", backfaceVisibility: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 12 }, shadowOpacity: 0.22, shadowRadius: 24, elevation: 5 },
  frontFace: { borderColor: "#2B4963" },
  backFace: { borderColor: "rgba(74,213,165,0.55)", backgroundColor: "#102A2C" },
  cardFaceTop: { position: "absolute", top: 17, left: 18, right: 18, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  cardTag: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: "rgba(56,189,248,0.3)", backgroundColor: "rgba(56,189,248,0.10)" },
  answerTag: { borderColor: "rgba(74,213,165,0.32)", backgroundColor: "rgba(74,213,165,0.10)" },
  cardTagText: { color: COLORS.cyan, fontSize: 9, fontWeight: "800", letterSpacing: 0.8 },
  cardText: { color: COLORS.text, fontSize: 21, lineHeight: 30, fontWeight: "700", textAlign: "center", paddingHorizontal: 2 },
  cardHint: { position: "absolute", bottom: 18, color: COLORS.muted, fontSize: 9, fontWeight: "800", letterSpacing: 0.8 },
  cardPressed: { opacity: 0.9, transform: [{ scale: 0.99 }] },
  ratingHeading: { marginTop: 2, gap: 3 },
  ratingTitle: { color: COLORS.text, fontSize: 15, fontWeight: "800" },
  ratingSubtitle: { color: COLORS.muted, fontSize: 11 },
  ratingRow: { flexDirection: "row", gap: 9 },
  ratingButton: { flex: 1, minHeight: 76, padding: 11, borderRadius: 17, borderWidth: 1, alignItems: "stretch", justifyContent: "center", gap: 6 },
  ratingTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  ratingButtonTitle: { fontSize: 13, fontWeight: "800" },
  ratingInterval: { color: COLORS.text, fontSize: 10, fontWeight: "700" },
  ratingDisabled: { opacity: 0.42 },
  keyHint: { fontSize: 9, fontWeight: "800", borderWidth: 1, borderColor: "#42566B", borderRadius: 6, paddingHorizontal: 5, paddingVertical: 2, overflow: "hidden" },
  flipReminder: { flexDirection: "row", gap: 9, alignItems: "center", padding: 13 },
  flipReminderText: { flex: 1, color: COLORS.muted, fontSize: 11, lineHeight: 16 },
  keyboardHint: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 6 },
  keyboardHintText: { color: COLORS.muted, fontSize: 10 },
  secondaryLink: { minHeight: 44, alignItems: "center", justifyContent: "center" },
  secondaryLinkText: { color: COLORS.cyan, fontSize: 12, fontWeight: "700" },
});
