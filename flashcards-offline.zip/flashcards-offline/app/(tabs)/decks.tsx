import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";

import { AppPage, COLORS, ConfirmDialog, createStyles, EmptyState, PageHeader, ProgressBar, SecondaryButton, Surface } from "@/components/flashcards-ui";
import { useFlashcards } from "@/hooks/flashcards-provider";
import { useNow } from "@/hooks/use-now";
import type { Deck } from "@/lib/flashcards";

export default function DecksScreen() {
  const router = useRouter();
  const { data, ready, deleteDeck } = useFlashcards();
  const now = useNow();
  const [query, setQuery] = useState("");
  const [pendingDelete, setPendingDelete] = useState<Deck | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filteredDecks = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return data.decks.filter((deck) => deck.title.toLowerCase().includes(needle));
  }, [data.decks, query]);

  if (!ready) return <AppPage><View style={{ flex: 1 }} /></AppPage>;

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await deleteDeck(pendingDelete.id);
      setPendingDelete(null);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <AppPage>
      <PageHeader eyebrow="YOUR COLLECTION" title="Decks" subtitle={`${data.decks.length} ${data.decks.length === 1 ? "deck" : "decks"} · all stored locally`} />

      <View style={styles.searchWrap}>
        <Ionicons name="search-outline" size={18} color={COLORS.muted} />
        <TextInput
          accessibilityLabel="Search decks"
          value={query}
          onChangeText={setQuery}
          placeholder="Search your decks"
          placeholderTextColor={COLORS.muted}
          returnKeyType="search"
          style={styles.searchInput}
        />
        {query ? <Pressable accessibilityRole="button" accessibilityLabel="Clear search" onPress={() => setQuery("")}><Ionicons name="close-circle" size={18} color={COLORS.muted} /></Pressable> : null}
      </View>

      {filteredDecks.length === 0 ? (
        <EmptyState
          icon={query ? "search-outline" : "layers-outline"}
          title={query ? "No matching decks" : "Your first deck is waiting"}
          message={query ? "Try a different search term." : "Create a card and give it a home. You can add more decks as your subjects grow."}
          action={!query ? <PrimaryCreateButton onPress={() => router.push("/create")} /> : undefined}
        />
      ) : (
        <View style={styles.deckList}>
          {filteredDecks.map((deck, index) => {
            const cards = data.cards.filter((card) => card.deckId === deck.id);
            const dueCount = cards.filter((card) => card.nextReview <= now).length;
            const masteredCount = cards.filter((card) => card.mastery >= 2).length;
            const progress = cards.length ? Math.round((masteredCount / cards.length) * 100) : 0;
            return (
              <Surface key={deck.id} style={styles.deckCard}>
                <View style={styles.deckHeader}>
                  <View style={[styles.deckIndex, index % 2 ? styles.indexIndigo : null]}>
                    <Text style={styles.deckIndexText}>{String(index + 1).padStart(2, "0")}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text accessibilityRole="header" style={styles.deckTitle}>{deck.title}</Text>
                    <Text style={styles.deckMeta}>{cards.length} {cards.length === 1 ? "card" : "cards"} · {dueCount} due</Text>
                  </View>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Delete ${deck.title} and all ${cards.length} cards`}
                    onPress={() => setPendingDelete(deck)}
                    hitSlop={8}
                    style={({ pressed }) => [styles.deleteButton, pressed && { opacity: 0.7 }]}
                  >
                    <Ionicons name="trash-outline" size={17} color={COLORS.red} />
                  </Pressable>
                </View>
                <View style={styles.deckProgressRow}>
                  <ProgressBar value={progress} color={index % 2 ? COLORS.indigo : COLORS.cyan} />
                  <Text style={styles.progressLabel}>{progress}%</Text>
                </View>
                <View style={styles.deckActions}>
                  <SecondaryButton title="Study this deck" icon="play" onPress={() => router.push({ pathname: "/study", params: { deckId: deck.id } })} />
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`View statistics for ${deck.title}`}
                    onPress={() => router.push("/stats")}
                    style={styles.statsAction}
                  >
                    <Ionicons name="stats-chart-outline" size={16} color={COLORS.indigo} />
                    <Text style={styles.statsActionText}>Stats</Text>
                  </Pressable>
                </View>
              </Surface>
            );
          })}
        </View>
      )}

      <View style={styles.addDeckHint}>
        <Ionicons name="add-circle-outline" size={17} color={COLORS.cyan} />
        <Text style={styles.addDeckHintText}>Create new decks from the New Flashcard screen.</Text>
      </View>

      <ConfirmDialog
        visible={Boolean(pendingDelete)}
        title={`Delete “${pendingDelete?.title ?? "deck"}”?`}
        message={`This permanently deletes the deck and all ${data.cards.filter((card) => card.deckId === pendingDelete?.id).length} cards inside it from this device.`}
        confirmLabel={deleting ? "Deleting…" : "Delete deck"}
        destructive
        onCancel={() => setPendingDelete(null)}
        onConfirm={() => void confirmDelete()}
      />
    </AppPage>
  );
}

function PrimaryCreateButton({ onPress }: { onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={styles.createAction}>
      <Text style={styles.createActionText}>Create a flashcard</Text>
      <Ionicons name="arrow-forward" size={17} color={COLORS.background} />
    </Pressable>
  );
}

const styles = createStyles({
  searchWrap: { minHeight: 50, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, borderRadius: 15, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.backgroundSoft },
  searchInput: { flex: 1, color: COLORS.text, paddingVertical: 12, fontSize: 13, outlineStyle: "none" as never },
  deckList: { gap: 11 },
  deckCard: { padding: 15, gap: 14 },
  deckHeader: { flexDirection: "row", alignItems: "center", gap: 11 },
  deckIndex: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(56,189,248,0.15)" },
  indexIndigo: { backgroundColor: "rgba(129,140,248,0.17)" },
  deckIndexText: { color: COLORS.cyan, fontSize: 10, fontWeight: "900" },
  deckTitle: { color: COLORS.text, fontSize: 14, fontWeight: "800" },
  deckMeta: { color: COLORS.muted, fontSize: 10, marginTop: 4 },
  deleteButton: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.redSoft, borderWidth: 1, borderColor: "#59303A" },
  deckProgressRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  progressLabel: { color: COLORS.muted, fontSize: 10, fontWeight: "700", width: 32, textAlign: "right" },
  deckActions: { flexDirection: "row", alignItems: "center", gap: 10 },
  statsAction: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 9 },
  statsActionText: { color: COLORS.indigo, fontSize: 11, fontWeight: "700" },
  addDeckHint: { flexDirection: "row", gap: 7, alignItems: "center", justifyContent: "center", paddingHorizontal: 8 },
  addDeckHintText: { color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  createAction: { minHeight: 50, flexDirection: "row", gap: 9, alignItems: "center", justifyContent: "center", paddingHorizontal: 17, borderRadius: 15, backgroundColor: COLORS.cyan },
  createActionText: { color: COLORS.background, fontSize: 13, fontWeight: "800" },
});
