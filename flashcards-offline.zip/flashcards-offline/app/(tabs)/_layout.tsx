import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import * as Haptics from "expo-haptics";
import { Platform, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FlashcardsProvider } from "@/hooks/flashcards-provider";
import { COLORS, createStyles } from "@/components/flashcards-ui";

const TAB_ITEMS: Record<string, { label: string; icon: React.ComponentProps<typeof Ionicons>["name"] }> = {
  index: { label: "Home", icon: "home-outline" },
  study: { label: "Study", icon: "albums-outline" },
  create: { label: "Create", icon: "add" },
  decks: { label: "Decks", icon: "layers-outline" },
  stats: { label: "Stats", icon: "stats-chart-outline" },
};

function FloatingDock({ state, descriptors, navigation }: any) {
  const insets = useSafeAreaInsets();
  const bottom = Math.max(insets.bottom, 10) + (Platform.OS === "web" ? 7 : 4);

  return (
    <View pointerEvents="box-none" style={[styles.dockPosition, { bottom }]}>
      <View style={styles.dock}>
        {state.routes.map((route: any, index: number) => {
          const item = TAB_ITEMS[route.name];
          if (!item) return null;
          const focused = state.index === index;
          const isCreate = route.name === "create";
          const onPress = () => {
            const event = navigation.emit({ type: "tabPress", target: route.key, canPreventDefault: true });
            if (!focused && !event.defaultPrevented) {
              if (Platform.OS !== "web") void Haptics.selectionAsync().catch(() => undefined);
              navigation.navigate(route.name, route.params);
            }
          };
          return (
            <Pressable
              key={route.key}
              accessibilityRole="tab"
              accessibilityLabel={isCreate ? "Create a flashcard" : item.label}
              accessibilityState={{ selected: focused }}
              onPress={onPress}
              style={({ pressed }) => [
                isCreate ? styles.createButton : styles.dockItem,
                focused && !isCreate && styles.activeDockItem,
                pressed && styles.pressed,
              ]}
            >
              <Ionicons
                name={isCreate ? "add" : item.icon}
                size={isCreate ? 26 : 19}
                color={isCreate ? COLORS.background : focused ? COLORS.background : COLORS.muted}
              />
              {!isCreate && focused ? <Text style={styles.activeLabel}>{item.label}</Text> : null}
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export default function TabLayout() {
  return (
    <FlashcardsProvider>
      <Tabs
        tabBar={(props) => <FloatingDock {...props} />}
        screenOptions={{
          headerShown: false,
          sceneStyle: { backgroundColor: COLORS.background },
          tabBarStyle: { position: "absolute", height: 90, backgroundColor: "transparent", borderTopWidth: 0, elevation: 0 },
        }}
      >
        <Tabs.Screen name="index" options={{ title: "Home" }} />
        <Tabs.Screen name="study" options={{ title: "Study" }} />
        <Tabs.Screen name="create" options={{ title: "Create" }} />
        <Tabs.Screen name="decks" options={{ title: "Decks" }} />
        <Tabs.Screen name="stats" options={{ title: "Stats" }} />
      </Tabs>
    </FlashcardsProvider>
  );
}

const styles = createStyles({
  dockPosition: { position: "absolute", left: 16, right: 16, alignItems: "center" },
  dock: {
    width: "100%",
    maxWidth: 490,
    height: 66,
    paddingHorizontal: 8,
    borderRadius: 36,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.15)",
    backgroundColor: "rgba(11,23,38,0.97)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.38,
    shadowRadius: 20,
    elevation: 12,
  },
  dockItem: { minWidth: 42, height: 46, paddingHorizontal: 10, borderRadius: 24, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6 },
  activeDockItem: { backgroundColor: COLORS.text, paddingHorizontal: 13 },
  activeLabel: { color: COLORS.background, fontSize: 11, fontWeight: "800" },
  createButton: {
    width: 52,
    height: 52,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.cyan,
    marginTop: -22,
    borderWidth: 4,
    borderColor: COLORS.background,
    shadowColor: COLORS.cyan,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.38,
    shadowRadius: 12,
    elevation: 8,
  },
  pressed: { opacity: 0.78, transform: [{ scale: 0.96 }] },
});
