import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Pressable, Text, View } from "react-native";

import { AppPage, COLORS, createStyles, Notice, PageHeader, PrimaryButton, Surface, TextField } from "@/components/flashcards-ui";
import { useFlashcards } from "@/hooks/flashcards-provider";

export default function CreateScreen() {
  const { data, ready, addCard } = useFlashcards();
  const [selectedDeckId, setSelectedDeckId] = useState("");
  const [createNewDeck, setCreateNewDeck] = useState(false);
  const [newDeckTitle, setNewDeckTitle] = useState("");
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState<"success" | "error">("success");
  const [saving, setSaving] = useState(false);

  const activeDeckId = selectedDeckId || data.decks[0]?.id || "";
  const isCreatingDeck = createNewDeck || data.decks.length === 0;

  if (!ready) return <AppPage><View style={{ flex: 1 }} /></AppPage>;

  const handleSave = async () => {
    setMessage("");
    if (!front.trim() || !back.trim()) {
      setMessageType("error");
      setMessage("Add both a question and an answer before saving.");
      return;
    }
    if (isCreatingDeck && !newDeckTitle.trim()) {
      setMessageType("error");
      setMessage("Give your new deck a name first.");
      return;
    }
    if (!isCreatingDeck && !activeDeckId) {
      setMessageType("error");
      setMessage("Choose a deck or create one inline.");
      return;
    }

    setSaving(true);
    try {
      await addCard({
        deckId: isCreatingDeck ? undefined : activeDeckId,
        newDeckTitle: isCreatingDeck ? newDeckTitle : undefined,
        front,
        back,
      });
      setFront("");
      setBack("");
      if (isCreatingDeck) setNewDeckTitle("");
      setMessageType("success");
      setMessage("Flashcard saved on this device and ready for review.");
    } catch (error) {
      setMessageType("error");
      setMessage(error instanceof Error ? error.message : "The card could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <AppPage>
      <PageHeader eyebrow="BUILD YOUR DECK" title="New flashcard" subtitle="Write a prompt and the answer you want to remember." />

      <Surface style={styles.formCard}>
        <View style={styles.stepHeader}>
          <View style={styles.stepNumber}><Text style={styles.stepNumberText}>01</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.stepTitle}>Choose a deck</Text>
            <Text style={styles.stepDescription}>Keep related ideas together.</Text>
          </View>
        </View>

        {data.decks.length ? (
          <View style={styles.deckChoices}>
            {data.decks.map((deck) => {
              const selected = !isCreatingDeck && activeDeckId === deck.id;
              return (
                <Pressable
                  key={deck.id}
                  accessibilityRole="button"
                  accessibilityLabel={`Select ${deck.title} deck`}
                  accessibilityState={{ selected }}
                  onPress={() => { setSelectedDeckId(deck.id); setCreateNewDeck(false); }}
                  style={({ pressed }) => [styles.deckChip, selected && styles.deckChipSelected, pressed && styles.pressed]}
                >
                  <Text style={[styles.deckChipText, selected && styles.deckChipTextSelected]} numberOfLines={1}>{deck.title}</Text>
                </Pressable>
              );
            })}
          </View>
        ) : (
          <View style={styles.noDeckInfo}>
            <Ionicons name="information-circle-outline" size={18} color={COLORS.cyan} />
            <Text style={styles.noDeckText}>No decks yet. Name one below to get started.</Text>
          </View>
        )}

        <Pressable
          accessibilityRole="button"
          accessibilityState={{ selected: isCreatingDeck }}
          onPress={() => setCreateNewDeck(true)}
          style={({ pressed }) => [styles.newDeckToggle, isCreatingDeck && styles.newDeckToggleSelected, pressed && styles.pressed]}
        >
          <Ionicons name="add-circle-outline" size={18} color={isCreatingDeck ? COLORS.cyan : COLORS.muted} />
          <Text style={[styles.newDeckToggleText, isCreatingDeck && { color: COLORS.cyan }]}>Create a new deck</Text>
        </Pressable>

        {isCreatingDeck ? (
          <TextField
            label="Deck name"
            value={newDeckTitle}
            onChangeText={setNewDeckTitle}
            placeholder="e.g. Biology · Cell structure"
            autoCapitalize="sentences"
            returnKeyType="next"
            maxLength={120}
          />
        ) : null}
      </Surface>

      <Surface style={styles.formCard}>
        <View style={styles.stepHeader}>
          <View style={[styles.stepNumber, styles.stepNumberIndigo]}><Text style={styles.stepNumberText}>02</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.stepTitle}>Shape your prompt</Text>
            <Text style={styles.stepDescription}>Keep the question focused and easy to recall.</Text>
          </View>
        </View>
        <TextField
          label="Front · question or prompt"
          value={front}
          onChangeText={setFront}
          placeholder="What do you want to remember?"
          multiline
          maxLength={10000}
          accessibilityHint="This is the side shown first during study."
        />
        <TextField
          label="Back · answer or explanation"
          value={back}
          onChangeText={setBack}
          placeholder="Add a clear, useful answer…"
          multiline
          maxLength={10000}
          accessibilityHint="This is revealed when you flip the card."
        />
      </Surface>

      <PrimaryButton title={saving ? "Saving card…" : "Save flashcard offline"} icon="checkmark" disabled={saving} onPress={() => void handleSave()} />
      <Notice message={message} type={messageType} />
      <View style={styles.privacyNote}>
        <Ionicons name="lock-closed-outline" size={14} color={COLORS.muted} />
        <Text style={styles.privacyText}>Saved locally on this device. No account or connection required.</Text>
      </View>
    </AppPage>
  );
}

const styles = createStyles({
  formCard: { gap: 16 },
  stepHeader: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 1 },
  stepNumber: { width: 38, height: 38, borderRadius: 13, backgroundColor: "rgba(56,189,248,0.15)", alignItems: "center", justifyContent: "center" },
  stepNumberIndigo: { backgroundColor: "rgba(129,140,248,0.16)" },
  stepNumberText: { color: COLORS.cyan, fontSize: 11, fontWeight: "900" },
  stepTitle: { color: COLORS.text, fontSize: 14, fontWeight: "800" },
  stepDescription: { color: COLORS.muted, fontSize: 11, marginTop: 3, lineHeight: 15 },
  deckChoices: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  deckChip: { maxWidth: "100%", borderRadius: 999, paddingHorizontal: 13, paddingVertical: 10, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.backgroundSoft },
  deckChipSelected: { borderColor: COLORS.cyan, backgroundColor: "rgba(56,189,248,0.15)" },
  deckChipText: { color: COLORS.muted, fontSize: 11, fontWeight: "700", maxWidth: 220 },
  deckChipTextSelected: { color: COLORS.cyan },
  newDeckToggle: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 12 },
  newDeckToggleSelected: { borderColor: "rgba(56,189,248,0.35)" },
  newDeckToggleText: { color: COLORS.muted, fontSize: 12, fontWeight: "700" },
  noDeckInfo: { flexDirection: "row", gap: 8, alignItems: "center", paddingVertical: 4 },
  noDeckText: { color: COLORS.muted, fontSize: 12, flex: 1 },
  privacyNote: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 6 },
  privacyText: { color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  pressed: { opacity: 0.8 },
});
