import { Ionicons } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { useRouter } from "expo-router";
import { useState } from "react";
import { Platform, Pressable, Text, View } from "react-native";

import {
  AppPage,
  BrandMark,
  COLORS,
  ConfirmDialog,
  createStyles,
  MetricCard,
  Notice,
  PrimaryButton,
  ProgressBar,
  SectionHeading,
  SecondaryButton,
  StatusPill,
  Surface,
} from "@/components/flashcards-ui";
import { useFlashcards } from "@/hooks/flashcards-provider";
import { useConnectivity } from "@/hooks/use-connectivity";
import { useNow } from "@/hooks/use-now";
import { parseBackup } from "@/lib/flashcards";

export default function DashboardScreen() {
  const router = useRouter();
  const { data, ready, storageError, exportBackup, importBackup } = useFlashcards();
  const { isOnline, label } = useConnectivity();
  const now = useNow();
  const [notice, setNotice] = useState("");
  const [noticeType, setNoticeType] = useState<"success" | "error" | "info">("success");
  const [backupText, setBackupText] = useState<string | null>(null);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const [busy, setBusy] = useState(false);

  if (!ready) return <AppPage><View style={{ flex: 1 }} /></AppPage>;

  const dueCount = data.cards.filter((card) => card.nextReview <= now).length;
  const masteredCount = data.cards.filter((card) => card.mastery >= 2).length;
  const masteryPercent = data.cards.length ? Math.round((masteredCount / data.cards.length) * 100) : 0;

  const announce = (message: string, type: "success" | "error" | "info" = "success") => {
    setNotice(message);
    setNoticeType(type);
  };

  const handleExport = async () => {
    setBusy(true);
    setNotice("");
    try {
      const json = exportBackup();
      const filename = `flashcards-backup-${new Date().toISOString().slice(0, 10)}.json`;
      if (Platform.OS === "web" && typeof document !== "undefined") {
        const blob = new Blob([json], { type: "application/json" });
        const uri = URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        anchor.href = uri;
        anchor.download = filename;
        anchor.click();
        window.setTimeout(() => URL.revokeObjectURL(uri), 1000);
      } else {
        const directory = FileSystem.cacheDirectory;
        if (!directory) throw new Error("A temporary file location is not available.");
        const uri = `${directory}${filename}`;
        await FileSystem.writeAsStringAsync(uri, json, { encoding: FileSystem.EncodingType.UTF8 });
        if (!(await Sharing.isAvailableAsync())) throw new Error("File sharing is not available on this device.");
        await Sharing.shareAsync(uri, {
          mimeType: "application/json",
          UTI: "public.json",
          dialogTitle: "Export flashcards backup",
        });
      }
      announce("Your complete flashcards backup is ready.");
    } catch (error) {
      announce(error instanceof Error ? error.message : "The backup could not be exported.", "error");
    } finally {
      setBusy(false);
    }
  };

  const chooseBackup = async () => {
    setBusy(true);
    setNotice("");
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "application/json",
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (result.canceled) return;
      const asset = result.assets[0];
      const json = asset.file ? await asset.file.text() : await FileSystem.readAsStringAsync(asset.uri);
      parseBackup(json);
      setBackupText(json);
      setShowRestoreConfirm(true);
    } catch (error) {
      announce(error instanceof Error ? error.message : "That file is not a valid Flashcards backup.", "error");
    } finally {
      setBusy(false);
    }
  };

  const confirmRestore = async () => {
    if (!backupText) return;
    setBusy(true);
    try {
      await importBackup(backupText);
      setShowRestoreConfirm(false);
      setBackupText(null);
      announce("Backup restored. Your local decks and cards were replaced.");
    } catch (error) {
      setShowRestoreConfirm(false);
      announce(error instanceof Error ? error.message : "The backup could not be restored.", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppPage>
      <View style={styles.topBar}>
        <View style={styles.brandGroup}>
          <BrandMark size={39} />
          <View>
            <Text style={styles.brandName}>Flashcards</Text>
            <Text style={styles.brandCaption}>OFFLINE STUDY SPACE</Text>
          </View>
        </View>
        <StatusPill label={isOnline === null ? "LOCAL READY" : isOnline ? "ONLINE · LOCAL" : "OFFLINE"} online={isOnline} />
      </View>

      <View style={styles.hero}>
        <View style={styles.heroCopy}>
          <Text style={styles.heroKicker}>SMALL SESSIONS ADD UP</Text>
          <Text accessibilityRole="header" style={styles.heroTitle}>A little practice,{"\n"}a lot of progress.</Text>
          <Text style={styles.heroDescription}>Your cards stay on this device. Pick up where you left off.</Text>
        </View>
        <View style={styles.heroBadge}>
          <Ionicons name="sparkles" size={23} color={COLORS.cyan} />
        </View>
      </View>

      <View style={styles.metricsRow}>
        <MetricCard
          label="TOTAL CARDS"
          value={data.cards.length}
          detail={`${data.decks.length} ${data.decks.length === 1 ? "active deck" : "active decks"}`}
          accent={COLORS.cyan}
          icon="albums-outline"
          style={{ flex: 1.08 }}
        />
        <MetricCard
          label="DUE TODAY"
          value={dueCount}
          detail={dueCount ? "Ready when you are" : "All clear for now"}
          accent={dueCount ? COLORS.amber : COLORS.green}
          icon="time-outline"
          style={{ flex: 0.92 }}
        />
      </View>

      <Surface style={styles.masteryCard}>
        <View style={styles.masteryTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardEyebrow}>YOUR MOMENTUM</Text>
            <Text accessibilityRole="header" style={styles.masteryTitle}>Mastery progress</Text>
          </View>
          <Text style={styles.masteryPercent}>{masteryPercent}<Text style={styles.percentSign}>%</Text></Text>
        </View>
        <ProgressBar value={masteryPercent} color={COLORS.cyan} />
        <Text style={styles.masteryCaption}>{masteredCount} of {data.cards.length} cards mastered</Text>
      </Surface>

      <PrimaryButton
        title={dueCount ? `Start studying · ${dueCount} due` : "Open study session"}
        icon="arrow-forward"
        onPress={() => router.push("/study")}
      />

      <View style={styles.sectionBlock}>
        <SectionHeading title="Keep your progress portable" detail="Stored on this device" />
        <Surface style={styles.backupCard}>
          <View style={styles.backupIntro}>
            <View style={styles.backupIcon}><Ionicons name="shield-checkmark-outline" size={20} color={COLORS.indigo} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.backupTitle}>Local by design</Text>
              <Text style={styles.backupDescription}>Export a JSON copy or restore one whenever you need.</Text>
            </View>
          </View>
          <View style={styles.backupActions}>
            <SecondaryButton title={busy ? "Working…" : "Export backup"} icon="download-outline" onPress={() => void handleExport()} />
            <SecondaryButton title="Import backup" icon="cloud-upload-outline" onPress={() => void chooseBackup()} />
          </View>
        </Surface>
      </View>

      <View style={styles.quickLinks}>
        <Pressable accessibilityRole="button" onPress={() => router.push("/decks")} style={styles.quickLink}>
          <View style={styles.quickLinkIcon}><Ionicons name="layers-outline" size={18} color={COLORS.indigo} /></View>
          <View style={{ flex: 1 }}><Text style={styles.quickLinkTitle}>Browse decks</Text><Text style={styles.quickLinkCopy}>Find the right set to study</Text></View>
          <Ionicons name="chevron-forward" size={17} color={COLORS.muted} />
        </Pressable>
        <Pressable accessibilityRole="button" onPress={() => router.push("/stats")} style={styles.quickLink}>
          <View style={styles.quickLinkIcon}><Ionicons name="stats-chart-outline" size={18} color={COLORS.green} /></View>
          <View style={{ flex: 1 }}><Text style={styles.quickLinkTitle}>See your progress</Text><Text style={styles.quickLinkCopy}>A clear view of what is sticking</Text></View>
          <Ionicons name="chevron-forward" size={17} color={COLORS.muted} />
        </Pressable>
      </View>

      {storageError ? <Notice message={`Local data note: ${storageError}`} type="error" /> : null}
      <Notice message={notice} type={noticeType} />
      <View style={styles.footerNote}>
        <Ionicons name="phone-portrait-outline" size={14} color={COLORS.muted} />
        <Text style={styles.footerText}>{label}. Your cards remain available without a connection.</Text>
      </View>

      <ConfirmDialog
        visible={showRestoreConfirm}
        title="Replace current flashcards?"
        message="Restoring this backup replaces all decks, cards, and review history currently saved on this device. Export a copy first if you want to keep them."
        confirmLabel="Restore backup"
        onCancel={() => { setShowRestoreConfirm(false); setBackupText(null); }}
        onConfirm={() => void confirmRestore()}
      />
      {busy ? <View accessibilityLiveRegion="polite" style={styles.busyOverlay}><Text style={styles.busyText}>Preparing backup…</Text></View> : null}
    </AppPage>
  );
}

const styles = createStyles({
  topBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, marginBottom: 2 },
  brandGroup: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandName: { color: COLORS.text, fontSize: 16, fontWeight: "800", letterSpacing: -0.2 },
  brandCaption: { color: COLORS.muted, fontSize: 8, letterSpacing: 1.1, fontWeight: "800", marginTop: 2 },
  hero: { minHeight: 170, overflow: "hidden", position: "relative", borderRadius: 25, padding: 21, borderWidth: 1, borderColor: "#1D3B54", backgroundColor: "#10243A", flexDirection: "row", alignItems: "center" },
  heroCopy: { flex: 1, maxWidth: 280, gap: 8, zIndex: 1 },
  heroKicker: { color: COLORS.cyan, fontSize: 9, letterSpacing: 1.35, fontWeight: "800" },
  heroTitle: { color: COLORS.text, fontSize: 25, lineHeight: 31, fontWeight: "800", letterSpacing: -0.7 },
  heroDescription: { color: "#B4C4D5", fontSize: 12, lineHeight: 18, maxWidth: 270 },
  heroBadge: { width: 52, height: 52, borderRadius: 20, position: "absolute", right: 18, top: 18, backgroundColor: "rgba(56,189,248,0.13)", alignItems: "center", justifyContent: "center" },
  metricsRow: { flexDirection: "row", gap: 11 },
  masteryCard: { gap: 13 },
  masteryTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cardEyebrow: { color: COLORS.cyan, fontSize: 9, letterSpacing: 1.15, fontWeight: "800", marginBottom: 4 },
  masteryTitle: { color: COLORS.text, fontSize: 16, fontWeight: "700" },
  masteryPercent: { color: COLORS.cyan, fontSize: 28, fontWeight: "800", letterSpacing: -0.8 },
  percentSign: { fontSize: 15, color: COLORS.muted },
  masteryCaption: { color: COLORS.muted, fontSize: 11 },
  sectionBlock: { gap: 1 },
  backupCard: { padding: 15, gap: 14 },
  backupIntro: { flexDirection: "row", alignItems: "center", gap: 12 },
  backupIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "rgba(129,140,248,0.14)", alignItems: "center", justifyContent: "center" },
  backupTitle: { color: COLORS.text, fontSize: 13, fontWeight: "800", marginBottom: 3 },
  backupDescription: { color: COLORS.muted, fontSize: 11, lineHeight: 16 },
  backupActions: { flexDirection: "row", gap: 9 },
  quickLinks: { gap: 9 },
  quickLink: { flexDirection: "row", alignItems: "center", gap: 11, padding: 13, borderRadius: 17, borderWidth: 1, borderColor: COLORS.border, backgroundColor: "rgba(16,31,49,0.75)" },
  quickLinkIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.surfaceRaised },
  quickLinkTitle: { color: COLORS.text, fontSize: 12, fontWeight: "700" },
  quickLinkCopy: { color: COLORS.muted, fontSize: 10, marginTop: 3 },
  footerNote: { flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 2 },
  footerText: { flex: 1, color: COLORS.muted, fontSize: 10, lineHeight: 15 },
  busyOverlay: { position: "absolute", alignSelf: "center", bottom: 132, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surfaceRaised },
  busyText: { color: COLORS.text, fontSize: 11, fontWeight: "700" },
});
