import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

import {
  calculateSM2,
  createInitialData,
  makeId,
  parseBackup,
  serializeBackup,
  validateData,
  type Deck,
  type Flashcard,
  type FlashcardsData,
  type Rating,
} from "@/lib/flashcards";

const STORAGE_KEY = "flashcards-offline-data-v2";

type CreateCardInput = {
  deckId?: string;
  newDeckTitle?: string;
  front: string;
  back: string;
};

type FlashcardsContextValue = {
  data: FlashcardsData;
  ready: boolean;
  storageError: string | null;
  addCard: (input: CreateCardInput) => Promise<void>;
  rateCard: (cardId: string, rating: Rating) => Promise<void>;
  deleteDeck: (deckId: string) => Promise<void>;
  importBackup: (text: string) => Promise<void>;
  exportBackup: () => string;
};

const FlashcardsContext = createContext<FlashcardsContextValue | null>(null);

export function FlashcardsProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<FlashcardsData>({ decks: [], cards: [] });
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const dataRef = useRef<FlashcardsData>({ decks: [], cards: [] });

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        const initial = saved ? validateData(JSON.parse(saved) as unknown) : createInitialData();
        if (!saved) await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
        if (!mounted) return;
        dataRef.current = initial;
        setData(initial);
      } catch (error) {
        if (!mounted) return;
        const message = error instanceof Error ? error.message : "Local data could not be read.";
        setStorageError(message);
        const fallback = createInitialData();
        dataRef.current = fallback;
        setData(fallback);
      } finally {
        if (mounted) setReady(true);
      }
    };
    void load();
    return () => {
      mounted = false;
    };
  }, []);

  const commit = useCallback(async (next: FlashcardsData) => {
    const normalized = validateData(next);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    dataRef.current = normalized;
    setData(normalized);
    setStorageError(null);
  }, []);

  const addCard = useCallback(
    async ({ deckId: selectedDeckId, newDeckTitle, front, back }: CreateCardInput) => {
      const current = dataRef.current;
      let deckId = selectedDeckId;
      const decks = [...current.decks];

      if (newDeckTitle?.trim()) {
        deckId = makeId("deck");
        decks.push({ id: deckId, title: newDeckTitle.trim(), createdAt: Date.now() });
      }
      if (!deckId || !decks.some((deck) => deck.id === deckId)) {
        throw new Error("Choose an existing deck or enter a new deck name.");
      }
      if (!front.trim() || !back.trim()) {
        throw new Error("Enter both the front and back of the card.");
      }

      const card: Flashcard = {
        id: makeId("card"),
        deckId,
        front: front.trim(),
        back: back.trim(),
        mastery: 0,
        repetitions: 0,
        intervalDays: 0,
        easeFactor: 2.5,
        nextReview: Date.now(),
        createdAt: Date.now(),
        reviewHistory: [],
      };
      await commit({ decks, cards: [...current.cards, card] });
    },
    [commit],
  );

  const rateCard = useCallback(
    async (cardId: string, rating: Rating) => {
      const current = dataRef.current;
      const card = current.cards.find((item) => item.id === cardId);
      if (!card) return;
      const updated = calculateSM2(card, rating);
      await commit({
        decks: current.decks,
        cards: current.cards.map((item) => (item.id === cardId ? updated : item)),
      });
    },
    [commit],
  );

  const deleteDeck = useCallback(
    async (deckId: string) => {
      const current = dataRef.current;
      await commit({
        decks: current.decks.filter((deck) => deck.id !== deckId),
        cards: current.cards.filter((card) => card.deckId !== deckId),
      });
    },
    [commit],
  );

  const importBackup = useCallback(
    async (text: string) => {
      const restored = parseBackup(text);
      await commit(restored);
    },
    [commit],
  );

  const value = useMemo<FlashcardsContextValue>(
    () => ({
      data,
      ready,
      storageError,
      addCard,
      rateCard,
      deleteDeck,
      importBackup,
      exportBackup: () => serializeBackup(dataRef.current),
    }),
    [data, ready, storageError, addCard, rateCard, deleteDeck, importBackup],
  );

  return <FlashcardsContext.Provider value={value}>{children}</FlashcardsContext.Provider>;
}

export function useFlashcards() {
  const value = useContext(FlashcardsContext);
  if (!value) throw new Error("useFlashcards must be used inside FlashcardsProvider.");
  return value;
}

export function dueCards(cards: Flashcard[], now = Date.now(), deckId?: string): Flashcard[] {
  return cards
    .filter((card) => (!deckId || card.deckId === deckId) && card.nextReview <= now)
    .sort((a, b) => a.nextReview - b.nextReview);
}

export function cardsForDeck(data: FlashcardsData, deckId: string): Flashcard[] {
  return data.cards.filter((card) => card.deckId === deckId);
}

export function getDeck(data: FlashcardsData, deckId: string): Deck | undefined {
  return data.decks.find((deck) => deck.id === deckId);
}
