import { useEffect, useState } from "react";

export function useNow(refreshInterval = 30_000) {
  const [now, setNow] = useState(0);

  useEffect(() => {
    const initial = setTimeout(() => setNow(Date.now()), 0);
    const interval = setInterval(() => setNow(Date.now()), refreshInterval);
    return () => {
      clearTimeout(initial);
      clearInterval(interval);
    };
  }, [refreshInterval]);

  return now;
}
