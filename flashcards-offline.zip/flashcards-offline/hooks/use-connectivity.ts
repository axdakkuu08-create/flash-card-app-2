import * as Network from "expo-network";
import { useEffect, useState } from "react";
import { Platform } from "react-native";

export function useConnectivity() {
  const [isOnline, setIsOnline] = useState<boolean | null>(null);

  useEffect(() => {
    let active = true;
    const applyState = (state: Network.NetworkState) => {
      const reachable = state.isInternetReachable ?? state.isConnected;
      if (active && typeof reachable === "boolean") setIsOnline(reachable);
    };

    void Network.getNetworkStateAsync().then(applyState).catch(() => {
      if (Platform.OS === "web" && typeof navigator !== "undefined") {
        setIsOnline(navigator.onLine);
      }
    });
    const subscription = Network.addNetworkStateListener(applyState);
    let removeBrowserListeners: (() => void) | undefined;

    if (Platform.OS === "web" && typeof window !== "undefined") {
      const onOnline = () => setIsOnline(true);
      const onOffline = () => setIsOnline(false);
      window.addEventListener("online", onOnline);
      window.addEventListener("offline", onOffline);
      setIsOnline(navigator.onLine);
      removeBrowserListeners = () => {
        window.removeEventListener("online", onOnline);
        window.removeEventListener("offline", onOffline);
      };
    }

    return () => {
      active = false;
      subscription.remove();
      removeBrowserListeners?.();
    };
  }, []);

  return {
    isOnline,
    label: isOnline === null ? "Checking connection" : isOnline ? "Online · Saved here" : "Offline · Saved here",
  };
}
