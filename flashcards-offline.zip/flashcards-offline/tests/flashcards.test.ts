import { describe, expect, it } from "vitest";

import {
  calculateSM2,
  countRecentReviews,
  createInitialData,
  intervalLabel,
  parseBackup,
  previewIntervalLabel,
  serializeBackup,
  type Flashcard,
} from "../lib/flashcards";

const timestamp = 1_800_000_000_000;

const cardFixture = (overrides: Partial<Flashcard> = {}): Flashcard => ({
  id: "card-test",
  deckId: "deck-test",
  front: "Prompt",
  back: "Answer",
  mastery: 0,
  repetitions: 0,
  intervalDays: 0,
  easeFactor: 2.5,
  nextReview: timestamp,
  createdAt: timestamp,
  reviewHistory: [],
  ...overrides,
});

describe("SM-2 scheduling", () => {
  it("repeats a Hard answer in two minutes, resets repetitions, lowers ease, and records the review", () => {
    const result = calculateSM2(cardFixture({ repetitions: 3, intervalDays: 10, easeFactor: 1.5 }), 0, timestamp);

    expect(result.nextReview).toBe(timestamp + 2 * 60 * 1000);
    expect(result.repetitions).toBe(0);
    expect(result.intervalDays).toBe(0);
    expect(result.easeFactor).toBe(1.3);
    expect(result.mastery).toBe(0);
    expect(result.reviewHistory).toEqual([
      { reviewedAt: timestamp, rating: 0, intervalDays: 0, nextReview: timestamp + 2 * 60 * 1000 },
    ]);
  });

  it("uses the first Good and Easy intervals and updates mastery/ease", () => {
    const fresh = cardFixture();
    const good = calculateSM2(fresh, 1, timestamp);
    const easy = calculateSM2(fresh, 2, timestamp);

    expect(good.intervalDays).toBe(1);
    expect(good.mastery).toBe(1);
    expect(good.easeFactor).toBe(2.5);
    expect(easy.intervalDays).toBe(3);
    expect(easy.mastery).toBe(2);
    expect(easy.easeFactor).toBe(2.65);
  });

  it("shows preview intervals that match the stored scheduling result", () => {
    const cards = [
      cardFixture(),
      cardFixture({ mastery: 1, repetitions: 1, intervalDays: 1 }),
      cardFixture({ mastery: 2, repetitions: 4, intervalDays: 10, easeFactor: 2.3 }),
    ];

    for (const card of cards) {
      for (const rating of [0, 1, 2] as const) {
        const result = calculateSM2(card, rating, timestamp);
        expect(previewIntervalLabel(card, rating)).toBe(intervalLabel(result.nextReview - timestamp));
      }
    }
  });
});

describe("offline JSON backups", () => {
  it("round-trips the complete deck and card dataset", () => {
    const data = createInitialData(timestamp);
    const restored = parseBackup(serializeBackup(data));
    expect(restored).toEqual(data);
  });

  it("rejects unsupported versions and invalid card-to-deck references", () => {
    const backup = JSON.parse(serializeBackup(createInitialData(timestamp))) as Record<string, unknown>;
    expect(() => parseBackup(JSON.stringify({ ...backup, version: 1 }))).toThrow(/Unsupported backup format/);

    const cards = backup.cards as Array<Record<string, unknown>>;
    cards[0] = { ...cards[0], deckId: "missing-deck" };
    expect(() => parseBackup(JSON.stringify(backup))).toThrow(/valid deck/);
  });
});


describe("recent review statistics", () => {
  it("counts only reviews from the last seven days and not future-dated records", () => {
    const now = timestamp + 10 * 24 * 60 * 60 * 1000;
    const card = cardFixture({
      reviewHistory: [
        { reviewedAt: now - 24 * 60 * 60 * 1000, rating: 1, intervalDays: 1, nextReview: now },
        { reviewedAt: now + 24 * 60 * 60 * 1000, rating: 2, intervalDays: 3, nextReview: now + 4 * 86400000 },
        { reviewedAt: now - 9 * 24 * 60 * 60 * 1000, rating: 0, intervalDays: 0, nextReview: now },
      ],
    });

    expect(countRecentReviews([card], now)).toBe(1);
  });
});
