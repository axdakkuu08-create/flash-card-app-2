export type Rating = 0 | 1 | 2;

export type ReviewRecord = {
  reviewedAt: number;
  rating: Rating;
  intervalDays: number;
  nextReview: number;
};

export type Deck = {
  id: string;
  title: string;
  createdAt: number;
};

export type Flashcard = {
  id: string;
  deckId: string;
  front: string;
  back: string;
  mastery: 0 | 1 | 2;
  repetitions: number;
  intervalDays: number;
  easeFactor: number;
  nextReview: number;
  createdAt: number;
  reviewHistory: ReviewRecord[];
};

export type FlashcardsData = {
  decks: Deck[];
  cards: Flashcard[];
};

export const BACKUP_APP_NAME = "FlashcardsOffline";
export const BACKUP_VERSION = 2;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isFiniteNumber = (value: unknown): value is number =>
  typeof value === "number" && Number.isFinite(value);

const cleanId = (value: unknown): string => {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, 200);
};

export function createInitialData(now = Date.now()): FlashcardsData {
  const deckId = "deck-core-1";
  return {
    decks: [{ id: deckId, title: "System Architecture", createdAt: now }],
    cards: [
      {
        id: "card-1",
        deckId,
        front: "What is IndexedDB used for in offline web apps?",
        back: "Client-side structured storage for large datasets and offline persistence.",
        mastery: 1,
        repetitions: 1,
        intervalDays: 1,
        easeFactor: 2.5,
        nextReview: now,
        createdAt: now,
        reviewHistory: [],
      },
      {
        id: "card-2",
        deckId,
        front: "How does Capacitor package a web app into an APK?",
        back: "It wraps local web assets inside a native Android WebView container with a JS-to-Native bridge.",
        mastery: 0,
        repetitions: 0,
        intervalDays: 0,
        easeFactor: 2.5,
        nextReview: now,
        createdAt: now,
        reviewHistory: [],
      },
    ],
  };
}

export function validateData(value: unknown): FlashcardsData {
  if (!isRecord(value) || !Array.isArray(value.decks) || !Array.isArray(value.cards)) {
    throw new Error("This file is not a valid Flashcards backup.");
  }

  const decks: Deck[] = value.decks.map((item) => {
    if (!isRecord(item)) throw new Error("A deck entry is malformed.");
    const id = cleanId(item.id);
    const title = typeof item.title === "string" ? item.title.trim().slice(0, 120) : "";
    if (!id || !title) throw new Error("Every deck needs an ID and a title.");
    return {
      id,
      title,
      createdAt: isFiniteNumber(item.createdAt) ? item.createdAt : Date.now(),
    };
  });

  const deckIds = new Set(decks.map((deck) => deck.id));
  if (deckIds.size !== decks.length) throw new Error("The backup contains duplicate deck IDs.");

  const cards: Flashcard[] = value.cards.map((item) => {
    if (!isRecord(item)) throw new Error("A flashcard entry is malformed.");
    const id = cleanId(item.id);
    const deckId = cleanId(item.deckId);
    const front = typeof item.front === "string" ? item.front.trim().slice(0, 10000) : "";
    const back = typeof item.back === "string" ? item.back.trim().slice(0, 10000) : "";
    if (!id || !deckIds.has(deckId) || !front || !back) {
      throw new Error("Every flashcard needs a valid deck, question, and answer.");
    }
    const masteryValue = Number(item.mastery ?? 0);
    const mastery = (masteryValue === 2 ? 2 : masteryValue === 1 ? 1 : 0) as Flashcard["mastery"];
    const reviewHistory: ReviewRecord[] = Array.isArray(item.reviewHistory)
      ? item.reviewHistory
          .filter(isRecord)
          .filter((record) => isFiniteNumber(record.reviewedAt) && [0, 1, 2].includes(Number(record.rating)))
          .map((record) => ({
            reviewedAt: Number(record.reviewedAt),
            rating: Number(record.rating) as Rating,
            intervalDays: Math.max(0, Number(record.intervalDays) || 0),
            nextReview: isFiniteNumber(record.nextReview) ? record.nextReview : Date.now(),
          }))
      : [];

    return {
      id,
      deckId,
      front,
      back,
      mastery,
      repetitions: Math.max(0, Math.floor(Number(item.repetitions) || 0)),
      intervalDays: Math.max(0, Number(item.intervalDays) || 0),
      easeFactor: Math.max(1.3, Number(item.easeFactor) || 2.5),
      nextReview: isFiniteNumber(item.nextReview) ? item.nextReview : Date.now(),
      createdAt: isFiniteNumber(item.createdAt) ? item.createdAt : Date.now(),
      reviewHistory,
    };
  });

  const cardIds = new Set(cards.map((card) => card.id));
  if (cardIds.size !== cards.length) throw new Error("The backup contains duplicate flashcard IDs.");
  return { decks, cards };
}

export function parseBackup(text: string): FlashcardsData {
  const parsed: unknown = JSON.parse(text);
  if (
    !isRecord(parsed) ||
    parsed.app !== BACKUP_APP_NAME ||
    parsed.version !== BACKUP_VERSION
  ) {
    throw new Error("Unsupported backup format. Choose a Flashcards Offline v2 JSON backup.");
  }
  return validateData(parsed);
}

export function serializeBackup(data: FlashcardsData): string {
  return JSON.stringify(
    {
      app: BACKUP_APP_NAME,
      version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(),
      decks: data.decks,
      cards: data.cards,
    },
    null,
    2,
  );
}

export function calculateSM2(card: Flashcard, rating: Rating, reviewedAt = Date.now()): Flashcard {
  let repetitions = card.repetitions || 0;
  let intervalDays = card.intervalDays || 0;
  let easeFactor = card.easeFactor || 2.5;

  if (rating === 0) {
    repetitions = 0;
    intervalDays = 0;
    easeFactor = Math.max(1.3, easeFactor - 0.2);
    const nextReview = reviewedAt + 2 * 60 * 1000;
    return {
      ...card,
      mastery: 0,
      repetitions,
      intervalDays,
      easeFactor,
      nextReview,
      reviewHistory: [
        ...(card.reviewHistory ?? []),
        { reviewedAt, rating, intervalDays, nextReview },
      ],
    };
  }

  if (repetitions === 0) {
    intervalDays = rating === 2 ? 3 : 1;
  } else if (repetitions === 1) {
    intervalDays = rating === 2 ? 6 : 3;
  } else {
    intervalDays = Math.round(intervalDays * easeFactor * (rating === 2 ? 1.3 : 1));
  }

  repetitions += 1;
  easeFactor = Math.max(1.3, easeFactor + (rating === 2 ? 0.15 : 0));
  const nextReview = reviewedAt + intervalDays * 24 * 60 * 60 * 1000;
  return {
    ...card,
    mastery: rating === 2 || repetitions >= 2 ? 2 : 1,
    repetitions,
    intervalDays,
    easeFactor,
    nextReview,
    reviewHistory: [
      ...(card.reviewHistory ?? []),
      { reviewedAt, rating, intervalDays, nextReview },
    ],
  };
}

export function intervalLabel(milliseconds: number): string {
  if (milliseconds <= 2 * 60 * 1000) return "2 min";
  if (milliseconds < 60 * 60 * 1000) return `${Math.max(1, Math.round(milliseconds / 60000))} min`;
  if (milliseconds < 24 * 60 * 60 * 1000) return `${Math.max(1, Math.round(milliseconds / 3600000))} hr`;
  const days = Math.max(1, Math.round(milliseconds / 86400000));
  return `${days} ${days === 1 ? "day" : "days"}`;
}

export function makeId(prefix: string): string {
  const random = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now()}-${random}`;
}

export function previewIntervalLabel(card: Flashcard, rating: Rating): string {
  if (rating === 0) return "2 min";
  let intervalDays = card.intervalDays || 0;
  const repetitions = card.repetitions || 0;
  if (repetitions === 0) intervalDays = rating === 2 ? 3 : 1;
  else if (repetitions === 1) intervalDays = rating === 2 ? 6 : 3;
  else intervalDays = Math.round(intervalDays * (card.easeFactor || 2.5) * (rating === 2 ? 1.3 : 1));
  return intervalLabel(intervalDays * 24 * 60 * 60 * 1000);
}

export function countRecentReviews(cards: Flashcard[], now: number, windowMs = 7 * 24 * 60 * 60 * 1000): number {
  const since = now - windowMs;
  return cards.reduce(
    (count, card) => count + card.reviewHistory.filter((review) => review.reviewedAt >= since && review.reviewedAt <= now).length,
    0,
  );
}
